enum AUDIO_ID
{
	bgmtitle,
	bgm01,
	bgm11,
	bgm12,
	bgm13,
	bgm21,
	bgm22,
	bgm23,
	bgm31,
	skillq,
	skillw,
	skille,
	skillr,
	pickitem,
	levelup,
	attack23,
	attack31,
	success,
};

namespace game_framework
{
	class Item {
	public:
		Item(int, int, string);
		~Item();
		void LoadBitmap();
		void SetTopLeft(int, int);
		void onShow(int, int, bool);
		int GetX();
		int GetY();
		int GetWidth();
		int GetHeight();
		int GetNum();
		string GetName();
		double GetShowTime();
		void SetNum(int);
		void ShowNum();
	protected:
		CMovingBitmap item_pic;
		vector<CMovingBitmap*> numfont;
		string name, effecttype;
		double timer_show;
		int x, y, num;
	};
	class Effect {
	public:
		Effect(string, int, int);
		string getName();
		int getNum();
		int getTime();
		void setTime(int);
	protected:
		string  effectname;
		int effecttime, effectnum;
	};
	class Monster
	{
	public:
		Monster(int, int, int, vector<int>, int, int, int, int, int);
		~Monster();
		void LoadBitmap();
		void onShow(int, int, int, int);
		void onMove();
		int getHit(int, int, int, int, int, int, int, bool, int*, vector<Item*>*);
		int Hit(int, int, int, int, int);
	protected:
		CAnimation animationStandR, animationStandL, animationWalkL, animationWalkR, animationHitL, animationHitR, animationDieL, animationDieR, animationSkillL, animationSkillR;
		vector<int> Area, stonex, stoney;
		vector<CMovingBitmap*> stone;
		int direction, state, MapX, MapY, x, y, mh, mw, hp, currentMap, expr, dmg, def, rnd;
		double timer_death, timer_gethit, timer_hit, timer_skill;
		bool skillhit,soundeffect;
	};

	class Map
	{
	public:
		~Map();
		void Initialize(int, int);
		int getInitX();
		int getInitY();
		int getMapX();
		int getMapY();
		int getEdgex1();
		int getEdgex2();
		int scrollRight(int);
		int scrollLeft(int);
		void onShow();
		void itemShow();
		void monsterMove();
		void monsterShow(int);
		int hitMonster(int, int, int, int, int, int, int, bool, int*);
		int Monsterhit(int, int, int, int, int);
		void PickItem(int, int, int, int, vector<Item*>*);
		void setArea(vector<int>*);
		void setLadder(vector<int>*, string);
		int setTeleport(vector<int>*);
		bool isEdge(vector<int>*, string);
		bool isArea(vector<int>*);
		bool isLadder(vector<int>*, string);
		bool isTeleport(vector<int>*);
	protected:
		int MapX, MapY, currentMap, edgex1, edgex2;
		vector<vector<int>> Area;
		vector<vector<int>> Ladder;
		vector<vector<int>> Teleport;
		vector<Monster*> monster;
		vector<Item*> item;
		CMovingBitmap *background = NULL;
		bool floating, music;
		double item_floating;
	};
	class Character
	{
	public:
		~Character();
		int  GetX1();
		int  GetY1();
		int  GetX2();
		int  GetY2();
		int GetFall();
		int LevelUp(int);
		int GetItemSelectIndex();
		int GetHP();
		void Initialize(Map*);
		void Relive();
		void LoadBitmap();
		void MakeFont(int, string);
		void ShowDamageFont();
		void SetBackpack();
		void SetItemSelectIndex(int);
		void SetPick(bool);
		void SetUse(bool);
		void SetMovingDown(bool);
		void SetMovingLeft(bool);
		void SetMovingRight(bool);
		void SetMovingUp(bool);
		void SetAttack(bool, string);
		void SetJump(bool);
		void setEffect();
		void getEffect(string);
		void OnMove();
		void OnShow();
		void Jump(vector<int>*, string);
		bool JudgeArea(vector<int>*, string);
		bool GetBackpack();
	protected:
		CAnimation animationStandR, animationStandL, animationProneR, animationProneL, animationJumpR, animationJumpL, animationWalkR, animationWalkL, animationAttackR, animationAttackL, animationLadder, animationGetHitR, animationGetHitL;
		CAnimation animationSkillQL, animationSkillQR, animationSkillW1, animationSkillW2, animationSkillE;
		CMovingBitmap playerinfo, backpack_ui, itemselected_ui, SkillQ, SkillW, SkillE, SkillR, tomb,expbar;
		vector<CMovingBitmap*> hp_pic, mp_pic, hp_num, hplimit_num, mp_num, mplimit_num, level_num, q_cd_time, w_cd_time, e_cd_time, r_cd_time, exp;
		vector<vector<CMovingBitmap*>> damagefont;
		vector<Item*> backpack;
		vector<Effect*> effect;
		vector<double> damagefont_timer;
		vector<int> pos;
		Map* map;
		int x, y, damage, defense, hp, mp, expr, hp_limit, mp_limit, lvl, onLadder, Fall, direction, supercount;
		int mh, mw, wx, wy, wcount, velocity, initial_velocity, currentMap, itemselectindex;
		int q_mp, w_mp,r_mp;
		double q_timer, w_timer, e_timer,r_timer, mp_timer, hp_timer, hit_timer, q_cd, w_cd, e_cd,r_cd;
		string attackstate;
		bool isMovingDown, isMovingLeft, isMovingRight, isMovingUp, isJump, isAttack, ishit,isProne, openBackpack, pickItem, useItem;
	};

	class CGameStateInit : public CGameState
	{
	public:
		CGameStateInit(CGame* g);
		void OnInit();  								// �C������Ȥιϧγ]�w
		void OnBeginState();							// �]�w�C�������һݪ��ܼ�
		void OnKeyUp(UINT, UINT, UINT); 				// �B�z��LUp���ʧ@
	protected:
		void OnShow();									// ��ܳo�Ӫ��A���C���e��
	private:
		CAnimation title;
	};

	/////////////////////////////////////////////////////////////////////////////
	// �o��class���C�����C�����檫��A�D�n���C���{�����b�o��
	// �C��Member function��Implementation���n����
	/////////////////////////////////////////////////////////////////////////////

	class CGameStateRun : public CGameState
	{
	public:
		CGameStateRun(CGame* g);
		void OnBeginState();							// �]�w�C�������һݪ��ܼ�
		void OnInit();  								// �C������Ȥιϧγ]�w
		void OnKeyDown(UINT, UINT, UINT);
		void OnKeyUp(UINT, UINT, UINT);
	protected:
		void OnMove();									// ���ʹC������
		void OnShow();									// ��ܳo�Ӫ��A���C���e��
	private:
		Character	character;
		Map map;
	};

	/////////////////////////////////////////////////////////////////////////////
	// �o��class���C�����������A(Game Over)
	// �C��Member function��Implementation���n����
	/////////////////////////////////////////////////////////////////////////////

	class CGameStateOver : public CGameState
	{
	public:
		CGameStateOver(CGame* g);
		void OnInit();
	protected:
		void OnShow();									// ��ܳo�Ӫ��A���C���e��
	};

}