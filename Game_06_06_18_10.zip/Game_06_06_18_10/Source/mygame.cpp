#include "stdafx.h"
#include "Resource.h"
#include <mmsystem.h>
#include <ddraw.h>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include "audio.h"
#include "gamelib.h"
#include "mygame.h"

namespace game_framework
{
	Effect::Effect(string name, int time, int num)
	{
		effectname = name;
		effecttime = time;
		effectnum = num;
	}
	string Effect::getName()
	{
		return effectname;
	}
	int Effect::getNum()
	{
		return effectnum;
	}
	int Effect::getTime()
	{
		return effecttime;
	}
	void Effect::setTime(int time)
	{
		effecttime += time;
	}
	Item::Item(int px, int py, string s)
	{
		timer_show = clock();
		x = px;
		y = py;
		name = s;
		num = 1;
		LoadBitmap();
	}
	Item::~Item()
	{
		for (int i = 0; i < (int)numfont.size(); i++)
		{
			delete numfont[i];
		}
	}
	void Item::LoadBitmap()
	{
		if (name == "�����Ĥ�")
		{
			item_pic.LoadBitmap(IDB_potion_red, RGB(0, 255, 0));
		}
		else if (name == "�Ŧ��Ĥ�")
		{
			item_pic.LoadBitmap(IDB_potion_blue, RGB(0, 255, 0));
		}
		else if (name == "�H����C")
		{
			item_pic.LoadBitmap(IDB_sword_0, RGB(0, 255, 0));
		}
		else if (name == "�H��޵P")
		{
			item_pic.LoadBitmap(IDB_shield_0, RGB(0, 255, 0));
		}
		else if (name == "�H��W��")
		{
			item_pic.LoadBitmap(IDB_cloth_0, RGB(0, 255, 0));
		}
	}
	void Item::SetTopLeft(int x1, int y1)
	{
		x = x1;
		y = y1;
	}
	void Item::onShow(int MapX, int MapY, bool floating)
	{
		if (floating)
		{
			item_pic.SetTopLeft(x + MapX, y + MapY - 5);
		}
		else
		{
			item_pic.SetTopLeft(x + MapX, y + MapY);
		}

		item_pic.ShowBitmap();
	}
	int Item::GetX()
	{
		return x;
	}
	int Item::GetY()
	{
		return y;
	}
	int Item::GetWidth()
	{
		return item_pic.Width();
	}
	int Item::GetHeight()
	{
		return item_pic.Height();
	}
	int Item::GetNum()
	{
		return num;
	}
	string Item::GetName()
	{
		return name;
	}
	double Item::GetShowTime()
	{
		return timer_show;
	}
	void Item::SetNum(int n)
	{
		num = n;
	}
	void Item::ShowNum()
	{
		string s = to_string(num);

		for (int i = 0; i < (int)numfont.size(); i++)
		{
			delete numfont[i];
		}

		numfont.clear();

		for (int i = 0; i < (int)s.size(); i++)
		{
			numfont.push_back(new CMovingBitmap);
			numfont[i]->LoadBitmap(335 + s[i] - 48, RGB(0, 255, 0));
			numfont[i]->SetTopLeft(x + 30 - (s.length() - i)*numfont[i]->Width(), y + 30 - numfont[i]->Height());
			numfont[i]->ShowBitmap();
		}
	}
	Monster::Monster(int MapX, int MapY, int dir, vector<int> area, int map, int mexp, int hpnum, int dmgnum, int defnum)
	{
		expr = mexp;
		dmg = dmgnum;
		def = defnum;
		hp = hpnum;
		timer_death = timer_gethit = timer_hit = timer_skill = -1;
		currentMap = map;
		Area = area;
		LoadBitmap();
		x = MapX;
		y = MapY - animationStandR.Height();
		direction = dir;
		stone.clear();
		mh = animationStandR.Height() / 2;
		mw = animationStandR.Width() / 2;

		if (currentMap == 6)
		{
			timer_skill = clock();
			rnd = (rand() % 4 + 1) * 1000;
		}
		else if (currentMap == 7)
		{
			timer_skill = clock();
			rnd = 3000;
		}
	}

	void Monster::LoadBitmap()
	{
		if (currentMap == 1)
		{
			animationStandR.AddBitmap(IDB_11STANDRIGHT_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_11STANDLEFT_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_11MOVERIGHT_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_11MOVERIGHT_1, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_11MOVERIGHT_2, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_11MOVERIGHT_3, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_11MOVERIGHT_4, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_11MOVELEFT_0, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_11MOVELEFT_1, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_11MOVELEFT_2, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_11MOVELEFT_3, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_11MOVELEFT_4, RGB(0, 255, 0));
			animationHitL.AddBitmap(IDB_11HITLEFT_0, RGB(0, 255, 0));
			animationHitR.AddBitmap(IDB_11HITRIGHT_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_1, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_2, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_3, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_4, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_5, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_6, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_7, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_8, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_0, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_1, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_2, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_3, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_4, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_5, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_6, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_7, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_8, RGB(0, 255, 0));
		}
		else if (currentMap == 2)
		{
			animationStandR.AddBitmap(IDB_12STANDRIGHT_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_12STANDLEFT_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_12MOVERIGHT_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_12MOVERIGHT_1, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_12MOVERIGHT_2, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_12MOVELEFT_0, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_12MOVELEFT_1, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_12MOVELEFT_2, RGB(0, 255, 0));
			animationHitL.AddBitmap(IDB_12HITLEFT_0, RGB(0, 255, 0));
			animationHitR.AddBitmap(IDB_12HITRIGHT_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_12DIELEFT_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_12DIELEFT_1, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_12DIELEFT_2, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_12DIERIGHT_0, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_12DIERIGHT_1, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_12DIERIGHT_2, RGB(0, 255, 0));
		}
		else if (currentMap == 3)
		{
			animationStandR.AddBitmap(IDB_14standright_0, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_1, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_2, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_3, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_4, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_5, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_6, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_7, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_8, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_1, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_2, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_3, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_4, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_5, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_6, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_7, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_8, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_14moveright_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_14moveright_1, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_14moveright_2, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_14moveright_3, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_14moveright_4, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_14moveright_5, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_14moveleft_0, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_14moveleft_1, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_14moveleft_2, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_14moveleft_3, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_14moveleft_4, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_14moveleft_5, RGB(0, 255, 0));
			animationHitL.AddBitmap(IDB_14hitleft_0, RGB(0, 255, 0));
			animationHitR.AddBitmap(IDB_14hitright_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_1, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_2, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_3, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_4, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_5, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_6, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_7, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_8, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_0, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_1, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_2, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_3, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_4, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_5, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_6, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_7, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_8, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_0, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_1, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_2, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_3, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_4, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_5, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_6, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_7, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_8, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_9, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_0, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_1, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_2, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_3, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_4, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_5, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_6, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_7, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_8, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_9, RGB(0, 255, 0));
		}
		else if (currentMap == 4)
		{
			animationStandR.AddBitmap(IDB_23standright_0, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_23standright_1, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_23standright_2, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_23standleft_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_23standleft_1, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_23standleft_2, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_23moveright_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_23moveright_1, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_23moveright_2, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_23moveleft_0, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_23moveleft_1, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_23moveleft_2, RGB(0, 255, 0));
			animationHitL.AddBitmap(IDB_23hitleft_0, RGB(0, 255, 0));
			animationHitR.AddBitmap(IDB_23hitright_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_23dieleft_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_23dieleft_1, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_23dieleft_2, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_23dieright_0, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_23dieright_1, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_23dieright_2, RGB(0, 255, 0));
		}
		else if (currentMap == 5)
		{
			animationStandR.AddBitmap(IDB_21standright_0, RGB(255, 0, 0));
			animationStandR.AddBitmap(IDB_21standright_1, RGB(255, 0, 0));
			animationStandR.AddBitmap(IDB_21standright_2, RGB(255, 0, 0));
			animationStandL.AddBitmap(IDB_21standleft_0, RGB(255, 0, 0));
			animationStandL.AddBitmap(IDB_21standleft_1, RGB(255, 0, 0));
			animationStandL.AddBitmap(IDB_21standleft_2, RGB(255, 0, 0));
			animationWalkR.AddBitmap(IDB_21moveright_0, RGB(255, 0, 0));
			animationWalkR.AddBitmap(IDB_21moveright_1, RGB(255, 0, 0));
			animationWalkR.AddBitmap(IDB_21moveright_2, RGB(255, 0, 0));
			animationWalkR.AddBitmap(IDB_21moveright_3, RGB(255, 0, 0));
			animationWalkR.AddBitmap(IDB_21moveright_4, RGB(255, 0, 0));
			animationWalkR.AddBitmap(IDB_21moveright_5, RGB(255, 0, 0));
			animationWalkL.AddBitmap(IDB_21moveleft_0, RGB(255, 0, 0));
			animationWalkL.AddBitmap(IDB_21moveleft_1, RGB(255, 0, 0));
			animationWalkL.AddBitmap(IDB_21moveleft_2, RGB(255, 0, 0));
			animationWalkL.AddBitmap(IDB_21moveleft_3, RGB(255, 0, 0));
			animationWalkL.AddBitmap(IDB_21moveleft_4, RGB(255, 0, 0));
			animationWalkL.AddBitmap(IDB_21moveleft_5, RGB(255, 0, 0));
			animationHitL.AddBitmap(IDB_21hitleft_0, RGB(255, 0, 0));
			animationHitR.AddBitmap(IDB_21hitright_0, RGB(255, 0, 0));
			animationDieL.AddBitmap(IDB_21dieleft_0, RGB(255, 0, 0));
			animationDieL.AddBitmap(IDB_21dieleft_1, RGB(255, 0, 0));
			animationDieL.AddBitmap(IDB_21dieleft_2, RGB(255, 0, 0));
			animationDieL.AddBitmap(IDB_21dieleft_3, RGB(255, 0, 0));
			animationDieR.AddBitmap(IDB_21dieright_0, RGB(255, 0, 0));
			animationDieR.AddBitmap(IDB_21dieright_1, RGB(255, 0, 0));
			animationDieR.AddBitmap(IDB_21dieright_2, RGB(255, 0, 0));
			animationDieR.AddBitmap(IDB_21dieright_3, RGB(255, 0, 0));
		}
		else if (currentMap == 6)
		{
			animationStandR.AddBitmap(IDB_24standright_0, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_24standright_1, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_24standright_2, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_24standright_3, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_24standright_4, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_24standright_5, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_24standleft_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_24standleft_1, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_24standleft_2, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_24standleft_3, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_24standleft_4, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_24standleft_5, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_24moveright_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_24moveright_1, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_24moveright_2, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_24moveright_3, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_24moveright_4, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_24moveright_5, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_24moveleft_0, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_24moveleft_1, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_24moveleft_2, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_24moveleft_3, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_24moveleft_4, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_24moveleft_5, RGB(0, 255, 0));
			animationHitL.AddBitmap(IDB_24hitleft_0, RGB(0, 255, 0));
			animationHitR.AddBitmap(IDB_24hitright_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_1, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_2, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_3, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_4, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_5, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_6, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_7, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_8, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_9, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_10, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_0, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_1, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_2, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_3, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_4, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_5, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_6, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_7, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_8, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_9, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_10, RGB(0, 255, 0));
			animationDieL.SetDelayCount(5);
			animationDieR.SetDelayCount(5);
			animationDieL.Reset();
			animationDieR.Reset();
		}
		else if (currentMap == 7)
		{
			animationStandR.AddBitmap(IDB_31standleft_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_1, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_2, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_3, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_4, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_5, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_6, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_0, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_1, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_2, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_3, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_4, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_5, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_6, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_7, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_8, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_9, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_10, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_11, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_12, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_31dieleft_0, RGB(0, 255, 0));
			animationHitL.AddBitmap(IDB_31dieleft_0, RGB(0, 255, 0));
			animationStandL.SetDelayCount(5);
			animationSkillL.SetDelayCount(5);
			animationStandL.Reset();
			animationSkillL.Reset();
		}
	}

	void Monster::onShow(int Map_X, int Map_Y, int random, int px)
	{
		MapX = Map_X;
		MapY = Map_Y;

		if (clock() - timer_skill == rnd && currentMap == 6)
		{
			skillhit = false;
		}

		if (currentMap == 6 && ((direction == 0 && x + MapX > px) || (direction == 1 && x + MapX < px)))
		{
			timer_skill = clock();
			rnd = (rand() % 4 + 1) * 1000;
		}

		if ((px < x + MapX && currentMap == 6 && hp > 0) || currentMap == 7)
		{
			direction = 1;
		}
		else if (px > x + MapX && currentMap == 6 && hp > 0)
		{
			direction = 0;
		}

		if (clock() - timer_skill >= rnd && currentMap == 6)
		{
			state = 1;
		}
		else if ((clock() - timer_skill < rnd && currentMap == 6) || currentMap == 7)
		{
			state = 0;
		}
		else
		{
			state = random;
		}

		if ((clock() - timer_skill) / CLOCKS_PER_SEC > 15 && timer_skill != -1 && currentMap == 3)
		{
			timer_skill = -1;
			def /= 2;
		}

		if (hp <= 0)
		{
			if (direction == 0)
			{
				if (!animationDieR.IsFinalBitmap())
				{
					animationDieR.SetTopLeft(x + MapX + mw, y + MapY + mh);
					animationDieR.OnShow();
				}
				else if (int(timer_death) == -1)
				{
					timer_death = clock();
				}
				else if ((clock() - timer_death) / CLOCKS_PER_SEC >= 3 && (currentMap == 1 || currentMap == 2 || currentMap == 4 || currentMap == 5))
				{
					srand(x);
					direction = rand() % 2;
					state = rand() % 2;
					x = rand() % (Area[2] - Area[0] - (animationStandR.Width() / 2)) + Area[0];
					timer_death = -1;
					hp = 500;
					animationDieR.Reset();
				}
			}
			else
			{
				if (!animationDieL.IsFinalBitmap())
				{
					animationDieL.SetTopLeft(x + MapX + mw, y + MapY + mh);
					animationDieL.OnShow();
				}
				else if (int(timer_death) == -1)
				{
					timer_death = clock();
				}
				else if ((clock() - timer_death) / CLOCKS_PER_SEC >= 3 && (currentMap == 1 || currentMap == 2 || currentMap == 4 || currentMap == 5))
				{
					srand(x);
					direction = rand() % 2;
					state = rand() % 2;
					x = rand() % (Area[2] - Area[0] - (animationStandR.Width() / 2)) + Area[0];
					timer_death = -1;
					hp = 500;
					animationDieL.Reset();
				}
			}
		}
		else
		{
			if (direction == 0)
			{
				if (timer_gethit != -1 && clock() - timer_gethit <= 350)
				{
					animationHitR.SetTopLeft(x + MapX + mw, y + MapY + mh);
					animationHitR.OnShow();
				}
				else
				{
					timer_gethit = -1;

					if (state == 0)
					{
						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillR.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationSkillR.OnShow();
						}
						else
						{
							animationStandR.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationStandR.OnShow();
						}
					}
					else if (currentMap != 7)
					{
						if (clock() - timer_skill >= rnd && currentMap == 6)
						{
							if (x + (animationStandR.Width() / 2) + 10 < Area[2])
							{
								x += 10;
							}
							else
							{
								direction = 1;
								x -= 10;
							}
						}
						else if (x + (animationStandR.Width() / 2) + 1 < Area[2])
						{
							x += 1;
						}
						else
						{
							direction = 1;
							x -= 1;
						}

						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillR.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationSkillR.OnShow();
						}
						else
						{
							animationWalkR.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationWalkR.OnShow();
						}
					}
				}
			}
			else
			{
				if (timer_gethit != -1 && clock() - timer_gethit <= 350)
				{
					animationHitL.SetTopLeft(x + MapX + mw, y + MapY + mh);
					animationHitL.OnShow();
				}
				else
				{
					timer_gethit = -1;

					if (state == 0)
					{
						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillL.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationSkillL.OnShow();
						}
						else if (clock() - timer_skill >= rnd && currentMap == 7)
						{
							if (stone.empty())
							{
								animationSkillL.SetTopLeft(x + MapX + mw, y + MapY + mh);
								animationSkillL.OnShow();
							}
							else
							{
								animationStandL.SetTopLeft(x + MapX + mw, y + MapY + mh);
								animationStandL.OnShow();

								if (stone[0]->Top() + stone[0]->Height() >= Area[1])
								{
									for (int i = 0; i < (int)stone.size(); i++)
									{
										delete stone[i];
									}

									stone.clear();
									stonex.clear();
									stoney.clear();
									timer_skill = clock();
								}
								else
								{
									for (int i = 0; i < (int)stone.size(); i++)
									{
										stoney[i] += 20;
										stone[i]->SetTopLeft(stonex[i] + MapX, stoney[i] + MapY);
										stone[i]->ShowBitmap();
									}
								}
							}
						}
						else
						{
							animationStandL.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationStandL.OnShow();
						}
					}
					else if (currentMap != 7)
					{
						if (clock() - timer_skill >= rnd && currentMap == 6)
						{
							if (x + (animationStandR.Width() / 2) - 10 > Area[0])
							{
								x -= 10;
							}
							else
							{
								direction = 0;
								x += 10;
							}
						}
						else if (x + (animationStandR.Width() / 2) - 1 > Area[0])
						{
							x -= 1;
						}
						else
						{
							direction = 0;
							x += 1;
						}

						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillL.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationSkillL.OnShow();
						}
						else
						{
							animationWalkL.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationWalkL.OnShow();
						}
					}
				}
			}
		}
	}

	void Monster::onMove()
	{
		if (hp <= 0)
		{
			if (direction == 0)
			{
				if (!animationDieR.IsFinalBitmap())
				{
					animationDieR.OnMove();
				}
			}
			else
			{
				if (!animationDieL.IsFinalBitmap())
				{
					animationDieL.OnMove();
				}
			}
		}
		else
		{
			if (direction == 0)
			{
				if (timer_gethit != -1 && clock() - timer_gethit <= 350)
				{
					animationHitR.OnMove();
				}
				else
				{
					timer_gethit = -1;

					if (state == 0)
					{
						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillR.OnMove();
						}
						else
						{
							animationStandR.OnMove();
						}
					}
					else
					{
						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillR.OnMove();
						}
						else
						{
							animationWalkR.OnMove();
						}
					}
				}
			}
			else
			{
				if (timer_gethit != -1 && clock() - timer_gethit <= 350)
				{
					animationHitL.OnMove();
				}
				else
				{
					timer_gethit = -1;

					if (state == 0)
					{
						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillL.OnMove();
						}
						else if (clock() - timer_skill >= rnd && currentMap == 7)
						{
							if (stone.empty())
							{
								animationSkillL.OnMove();

								if (animationSkillL.IsFinalBitmap())
								{
									srand((unsigned)time(NULL));

									for (int i = rand() % 202; i <= Area[2]; i += 125)
									{
										stone.push_back(new CMovingBitmap);
										stonex.push_back(i);
										stoney.push_back(0);
										stone[(int)stone.size() - 1]->LoadBitmap(IDB_stone, RGB(0, 255, 0));
										stone[(int)stone.size() - 1]->SetTopLeft(stonex[(int)stonex.size() - 1] + MapX, stoney[(int)stoney.size() - 1] + MapY);
										stone[(int)stone.size() - 1]->ShowBitmap();
									}

									skillhit = false;
									animationSkillL.Reset();
								}
							}
							else
							{
								animationStandL.OnMove();
							}
						}
						else
						{
							animationStandL.OnMove();
						}
					}
					else
					{
						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillL.OnMove();
						}
						else
						{
							animationWalkL.OnMove();
						}
					}
				}
			}
		}
	}

	int Monster::getHit(int cx, int cy, int skillx1, int skilly1, int skillx2, int skilly2, int damage, bool finalbitmap, int* totaldamage, vector<Item*>* item)
	{
		bool flag = false;
		int srcx = x + MapX + (animationStandR.Width() / 2);

		for (int k = y + MapY; k <= y + MapY + animationStandR.Height(); k++)
		{
			if (srcx >= skillx1 && srcx <= skillx2 && k >= skilly1 && k <= skilly2)
			{
				flag = true;
				break;
			}
		}

		if (flag)
		{
			if (timer_gethit == -1)
			{
				timer_gethit = clock();

				if (srcx > cx)
				{
					x += 25;

					if (x > Area[2])
					{
						x = Area[2];
					}
				}
				else
				{
					x -= 25;

					if (x < Area[0])
					{
						x = Area[0];
					}
				}
			}

			if (finalbitmap)
			{
				if (hp > 0 && damage > def)
				{
					(*totaldamage) = (*totaldamage) + (damage - def);
					hp = hp - (damage - def);

					if (damage - def > 0 && timer_skill == -1 && currentMap == 3)
					{
						timer_skill = clock();
						def *= 2;
					}

					if (hp <= 0)
					{
						int itemnum, itemtype, potiontype;
						srand(x);

						if (currentMap == 1 || currentMap == 2)
						{
							itemnum = rand() % 2 + 1;

							for (int i = 0; i < itemnum; i++)
							{
								itemtype = rand() % 100;

								if (itemtype >= 0 && itemtype < 70)
								{
									potiontype = rand() % 2;

									if (potiontype == 0)
									{
										item->push_back(new Item(x + 35 * i, Area[1] - 30, "�����Ĥ�"));
									}
									else
									{
										item->push_back(new Item(x + 35 * i, Area[1] - 30, "�Ŧ��Ĥ�"));
									}
								}
								else if (itemtype >= 70 && itemtype < 80)
								{
									item->push_back(new Item(x + 35 * i, Area[1] - 30, "�H����C"));
								}
								else if (itemtype >= 80 && itemtype < 90)
								{
									item->push_back(new Item(x + 35 * i, Area[1] - 30, "�H��޵P"));
								}
								else if (itemtype >= 90 && itemtype < 100)
								{
									item->push_back(new Item(x + 35 * i, Area[1] - 30, "�H��W��"));
								}
							}
						}

						return expr;
					}
				}
			}
		}

		return 0;
	}

	int Monster::Hit(int x1, int y1, int x2, int y2, int def)
	{
		bool flag = false;
		int srcx;

		if (direction == 0)
		{
			srcx = x + animationStandR.Width() + MapX;
		}
		else
		{
			srcx = x + MapX;
		}

		for (int i = y + MapY; i <= y + MapY + animationStandR.Height(); i++)
		{
			if (srcx >= x1 && srcx <= x2 && i >= y1 && i <= y2)
			{
				flag = true;
				break;
			}
		}

		if (currentMap == 6 && hp > 0 && flag && !skillhit)
		{
			skillhit = true;
			return dmg - def;
		}
		else if (currentMap == 7)
		{
			for (int i = 0; i < (int)stone.size(); i++)
			{
				flag = false;
				srcx = stone[i]->Left() + stone[i]->Width() / 2 + MapX;

				for (int j = stone[i]->Top() + MapY; j <= stone[i]->Top() + stone[i]->Height() + MapY; j++)
				{
					if (srcx >= x1 && srcx <= x2 && j >= y1 && j <= y2)
					{
						flag = true;
						break;
					}
				}

				if (hp > 0 && flag && !skillhit)
				{
					skillhit = true;
					return 500 - def;
				}
			}
		}
		else if (hp > 0 && clock() - timer_hit >= 3000 && flag)
		{
			timer_hit = clock();
			return dmg - def;
		}

		return 0;
	}

	Map::~Map()
	{
		for (int i = 0; i < (int)monster.size(); i++)
		{
			delete monster[i];
		}

		for (int i = 0; i < (int)item.size(); i++)
		{
			delete item[i];
		}

		delete background;
	}
	void Map::Initialize(int map, int tmp)
	{
		vector<int> Areaxy;
		vector<int> Ladderxy;
		vector<int> Teleportxy;
		int random;
		currentMap = map;
		Area.clear();
		Ladder.clear();
		Teleport.clear();
		music = floating = false;
		item_floating = -1;

		for (int i = 0; i < int(monster.size()); i++)
		{
			delete monster[i];
		}

		monster.clear();

		if (background != NULL)
		{
			delete background;
		}

		for (int i = 0; i < int(item.size()); i++)
		{
			delete item[i];
		}

		item.clear();

		if (currentMap == 0)
		{
			Areaxy.clear();
			Areaxy.push_back(80);
			Areaxy.push_back(440);
			Areaxy.push_back(715);
			Areaxy.push_back(440);
			Area.push_back(Areaxy);
			Teleportxy.clear();
			Teleportxy.push_back(650);
			Teleportxy.push_back(440);
			Teleportxy.push_back(715);
			Teleportxy.push_back(440);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map01);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];
		}
		else if (currentMap == 1)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(610);
			Areaxy.push_back(1985);
			Areaxy.push_back(610);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(313);
			Areaxy.push_back(610);
			Areaxy.push_back(313);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(630);
			Areaxy.push_back(363);
			Areaxy.push_back(1130);
			Areaxy.push_back(363);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(480);
			Areaxy.push_back(116);
			Areaxy.push_back(1057);
			Areaxy.push_back(116);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(1075);
			Areaxy.push_back(165);
			Areaxy.push_back(1796);
			Areaxy.push_back(165);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(1667);
			Areaxy.push_back(313);
			Areaxy.push_back(1985);
			Areaxy.push_back(313);
			Area.push_back(Areaxy);
			Ladderxy.clear();
			Ladderxy.push_back(260);
			Ladderxy.push_back(313);
			Ladderxy.push_back(292);
			Ladderxy.push_back(495);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(575);
			Ladderxy.push_back(116);
			Ladderxy.push_back(607);
			Ladderxy.push_back(220);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(994);
			Ladderxy.push_back(116);
			Ladderxy.push_back(1026);
			Ladderxy.push_back(250);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(769);
			Ladderxy.push_back(363);
			Ladderxy.push_back(801);
			Ladderxy.push_back(495);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(1684);
			Ladderxy.push_back(165);
			Ladderxy.push_back(1716);
			Ladderxy.push_back(222);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(1772);
			Ladderxy.push_back(313);
			Ladderxy.push_back(1804);
			Ladderxy.push_back(495);
			Ladder.push_back(Ladderxy);
			Teleportxy.clear();
			Teleportxy.push_back(25);
			Teleportxy.push_back(610);
			Teleportxy.push_back(95);
			Teleportxy.push_back(610);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			Teleportxy.clear();
			Teleportxy.push_back(1895);
			Teleportxy.push_back(610);
			Teleportxy.push_back(1965);
			Teleportxy.push_back(610);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map11);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];

			for (int i = 0; i < int(Area.size()); i++)
			{
				srand((unsigned)time(NULL));

				for (int j = Area[i][0]; j < Area[i][2]; j += random)
				{
					random = rand() % 2;
					monster.push_back(new Monster(j, Area[i][1], random, Area[i], currentMap, 10, 150, 30, 5));
					random = rand() % 50 + 70;
				}
			}
		}
		else if (currentMap == 2)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(628);
			Areaxy.push_back(1500);
			Areaxy.push_back(628);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(32);
			Areaxy.push_back(363);
			Areaxy.push_back(412);
			Areaxy.push_back(363);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(428);
			Areaxy.push_back(408);
			Areaxy.push_back(940);
			Areaxy.push_back(408);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(1023);
			Areaxy.push_back(408);
			Areaxy.push_back(1500);
			Areaxy.push_back(408);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(33);
			Areaxy.push_back(145);
			Areaxy.push_back(413);
			Areaxy.push_back(145);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(429);
			Areaxy.push_back(189);
			Areaxy.push_back(940);
			Areaxy.push_back(189);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(956);
			Areaxy.push_back(144);
			Areaxy.push_back(1335);
			Areaxy.push_back(144);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(1285);
			Areaxy.push_back(57);
			Areaxy.push_back(1467);
			Areaxy.push_back(57);
			Area.push_back(Areaxy);
			Ladderxy.clear();
			Ladderxy.push_back(299);
			Ladderxy.push_back(363);
			Ladderxy.push_back(327);
			Ladderxy.push_back(525);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(602);
			Ladderxy.push_back(408);
			Ladderxy.push_back(630);
			Ladderxy.push_back(525);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(1141);
			Ladderxy.push_back(408);
			Ladderxy.push_back(1169);
			Ladderxy.push_back(525);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(225);
			Ladderxy.push_back(145);
			Ladderxy.push_back(253);
			Ladderxy.push_back(264);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(743);
			Ladderxy.push_back(189);
			Ladderxy.push_back(771);
			Ladderxy.push_back(307);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(1244);
			Ladderxy.push_back(144);
			Ladderxy.push_back(1272);
			Ladderxy.push_back(319);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(1337);
			Ladderxy.push_back(57);
			Ladderxy.push_back(1365);
			Ladderxy.push_back(93);
			Ladder.push_back(Ladderxy);
			Teleportxy.clear();
			Teleportxy.push_back(25);
			Teleportxy.push_back(628);
			Teleportxy.push_back(95);
			Teleportxy.push_back(628);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			Teleportxy.clear();
			Teleportxy.push_back(1420);
			Teleportxy.push_back(628);
			Teleportxy.push_back(1490);
			Teleportxy.push_back(628);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map12);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];

			for (int i = 0; i < int(Area.size()); i++)
			{
				srand((unsigned)time(NULL));

				for (int j = Area[i][0]; j < Area[i][2]; j += random)
				{
					random = rand() % 2;
					monster.push_back(new Monster(j, Area[i][1], random, Area[i], currentMap, 25, 350, 50, 15));
					random = rand() % 50 + 70;
				}
			}
		}
		else if (currentMap == 3)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(567);
			Areaxy.push_back(434);
			Areaxy.push_back(567);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(435);
			Areaxy.push_back(567);
			Areaxy.push_back(530);
			Areaxy.push_back(508);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(531);
			Areaxy.push_back(508);
			Areaxy.push_back(1420);
			Areaxy.push_back(508);
			Area.push_back(Areaxy);
			Teleportxy.clear();
			Teleportxy.push_back(20);
			Teleportxy.push_back(567);
			Teleportxy.push_back(95);
			Teleportxy.push_back(567);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			Teleportxy.clear();
			Teleportxy.push_back(1345);
			Teleportxy.push_back(508);
			Teleportxy.push_back(1420);
			Teleportxy.push_back(508);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map14);
			edgex1 = Area[0][0];
			edgex2 = Area[2][2];
			monster.push_back(new Monster(Area[2][0], Area[2][1], 0, Area[2], currentMap, 500, 900, 150, 100));
		}
		else if (currentMap == 4)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(595);
			Areaxy.push_back(1805);
			Areaxy.push_back(595);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(240);
			Areaxy.push_back(355);
			Areaxy.push_back(655);
			Areaxy.push_back(355);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(690);
			Areaxy.push_back(295);
			Areaxy.push_back(1195);
			Areaxy.push_back(295);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(175);
			Areaxy.push_back(295);
			Areaxy.push_back(175);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(330);
			Areaxy.push_back(115);
			Areaxy.push_back(835);
			Areaxy.push_back(115);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(1230);
			Areaxy.push_back(355);
			Areaxy.push_back(1555);
			Areaxy.push_back(355);
			Area.push_back(Areaxy);
			Ladderxy.clear();
			Ladderxy.push_back(435);
			Ladderxy.push_back(355);
			Ladderxy.push_back(480);
			Ladderxy.push_back(515);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(240);
			Ladderxy.push_back(175);
			Ladderxy.push_back(285);
			Ladderxy.push_back(275);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(705);
			Ladderxy.push_back(115);
			Ladderxy.push_back(750);
			Ladderxy.push_back(215);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(1025);
			Ladderxy.push_back(295);
			Ladderxy.push_back(1070);
			Ladderxy.push_back(500);
			Ladder.push_back(Ladderxy);
			Teleportxy.clear();
			Teleportxy.push_back(25);
			Teleportxy.push_back(595);
			Teleportxy.push_back(100);
			Teleportxy.push_back(595);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			Teleportxy.clear();
			Teleportxy.push_back(1715);
			Teleportxy.push_back(595);
			Teleportxy.push_back(1790);
			Teleportxy.push_back(595);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map23);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];

			for (int i = 0; i < int(Area.size()); i++)
			{
				srand((unsigned)time(NULL));

				for (int j = Area[i][0]; j < Area[i][2]; j += random)
				{
					random = rand() % 2;
					monster.push_back(new Monster(j, Area[i][1], random, Area[i], currentMap, 50, 500, 75, 30));
					random = rand() % 80 + 90;
				}
			}
		}
		else if (currentMap == 5)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(622);
			Areaxy.push_back(1199);
			Areaxy.push_back(622);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(385);
			Areaxy.push_back(1119);
			Areaxy.push_back(385);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(145);
			Areaxy.push_back(849);
			Areaxy.push_back(145);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(885);
			Areaxy.push_back(145);
			Areaxy.push_back(939);
			Areaxy.push_back(145);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(975);
			Areaxy.push_back(145);
			Areaxy.push_back(1029);
			Areaxy.push_back(145);
			Area.push_back(Areaxy);
			Ladderxy.clear();
			Ladderxy.push_back(378);
			Ladderxy.push_back(385);
			Ladderxy.push_back(410);
			Ladderxy.push_back(515);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(800);
			Ladderxy.push_back(385);
			Ladderxy.push_back(832);
			Ladderxy.push_back(515);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(261);
			Ladderxy.push_back(145);
			Ladderxy.push_back(293);
			Ladderxy.push_back(272);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(581);
			Ladderxy.push_back(145);
			Ladderxy.push_back(613);
			Ladderxy.push_back(272);
			Ladder.push_back(Ladderxy);
			Teleportxy.clear();
			Teleportxy.push_back(15);
			Teleportxy.push_back(145);
			Teleportxy.push_back(86);
			Teleportxy.push_back(145);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			Teleportxy.clear();
			Teleportxy.push_back(1127);
			Teleportxy.push_back(622);
			Teleportxy.push_back(1198);
			Teleportxy.push_back(622);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map22);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];

			for (int i = 0; i < int(Area.size()); i++)
			{
				srand((unsigned)time(NULL));

				for (int j = Area[i][0]; j < Area[i][2]; j += random)
				{
					random = rand() % 2;
					monster.push_back(new Monster(j, Area[i][1], random, Area[i], currentMap, 50, 500, 75, 30));
					random = rand() % 80 + 90;
				}
			}
		}
		else if (currentMap == 6)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(660);
			Areaxy.push_back(1190);
			Areaxy.push_back(660);
			Area.push_back(Areaxy);
			Teleportxy.clear();
			Teleportxy.push_back(10);
			Teleportxy.push_back(660);
			Teleportxy.push_back(85);
			Teleportxy.push_back(660);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			Teleportxy.clear();
			Teleportxy.push_back(1113);
			Teleportxy.push_back(660);
			Teleportxy.push_back(1188);
			Teleportxy.push_back(660);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map24);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];
			monster.push_back(new Monster((Area[0][3] - Area[0][0]) / 2, Area[0][1], 1, Area[0], currentMap, 500, 1, 150, 0));
		}
		else if (currentMap == 7)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(625);
			Areaxy.push_back(1326);
			Areaxy.push_back(626);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(390);
			Areaxy.push_back(565);
			Areaxy.push_back(1020);
			Areaxy.push_back(565);
			Area.push_back(Areaxy);
			Teleportxy.clear();
			Teleportxy.push_back(15);
			Teleportxy.push_back(625);
			Teleportxy.push_back(80);
			Teleportxy.push_back(625);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map31);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];
			monster.push_back(new Monster(528, 525, 1, Area[0], currentMap, 500, 1, 150, 0));
		}

		if (background->Width() < 1024)
		{
			MapX = (1024 - background->Width()) / 2;
		}
		else if (tmp > 0)
		{
			MapX = 0;
		}
		else
		{
			MapX = 1024 - background->Width();
		}

		if (background->Height() < 768)
		{
			MapY = (768 - background->Height()) / 2;
		}
		else
		{
			MapY = 768 - background->Height();
		}

		background->SetTopLeft(MapX, MapY);
	}

	int Map::getInitX()
	{
		return 350;
	}

	int Map::getInitY()
	{
		return Area[0][1];
	}

	int Map::getMapX()
	{
		return MapX;
	}

	int Map::getMapY()
	{
		return MapY;
	}

	int Map::scrollRight()
	{
		int step;

		if (background->Width() + MapX - 5 > 1024)
		{
			MapX -= 5;
			background->SetTopLeft(MapX, MapY);
			background->ShowBitmap();
			step = 0;
		}
		else if (background->Width() + MapX > 1024)
		{
			step = 5 - ((background->Width() + MapX) - 1024);
			MapX = 1024 - background->Width();
			background->SetTopLeft(MapX, MapY);
			background->ShowBitmap();
		}
		else
		{
			step = 5;
		}

		return step;
	}

	int Map::scrollLeft()
	{
		int step;

		if (MapX + 5 < 0)
		{
			MapX += 5;
			background->SetTopLeft(MapX, MapY);
			background->ShowBitmap();
			step = 0;
		}
		else if (MapX < 0)
		{
			step = 5 + MapX;
			MapX = 0;
			background->SetTopLeft(MapX, MapY);
			background->ShowBitmap();
		}
		else
		{
			step = 5;
		}

		return step;
	}

	void Map::onShow()
	{
		/*if (!music) {
			for (int i = 0; i < 4; i++) {
				CAudio::Instance()->Stop(i);
			}
			CAudio::Instance()->Play(currentMap + 1, true);
			music = true;
		}*/
		background->ShowBitmap();
	}

	void Map::itemShow()
	{
		int del = -1;

		if (clock() - item_floating >= 500)
		{
			floating = !floating;
			item_floating = clock();
		}

		for (int i = 0; i < (int)item.size(); i++)
		{
			if (clock() - item[i]->GetShowTime() >= 10000)
			{
				del = i;
			}
		}

		if (del != -1)
		{
			for (int i = 0; i < del; i++)
			{
				delete item[i];
			}

			item.erase(item.begin(), item.begin() + del + 1);
		}

		for (int i = 0; i < (int)item.size(); i++)
		{
			item[i]->onShow(MapX, MapY, floating);
		}
	}

	void Map::monsterMove()
	{
		for (int i = 0; i < int(monster.size()); i++)
		{
			monster[i]->onMove();
		}
	}

	void Map::monsterShow(int px)
	{
		srand((unsigned)time(NULL));

		for (int i = 0; i < int(monster.size()); i++)
		{
			monster[i]->onShow(MapX, MapY, rand() % 5, px);
		}
	}

	int Map::hitMonster(int cx, int cy, int skillx1, int skilly1, int skillx2, int skilly2, int damage, bool finalbitmap, int* totaldamage)
	{
		int expr = 0;

		for (int i = 0; i < int(monster.size()); i++)
		{
			expr += monster[i]->getHit(cx, cy, skillx1, skilly1, skillx2, skilly2, damage, finalbitmap, totaldamage, &item);
		}

		return expr;
	}

	int Map::Monsterhit(int x1, int y1, int x2, int y2, int def)
	{
		int damage = 0;

		for (int i = 0; i < int(monster.size()); i++)
		{
			damage += monster[i]->Hit(x1, y1, x2, y2, def);
		}

		return damage;
	}

	void Map::PickItem(int x, int y, int w, int h, vector<Item*>* backpack)
	{
		vector<int> del;

		for (int i = 0; i < (int)item.size(); i++)
		{
			if (item[i]->GetX() + item[i]->GetWidth() / 2 >= x && item[i]->GetX() + item[i]->GetWidth() / 2 <= x + w && item[i]->GetY() + item[i]->GetHeight() / 2 >= y && item[i]->GetY() + item[i]->GetHeight() / 2 <= y + h)
			{
				backpack->push_back(item[i]);
				del.push_back(i);
			}
		}

		for (int i = (int)del.size() - 1; i >= 0; i--)
		{
			item.erase(item.begin() + del[i]);
		}
	}

	void Map::setArea(vector<int>* pos)
	{
		double y = 0;

		for (int i = 0; i < int(Area.size()); i++)
		{
			if ((*pos)[0] - MapX + 34 >= Area[i][0] && (*pos)[0] - MapX + 34 <= Area[i][2])
			{
				if (Area[i][1] != Area[i][3])
				{
					y = double((*pos)[0] - MapX + 34 - Area[i][0]) * double(Area[i][3] - Area[i][1]) / double(Area[i][2] - Area[i][0]);
					y = (int)y + Area[i][1];
				}
				else
				{
					y = Area[i][1];
				}

				if ((abs((*pos)[1] - MapY - (y - 70)) <= 15))
				{
					(*pos)[1] = (int)y + MapY - 70;
				}
			}
		}
	}

	void Map::setLadder(vector<int>* pos, string position)
	{
		if (position == "up")
		{
			for (int i = 0; i < int(Ladder.size()); i++)
			{
				if ((*pos)[0] - MapX + 34 >= Ladder[i][0] && (*pos)[0] - MapX + 34 <= Ladder[i][2] && (*pos)[1] - MapY >= Ladder[i][1] && (*pos)[1] - MapY <= Ladder[i][3])
				{
					(*pos)[0] = Ladder[i][0] + MapX - (62 - (Ladder[i][2] - Ladder[i][0])) / 2 - 7;
				}
			}
		}
		else
		{
			for (int i = 0; i < int(Ladder.size()); i++)
			{
				if ((*pos)[0] - MapX + 34 >= Ladder[i][0] && (*pos)[0] - MapX + 34 <= Ladder[i][2] && (*pos)[1] - MapY + 70 >= Ladder[i][1] && (*pos)[1] - MapY + 70 <= Ladder[i][3])
				{
					(*pos)[0] = Ladder[i][0] + MapX - (62 - (Ladder[i][2] - Ladder[i][0])) / 2 - 7;
					(*pos)[1] += 15;
				}
			}
		}
	}

	int Map::setTeleport(vector<int>* pos)
	{
		int tmp;

		for (int i = 0; i < int(Teleport.size()); i++)
		{
			if ((*pos)[0] - MapX + 34 >= Teleport[i][0] && (*pos)[0] - MapX + 34 <= Teleport[i][2] && (abs((*pos)[1] - MapY - (Teleport[i][1] - 70)) <= 10))
			{
				tmp = Teleport[i][4];
				//CAudio::Instance()->Stop(currentMap);
				currentMap += tmp;
				Initialize(currentMap, tmp);

				if (tmp > 0 || currentMap == 0)
				{
					(*pos)[0] = Teleport[0][0] + MapX;
					(*pos)[1] = Teleport[0][1] + MapY - 70;
				}
				else
				{
					(*pos)[0] = Teleport[(int)Teleport.size() - 1][0] + MapX;
					(*pos)[1] = Teleport[(int)Teleport.size() - 1][1] + MapY - 70;
				}

				break;
			}
		}

		return currentMap;
	}

	bool Map::isEdge(vector<int>* pos, string direction)
	{
		if ((*pos)[0] - MapX + 34 - 5 < edgex1 && direction == "left")
		{
			(*pos)[0] = edgex1 + MapX - 34;
			return true;
		}
		else if ((*pos)[0] - MapX + 34 + 5 > edgex2 && direction == "right")
		{
			(*pos)[0] = edgex2 + MapX - 34;
			return true;
		}

		return false;
	}

	bool Map::isArea(vector<int>* pos)
	{
		double y = 0;

		for (int i = 0; i < int(Area.size()); i++)
		{
			if ((*pos)[0] - MapX + 34 >= Area[i][0] && (*pos)[0] - MapX + 34 <= Area[i][2])
			{
				if (Area[i][1] != Area[i][3])
				{
					y = double((*pos)[0] - MapX + 34 - Area[i][0]) * double(Area[i][3] - Area[i][1]) / double(Area[i][2] - Area[i][0]);
					y = (int)y + Area[i][1];
				}
				else
				{
					y = Area[i][1];
				}

				if ((abs((*pos)[1] - MapY - (y - 70)) <= 15))
				{
					setArea(pos);
					return true;
				}
			}
		}

		return false;
	}

	bool Map::isLadder(vector<int>* pos, string position)
	{
		if (position == "up")
		{
			for (int i = 0; i < int(Ladder.size()); i++)
			{
				if ((*pos)[0] - MapX + 34 >= Ladder[i][0] && (*pos)[0] - MapX + 34 <= Ladder[i][2] && (*pos)[1] - MapY >= Ladder[i][1] && (*pos)[1] - MapY <= Ladder[i][3])
				{
					return true;
				}
			}
		}
		else
		{
			for (int i = 0; i < int(Ladder.size()); i++)
			{
				if ((*pos)[0] - MapX + 34 >= Ladder[i][0] && (*pos)[0] - MapX + 34 <= Ladder[i][2] && (*pos)[1] - MapY + 70 >= Ladder[i][1] && (*pos)[1] - MapY + 70 <= Ladder[i][3])
				{
					return true;
				}
			}
		}

		return false;
	}

	bool Map::isTeleport(vector<int>* pos)
	{
		for (int i = 0; i < int(Teleport.size()); i++)
		{
			if ((*pos)[0] - MapX + 34 >= Teleport[i][0] && (*pos)[0] - MapX + 34 <= Teleport[i][2] && (abs((*pos)[1] - MapY - (Teleport[i][1] - 70)) <= 10))
			{
				return true;
			}
		}

		return false;
	}

	Character::~Character()
	{
		for (int i = 0; i < (int)backpack.size(); i++)
		{
			delete backpack[i];
		}

		for (int i = 0; i < (int)effect.size(); i++)
		{
			delete effect[i];
		}

		for (int i = 0; i < (int)hp_pic.size(); i++)
		{
			delete hp_pic[i];
		}

		for (int i = 0; i < (int)mp_pic.size(); i++)
		{
			delete mp_pic[i];
		}

		for (int i = 0; i < (int)level_num.size(); i++)
		{
			delete level_num[i];
		}

		for (int i = 0; i < (int)hp_num.size(); i++)
		{
			delete hp_num[i];
		}

		for (int i = 0; i < (int)hplimit_num.size(); i++)
		{
			delete hplimit_num[i];
		}

		for (int i = 0; i < (int)mp_num.size(); i++)
		{
			delete mp_num[i];
		}

		for (int i = 0; i < (int)mplimit_num.size(); i++)
		{
			delete mplimit_num[i];
		}

		for (int i = 0; i < (int)q_cd_time.size(); i++)
		{
			delete q_cd_time[i];
		}

		for (int i = 0; i < (int)w_cd_time.size(); i++)
		{
			delete w_cd_time[i];
		}

		for (int i = 0; i < (int)e_cd_time.size(); i++)
		{
			delete e_cd_time[i];
		}

		for (int i = 0; i < (int)damagefont.size(); i++)
		{
			for (int j = 0; j < (int)damagefont[i].size(); j++)
			{
				delete damagefont[i][j];
			}
		}
	}

	int Character::GetX1()
	{
		return x;
	}

	int Character::GetY1()
	{
		return y;
	}

	int Character::GetX2()
	{
		return x + animationStandR.Width();
	}

	int Character::GetY2()
	{
		return y + animationStandR.Height();
	}

	int Character::GetFall()
	{
		return Fall;
	}
	int Character::LevelUp(int lvl)
	{
		if (lvl == 1)
		{
			return 100;
		}
		else
		{
			return LevelUp(lvl - 1) + 200;
		}
	}
	int Character::GetItemSelectIndex()
	{
		return itemselectindex;
	}
	void Character::Initialize(Map* MAP)
	{
		map = MAP;
		damage = defense = 0;
		lvl = 1;
		hp = hp_limit = 750;
		mp = mp_limit = 450;
		q_mp = 30;
		w_mp = 150;
		hp_timer = mp_timer = q_timer = w_timer = e_timer = -1;
		supercount = wcount = -1;
		q_cd = 300;
		w_cd = 2000;
		e_cd = 15000;
		velocity = initial_velocity = 12;
		Fall = onLadder = direction = currentMap = expr = itemselectindex = 0;
		openBackpack = pickItem = useItem = isJump = isMovingLeft = isMovingRight = isMovingUp = isMovingDown = isAttack = false;
		map->Initialize(currentMap, 1);
		mh = animationStandR.Height() / 2;
		mw = animationStandR.Width() / 2;
		x = map->getInitX() + map->getMapX();
		y = map->getInitY() + map->getMapY() - 70;
	}

	void Character::LoadBitmap()
	{
		playerinfo.LoadBitmap(IDB_playerinfo, RGB(0, 255, 0));

		for (int i = 0; i < 100; i++)
		{
			hp_pic.push_back(new CMovingBitmap);
			mp_pic.push_back(new CMovingBitmap);
			hp_pic[i]->LoadBitmap(IDB_hp, RGB(0, 255, 0));
			mp_pic[i]->LoadBitmap(IDB_mp, RGB(0, 255, 0));
		}

		backpack_ui.LoadBitmap(IDB_backpack_ui);
		itemselected_ui.LoadBitmap(IDB_ItemSelectedUI, RGB(255, 255, 255));
		animationStandR.AddBitmap(IDB_standright_0, RGB(0, 255, 0));
		animationStandR.AddBitmap(IDB_standright_1, RGB(0, 255, 0));
		animationStandR.AddBitmap(IDB_standright_2, RGB(0, 255, 0));
		animationStandR.AddBitmap(IDB_standright_3, RGB(0, 255, 0));
		animationStandL.AddBitmap(IDB_standleft_0, RGB(0, 255, 0));
		animationStandL.AddBitmap(IDB_standleft_1, RGB(0, 255, 0));
		animationStandL.AddBitmap(IDB_standleft_2, RGB(0, 255, 0));
		animationStandL.AddBitmap(IDB_standleft_3, RGB(0, 255, 0));
		animationProneR.AddBitmap(IDB_proneright_0, RGB(0, 255, 0));
		animationProneL.AddBitmap(IDB_proneleft_0, RGB(0, 255, 0));
		animationJumpR.AddBitmap(IDB_jumpright_0, RGB(0, 255, 0));
		animationJumpL.AddBitmap(IDB_jumpleft_0, RGB(0, 255, 0));
		animationWalkR.AddBitmap(IDB_walkright_0, RGB(0, 255, 0));
		animationWalkR.AddBitmap(IDB_walkright_1, RGB(0, 255, 0));
		animationWalkR.AddBitmap(IDB_walkright_2, RGB(0, 255, 0));
		animationWalkR.AddBitmap(IDB_walkright_3, RGB(0, 255, 0));
		animationWalkL.AddBitmap(IDB_walkleft_0, RGB(0, 255, 0));
		animationWalkL.AddBitmap(IDB_walkleft_1, RGB(0, 255, 0));
		animationWalkL.AddBitmap(IDB_walkleft_2, RGB(0, 255, 0));
		animationWalkL.AddBitmap(IDB_walkleft_3, RGB(0, 255, 0));
		animationAttackR.AddBitmap(IDB_attackright_0, RGB(0, 255, 0));
		animationAttackR.AddBitmap(IDB_attackright_1, RGB(0, 255, 0));
		animationAttackR.AddBitmap(IDB_attackright_2, RGB(0, 255, 0));
		animationAttackL.AddBitmap(IDB_attackleft_0, RGB(0, 255, 0));
		animationAttackL.AddBitmap(IDB_attackleft_1, RGB(0, 255, 0));
		animationAttackL.AddBitmap(IDB_attackleft_2, RGB(0, 255, 0));
		animationLadder.AddBitmap(IDB_ladder_0, RGB(0, 255, 0));
		animationLadder.AddBitmap(IDB_ladder_1, RGB(0, 255, 0));
		animationGetHitR.AddBitmap(IDB_hitright_0, RGB(0, 255, 0));
		animationGetHitL.AddBitmap(IDB_hitleft_0, RGB(0, 255, 0));
		SkillQ.LoadBitmap(IDB_SkillQ);
		SkillW.LoadBitmap(IDB_SkillW);
		SkillE.LoadBitmap(IDB_SkillE);
		animationSkillQL.AddBitmap(IDB_SkillQleft_0, RGB(255, 255, 255));
		animationSkillQL.AddBitmap(IDB_SkillQleft_1, RGB(255, 255, 255));
		animationSkillQL.AddBitmap(IDB_SkillQleft_2, RGB(255, 255, 255));
		animationSkillQL.AddBitmap(IDB_SkillQleft_3, RGB(255, 255, 255));
		animationSkillQL.AddBitmap(IDB_SkillQleft_4, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_0, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_1, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_2, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_3, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_4, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_0, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_1, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_2, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_3, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_4, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_5, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_6, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_7, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_8, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_9, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_10, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_11, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_12, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_13, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_14, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_15, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_0, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_1, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_2, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_3, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_4, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_5, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_6, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_7, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_8, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_9, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_10, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_11, RGB(255, 255, 255));
		animationSkillE.AddBitmap(IDB_SkillE1_0, RGB(0, 255, 0));
		animationSkillE.AddBitmap(IDB_SkillE1_1, RGB(0, 255, 0));
		animationSkillE.AddBitmap(IDB_SkillE1_2, RGB(0, 255, 0));
		animationSkillE.AddBitmap(IDB_SkillE1_3, RGB(0, 255, 0));
		animationAttackR.SetDelayCount(3);
		animationAttackL.SetDelayCount(3);
		animationSkillQR.SetDelayCount(3);
		animationSkillQL.SetDelayCount(3);
		animationSkillW1.SetDelayCount(3);
		animationSkillW2.SetDelayCount(3);
		animationSkillE.SetDelayCount(4);
		animationAttackR.Reset();
		animationAttackL.Reset();
		animationSkillQR.Reset();
		animationSkillQL.Reset();
		animationSkillW1.Reset();
		animationSkillW2.Reset();
		animationSkillE.Reset();
	}

	void Character::MakeFont(int num, string type)
	{
		string mkfont;

		if (type == "HP")
		{
			mkfont = to_string(num);

			for (int i = 0; i < (int)hp_num.size(); i++)
			{
				delete hp_num[i];
			}

			hp_num.clear();

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				hp_num.push_back(new CMovingBitmap);
				hp_num[i]->LoadBitmap(335 + mkfont[i] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "MP")
		{
			mkfont = to_string(num);

			for (int i = 0; i < (int)mp_num.size(); i++)
			{
				delete mp_num[i];
			}

			mp_num.clear();

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				mp_num.push_back(new CMovingBitmap);
				mp_num[i]->LoadBitmap(335 + mkfont[i] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "HPLimit")
		{
			mkfont = to_string(num);

			for (int i = 0; i < (int)hplimit_num.size(); i++)
			{
				delete hplimit_num[i];
			}

			hplimit_num.clear();
			hplimit_num.push_back(new CMovingBitmap);
			hplimit_num[0]->LoadBitmap(IDB_mphp_line, RGB(0, 255, 0));

			for (int i = 1; i < (int)mkfont.size() + 1; i++)
			{
				hplimit_num.push_back(new CMovingBitmap);
				hplimit_num[i]->LoadBitmap(335 + mkfont[i - 1] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "MPLimit")
		{
			mkfont = to_string(num);

			for (int i = 0; i < (int)mplimit_num.size(); i++)
			{
				delete mplimit_num[i];
			}

			mplimit_num.clear();
			mplimit_num.push_back(new CMovingBitmap);
			mplimit_num[0]->LoadBitmap(IDB_mphp_line, RGB(0, 255, 0));

			for (int i = 1; i < (int)mkfont.size() + 1; i++)
			{
				mplimit_num.push_back(new CMovingBitmap);
				mplimit_num[i]->LoadBitmap(335 + mkfont[i - 1] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "Damage")
		{
			mkfont = to_string(num);
			vector<CMovingBitmap*> dmg_vector;
			int init_x, init_y;
			init_x = x + (animationStandR.Width() / 2) - ((mkfont.length() * 38) / 2);
			init_y = y - 15 - 59;

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				dmg_vector.push_back(new CMovingBitmap);
				dmg_vector[i]->LoadBitmap(302 + mkfont[i] - 48, RGB(0, 255, 0));
				dmg_vector[i]->SetTopLeft(init_x + i * 38, init_y);
			}

			damagefont.push_back(dmg_vector);
			damagefont_timer.push_back(clock());
		}
		else if (type == "level")
		{
			mkfont = to_string(num);

			for (int i = 0; i < (int)level_num.size(); i++)
			{
				delete level_num[i];
			}

			level_num.clear();

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				level_num.push_back(new CMovingBitmap);
				level_num[i]->LoadBitmap(312 + mkfont[i] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "Q_cd")
		{
			ostringstream stream;
			stream << fixed << setprecision(1);
			stream << (double)num / 1000;
			mkfont = stream.str();

			for (int i = 0; i < (int)q_cd_time.size(); i++)
			{
				delete q_cd_time[i];
			}

			q_cd_time.clear();

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				q_cd_time.push_back(new CMovingBitmap);

				if (mkfont[i] == '.')
				{
					q_cd_time[i]->LoadBitmap(IDB_skill_dot, RGB(0, 255, 0));
				}
				else
				{
					q_cd_time[i]->LoadBitmap(324 + mkfont[i] - 48, RGB(0, 255, 0));
				}
			}
		}
		else if (type == "W_cd")
		{
			ostringstream stream;
			stream << fixed << setprecision(1);
			stream << (double)num / 1000;
			mkfont = stream.str();

			for (int i = 0; i < (int)w_cd_time.size(); i++)
			{
				delete w_cd_time[i];
			}

			w_cd_time.clear();

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				w_cd_time.push_back(new CMovingBitmap);

				if (mkfont[i] == '.')
				{
					w_cd_time[i]->LoadBitmap(IDB_skill_dot, RGB(0, 255, 0));
				}
				else
				{
					w_cd_time[i]->LoadBitmap(324 + mkfont[i] - 48, RGB(0, 255, 0));
				}
			}
		}
		else if (type == "E_cd")
		{
			ostringstream stream;
			stream << fixed << setprecision(1);
			stream << (double)num / 1000;
			mkfont = stream.str();

			for (int i = 0; i < (int)e_cd_time.size(); i++)
			{
				delete e_cd_time[i];
			}

			e_cd_time.clear();

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				if (mkfont[i] == '.')
				{
					break;
				}
				else
				{
					e_cd_time.push_back(new CMovingBitmap);
					e_cd_time[i]->LoadBitmap(324 + mkfont[i] - 48, RGB(0, 255, 0));
				}
			}
		}
	}

	void Character::ShowDamageFont()
	{
		int del = -1;

		for (int i = 0; i < (int)damagefont.size(); i++)
		{
			for (int j = 0; j < (int)damagefont[i].size(); j++)
			{
				if (clock() - damagefont_timer[i] <= 400)
				{
					damagefont[i][j]->SetTopLeft(damagefont[i][j]->Left(), damagefont[i][j]->Top() - (int)(((clock() - damagefont_timer[i]) / 100) * 2));
					damagefont[i][j]->ShowBitmap();
				}
			}

			if (clock() - damagefont_timer[i] >= 1500)
			{
				del = i;
			}
		}

		if (del != -1)
		{
			for (int i = 0; i < del + 1; i++)
			{
				for (int j = 0; j < (int)damagefont[i].size(); j++)
				{
					delete damagefont[i][j];
				}
			}

			damagefont_timer.erase(damagefont_timer.begin(), damagefont_timer.begin() + del + 1);
			damagefont.erase(damagefont.begin(), damagefont.begin() + del + 1);
		}
	}

	void Character::SetBackpack()
	{
		openBackpack = !openBackpack;
	}

	void Character::SetItemSelectIndex(int index)
	{
		itemselectindex = index;
	}

	void Character::SetPick(bool flag)
	{
		pickItem = flag;
	}

	void Character::SetUse(bool flag)
	{
		useItem = flag;
	}

	void Character::SetMovingDown(bool flag)
	{
		isMovingDown = flag;
	}

	void Character::SetMovingLeft(bool flag)
	{
		if (isAttack && attackstate == "Q")
		{
			isMovingLeft = false;
		}
		else
		{
			isMovingLeft = flag;
		}
	}

	void Character::SetMovingRight(bool flag)
	{
		if (isAttack && attackstate == "Q")
		{
			isMovingRight = false;
		}
		else
		{
			isMovingRight = flag;
		}
	}

	void Character::SetMovingUp(bool flag)
	{
		isMovingUp = flag;
	}

	void Character::SetAttack(bool flag, string s)
	{
		isAttack = false;
		attackstate = s;
		if (attackstate == "Q"&& mp >= q_mp && (clock() - q_timer >= q_cd || q_cd == -1))
		{
			isAttack = flag;
			isMovingLeft = false;
			isMovingRight = false;
			isJump = false;
		}

		if (attackstate == "W" && mp >= w_mp && (clock() - w_timer >= w_cd || w_cd == -1))
		{
			isAttack = flag;
			wcount = 0;
			mp -= w_mp;
			wx = x + mw - map->getMapX();
			wy = y - 125 - map->getMapY();
			animationSkillW1.SetTopLeft(wx, wy);
			animationSkillW2.SetTopLeft(wx, wy);
			animationSkillW1.Reset();
			animationSkillW2.Reset();
		}

		if (attackstate == "E" &&supercount == -1 && (clock() - e_timer >= e_cd || e_timer == -1)) {
			supercount = 0;
			isAttack = flag;
		}
	}

	void Character::SetJump(bool flag)
	{
		if (isAttack && attackstate == "Q")
		{
			isJump = false;
		}
		else
		{
			isJump = flag;
		}
	}

	void Character::setEffect()
	{
		bool flag = false;
		backpack[itemselectindex]->SetNum(backpack[itemselectindex]->GetNum() - 1);
		useItem = false;

		if (backpack[itemselectindex]->GetName() == "�����Ĥ�")
		{
			for (int i = 0; i < (int)effect.size(); i++)
			{
				if (effect[i]->getName() == backpack[itemselectindex]->GetName())
				{
					effect[i]->setTime(5);
					flag = true;
				}
			}

			if (!flag)
			{
				effect.push_back(new Effect(backpack[itemselectindex]->GetName(), 5, 20));
			}
		}
		else if (backpack[itemselectindex]->GetName() == "�Ŧ��Ĥ�")
		{
			for (int i = 0; i < (int)effect.size(); i++)
			{
				if (effect[i]->getName() == backpack[itemselectindex]->GetName())
				{
					effect[i]->setTime(5);
					flag = true;
				}
			}

			if (!flag)
			{
				effect.push_back(new Effect(backpack[itemselectindex]->GetName(), 5, 30));
			}
		}
		else if (backpack[itemselectindex]->GetName() == "�H����C")
		{
			damage += 5;
		}
		else if (backpack[itemselectindex]->GetName() == "�H��޵P")
		{
			defense += 5;
		}
		else if (backpack[itemselectindex]->GetName() == "�H��W��")
		{
			hp_limit += 10;
		}

		if (backpack[itemselectindex]->GetNum() == 0)
		{
			delete backpack[itemselectindex];
			backpack.erase(backpack.begin() + itemselectindex);
		}
	}

	void Character::getEffect(string type)
	{
		for (int i = 0; i < (int)effect.size(); i++)
		{
			if (type == "hp")
			{
				if (effect[i]->getName() == "�����Ĥ�")
				{
					hp += effect[i]->getNum();
					effect[i]->setTime(-1);
				}
			}
			else if (type == "mp")
			{
				if (effect[i]->getName() == "�Ŧ��Ĥ�")
				{
					mp += effect[i]->getNum();
					effect[i]->setTime(-1);
				}
			}
		}

		for (int i = (int)effect.size() - 1; i >= 0; i--)
		{
			if (effect[i]->getTime() == 0)
			{
				delete effect[i];
				effect.erase(effect.begin() + i);
			}
		}
	}

	void Character::OnShow()
	{
		vector<int> del;
		playerinfo.SetTopLeft(338, 677);
		playerinfo.ShowBitmap();

		if (openBackpack)
		{
			backpack_ui.SetTopLeft(858, 75);
			backpack_ui.ShowBitmap();

			for (int i = 0; i < (int)backpack.size(); i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (backpack[i]->GetName() == backpack[j]->GetName())
					{
						backpack[j]->SetNum(backpack[j]->GetNum() + 1);
						del.push_back(i);
						break;
					}
				}
			}

			for (int i = (int)del.size() - 1; i >= 0; i--)
			{
				delete backpack[del[i]];
				backpack.erase(backpack.begin() + del[i]);
			}

			for (int i = 0; i < (int)backpack.size(); i++)
			{
				backpack[i]->SetTopLeft(867 + (i % 4) * 36, 103 + (i / 4) * 35);
				backpack[i]->onShow(0, 0, false);
				backpack[i]->ShowNum();
			}

			itemselected_ui.SetTopLeft(865 + (itemselectindex % 4) * 36, 101 + (itemselectindex / 4) * 35);
			itemselected_ui.ShowBitmap();
		}

		if (useItem && openBackpack && itemselectindex < (int)backpack.size())
		{
			setEffect();
		}

		SkillQ.SetTopLeft(874, 0);
		SkillQ.ShowBitmap();
		SkillW.SetTopLeft(924, 0);
		SkillW.ShowBitmap();
		SkillE.SetTopLeft(974, 0);
		SkillE.ShowBitmap();
		MakeFont(lvl, "level");

		for (int i = 0; i < (int)level_num.size(); i++)
		{
			level_num[i]->SetTopLeft(405 + 16 * i, 685);
			level_num[i]->ShowBitmap();
		}

		for (int i = 0; i < (int)ceil((double)hp / hp_limit * 100); i++)
		{
			hp_pic[i]->SetTopLeft(379 + 3 * i, 717);
			hp_pic[i]->ShowBitmap();
		}

		for (int i = 0; i < (int)ceil((double)mp / mp_limit * 100); i++)
		{
			mp_pic[i]->SetTopLeft(379 + 3 * i, 741);
			mp_pic[i]->ShowBitmap();
		}

		MakeFont(hp, "HP");

		for (int i = (int)hp_num.size() - 1; i >= 0; i--)
		{
			hp_num[i]->SetTopLeft(519 - ((int)hp_num.size() - 1 - i) * 11, 720);
			hp_num[i]->ShowBitmap();
		}

		MakeFont(mp, "MP");

		for (int i = (int)mp_num.size() - 1; i >= 0; i--)
		{
			mp_num[i]->SetTopLeft(519 - ((int)mp_num.size() - 1 - i) * 11, 744);
			mp_num[i]->ShowBitmap();
		}

		MakeFont(hp_limit, "HPLimit");

		for (int i = (int)hplimit_num.size() - 1; i >= 0; i--)
		{
			hplimit_num[i]->SetTopLeft(529 + i * 11, 720);
			hplimit_num[i]->ShowBitmap();
		}

		MakeFont(mp_limit, "MPLimit");

		for (int i = (int)mplimit_num.size() - 1; i >= 0; i--)
		{
			mplimit_num[i]->SetTopLeft(529 + i * 11, 744);
			mplimit_num[i]->ShowBitmap();
		}

		ShowDamageFont();

		if (q_cd - (clock() - q_timer) > 0 && q_timer != -1)
		{
			MakeFont(int(q_cd - (clock() - q_timer)), "Q_cd");

			for (int i = 0; i < (int)q_cd_time.size(); i++)
			{
				q_cd_time[i]->SetTopLeft(880 + i * 12, 50);
				q_cd_time[i]->ShowBitmap();
			}
		}

		if (w_cd - (clock() - w_timer) > 0 && w_timer != -1)
		{
			MakeFont(int(w_cd - (clock() - w_timer)), "W_cd");

			for (int i = 0; i < (int)w_cd_time.size(); i++)
			{
				w_cd_time[i]->SetTopLeft(930 + i * 12, 50);
				w_cd_time[i]->ShowBitmap();
			}
		}

		if (e_cd - (clock() - e_timer) > 0 && e_timer != -1)
		{
			MakeFont(int(e_cd - (clock() - e_timer)), "E_cd");

			for (int i = 0; i < (int)e_cd_time.size(); i++)
			{
				e_cd_time[i]->SetTopLeft(985 + i * 12, 50);
				e_cd_time[i]->ShowBitmap();
			}
		}

		if (wcount != -1)
		{
			if (wcount == 3)
			{
				animationSkillW2.SetTopLeft(wx + map->getMapX(), wy + map->getMapY());
				animationSkillW2.OnShow();
			}
			else
			{
				animationSkillW1.SetTopLeft(wx + map->getMapX(), wy + map->getMapY());
				animationSkillW1.OnShow();
			}
		}
		if (isAttack&&attackstate == "E") {
			animationSkillE.SetTopLeft(x + mw, y - mh * 2);
			animationSkillE.OnShow();
		}

		if (isJump)
		{
			if (direction == 0)
			{
				animationJumpR.SetTopLeft(x + mw, y + mh);
				animationJumpR.OnShow();
			}
			else
			{
				animationJumpL.SetTopLeft(x + mw, y + mh);
				animationJumpL.OnShow();
			}
		}
		else if (isAttack && attackstate == "Q")
		{
			if (direction == 0)
			{
				animationAttackR.SetTopLeft(x + mw, y + mh);
				animationAttackR.OnShow();

				if (animationAttackR.IsFinalBitmap())
				{
					animationSkillQR.SetTopLeft(x + animationStandR.Width() + (animationSkillQL.Width() / 2), y + (animationSkillQL.Height() / 2));
					animationSkillQR.OnShow();
				}
			}
			else
			{
				if (attackstate == "Q")
				{
					animationAttackL.SetTopLeft(x + mw, y + mh);
					animationAttackL.OnShow();

					if (animationAttackL.IsFinalBitmap())
					{
						animationSkillQL.SetTopLeft(x - (animationSkillQL.Width() / 2), y + (animationSkillQL.Height() / 2));
						animationSkillQL.OnShow();
					}
				}
			}
		}
		else if (isMovingRight && onLadder == 0)
		{
			animationWalkR.SetTopLeft(x + mw, y + mh);
			animationWalkR.OnShow();
			direction = 0;
		}
		else if (isMovingLeft && onLadder == 0)
		{
			animationWalkL.SetTopLeft(x + mw, y + mh);
			animationWalkL.OnShow();
			direction = 1;
		}
		else if (isMovingDown && onLadder == 0 && !isJump && Fall == 0)
		{
			if (direction == 0)
			{
				animationProneR.SetTopLeft(x + mw, y + mh);
				animationProneR.OnShow();
			}
			else
			{
				animationProneL.SetTopLeft(x + mw, y + mh);
				animationProneL.OnShow();
			}
		}
		else if (onLadder == 1)
		{
			animationLadder.SetTopLeft(x + mw, y + mh);
			animationLadder.OnShow();
		}
		else if (direction == 0 && onLadder == 0)
		{
			if (ishit && clock() - hit_timer <= 1000)
			{
				animationGetHitR.SetTopLeft(x + mw, y + mh);
				animationGetHitR.OnShow();
			}
			else
			{
				animationStandR.SetTopLeft(x + mw, y + mh);
				animationStandR.OnShow();
			}
		}
		else if (direction == 1 && onLadder == 0)
		{
			if (ishit && clock() - hit_timer <= 1000)
			{
				animationGetHitL.SetTopLeft(x + mw, y + mh);
				animationGetHitL.OnShow();
			}
			else
			{
				animationStandL.SetTopLeft(x + mw, y + mh);
				animationStandL.OnShow();
			}
		}
	}

	void Character::OnMove()
	{
		int totaldmg = 0, getdmg = map->Monsterhit(x, y, x + animationStandR.Width(), y + animationStandR.Height(), defense);
		if (supercount != -1) {
			getdmg = 0;
		}
		if (getdmg != 0)
		{
			hp -= getdmg;
			getdmg = 0;
			ishit = true;
			hit_timer = clock();
		}

		if (clock() - mp_timer >= 1000)
		{
			getEffect("mp");
			mp += lvl;
			mp_timer = clock();

			if (mp > mp_limit)
			{
				mp = mp_limit;
			}
		}

		if (clock() - hp_timer >= 1000)
		{
			getEffect("hp");
			hp += 3 * lvl;
			hp_timer = clock();

			if (hp > hp_limit)
			{
				hp = hp_limit;
			}
		}

		if (expr >= LevelUp(lvl))
		{
			expr -= LevelUp(lvl);
			lvl++;
			hp_limit += 50;
			mp_limit += 30;
			hp = hp_limit;
			mp = mp_limit;
			q_mp += 15;
			w_mp += 30;
		}

		if (pickItem)
		{
			map->PickItem(x - map->getMapX(), y - map->getMapY(), animationStandR.Width(), animationStandR.Height(), &backpack);
		}

		pos.clear();
		pos.push_back(x);
		pos.push_back(y);
		JudgeArea(&pos, "null");

		if (wcount != -1)
		{
			if (wcount == 3)
			{
				animationSkillW2.OnMove();

				if (animationSkillW2.IsFinalBitmap())
				{
					expr += map->hitMonster(x, y, animationSkillW1.Left(), animationSkillW1.Top(), animationSkillW1.Left() + animationSkillW1.Width(), animationSkillW1.Top() + animationSkillW1.Height(), 150 + damage + 25 * (lvl - 1), animationSkillW2.IsFinalBitmap(), &totaldmg);
					isAttack = false;
					w_timer = clock();

					if (totaldmg > 0)
					{
						MakeFont(totaldmg, "Damage");
					}

					animationSkillW1.Reset();
					animationSkillW2.Reset();
					wcount = -1;
				}
			}
			else if (animationSkillW1.IsFinalBitmap())
			{
				expr += map->hitMonster(x, y, animationSkillW1.Left(), animationSkillW1.Top(), animationSkillW1.Left() + animationSkillW1.Width(), animationSkillW1.Top() + animationSkillW1.Height(), 50 + damage + 25 * (lvl - 1), animationSkillW1.IsFinalBitmap(), &totaldmg);

				if (totaldmg > 0)
				{
					MakeFont(totaldmg, "Damage");
				}

				if (wcount < 3)
				{
					wcount++;
					animationSkillW1.Reset();
				}
			}
			else
			{
				animationSkillW1.OnMove();
			}
		}
		if (isAttack&&attackstate == "E") {
			animationSkillE.OnMove();
			if (animationSkillE.IsFinalBitmap()) {
				supercount++;
				animationSkillE.Reset();
			}
			if (supercount == 5) {
				supercount = -1;
				animationSkillE.Reset();
				isAttack = false;
				e_timer = clock();
			}
		}
		if (isAttack && attackstate == "Q")
		{
			if (direction == 0)
			{
				if (animationAttackR.IsFinalBitmap())
				{
					animationSkillQR.OnMove();
					expr += map->hitMonster(x, y, animationSkillQR.Left(), animationSkillQR.Top(), animationSkillQR.Left() + animationSkillQR.Width(), animationSkillQR.Top() + (animationSkillQR.Height() / 2), 100 + damage + 25 * (lvl - 1), animationSkillQR.IsFinalBitmap(), &totaldmg);

					if (animationSkillQR.IsFinalBitmap())
					{
						isAttack = false;
						animationAttackR.Reset();
						animationSkillQR.Reset();
						q_timer = clock();
						mp -= q_mp;

						if (totaldmg > 0)
						{
							MakeFont(totaldmg, "Damage");
						}
					}
				}
				else
				{
					animationAttackR.OnMove();
				}
			}
			else
			{
				if (animationAttackL.IsFinalBitmap())
				{
					animationSkillQL.OnMove();
					expr += map->hitMonster(x, y, animationSkillQL.Left(), animationSkillQL.Top(), animationSkillQL.Left() + animationSkillQL.Width(), animationSkillQL.Top() + (animationSkillQL.Height() / 2), 100 + damage + 25 * (lvl - 1), animationSkillQL.IsFinalBitmap(), &totaldmg);

					if (animationSkillQL.IsFinalBitmap())
					{
						isAttack = false;
						animationAttackL.Reset();
						animationSkillQL.Reset();
						q_timer = clock();
						mp -= q_mp;

						if (totaldmg > 0)
						{
							MakeFont(totaldmg, "Damage");
						}
					}
				}
				else
				{
					animationAttackL.OnMove();
				}
			}
		}

		if (isMovingLeft)
		{
			if (JudgeArea(&pos, "left"))
			{
				direction = 1;
				x = pos[0];
				y = pos[1];
			}
		}
		else if (isMovingRight)
		{
			if (JudgeArea(&pos, "right"))
			{
				direction = 0;
				x = pos[0];
				y = pos[1];
			}
		}
		else if (isMovingUp)
		{
			if (JudgeArea(&pos, "up"))
			{
				x = pos[0];
				y = pos[1];
			}
		}
		else if (isMovingDown)
		{
			if (JudgeArea(&pos, "down"))
			{
				x = pos[0];
				y = pos[1];
			}
		}
		else if (direction == 0)
		{
			if (ishit && clock() - hit_timer <= 1000)
			{
				animationGetHitR.OnMove();
			}
			else
			{
				ishit = false;
				animationStandR.OnMove();
			}
		}
		else if (direction == 1)
		{
			if (ishit && clock() - hit_timer <= 1000)
			{
				animationGetHitL.OnMove();
			}
			else
			{
				ishit = false;
				animationStandL.OnMove();
			}
		}

		if (isJump)
		{
			if (onLadder == 1)
			{
				onLadder = 0;
				velocity = 6;
			}

			if (Fall == 1)
			{
				isJump = false;
			}
			else if (JudgeArea(&pos, "jump"))
			{
				y = pos[1];
			}
		}

		if (Fall == 1)
		{
			if (JudgeArea(&pos, "fall"))
			{
				if (map->isArea(&pos))
				{
					Fall = 0;
					velocity = initial_velocity;
					isJump = false;
				}

				x = pos[0];
				y = pos[1];
			}
		}
	}
	void Character::Jump(vector<int>* pos, string move)
	{
		if (move == "jump")
		{
			if (velocity > initial_velocity)
			{
				velocity = initial_velocity;
			}

			if (velocity > 0)
			{
				(*pos)[1] -= velocity;
				velocity--;
			}
			else
			{
				Fall = 1;
				velocity = 1;
			}
		}
		else
		{
			if (velocity < 18)
			{
				velocity++;
			}

			(*pos)[1] += velocity;
		}
	}

	bool Character::JudgeArea(vector<int>* pos, string dir)
	{
		if (!isJump && onLadder == 0)
		{
			if (!map->isArea(pos))
			{
				if (Fall == 1)
				{
					isJump = false;
				}
				else
				{
					Fall = 1;
					velocity = 1;
				}
			}
		}

		if (dir == "left" && onLadder == 0)
		{
			if (!map->isEdge(pos, "left"))
			{
				if ((*pos)[0] > 350)
				{
					(*pos)[0] -= 5;
				}
				else
				{
					(*pos)[0] -= map->scrollLeft();
				}
			}

			animationWalkL.OnMove();
		}

		if (dir == "right" && onLadder == 0)
		{
			if (!map->isEdge(pos, "right"))
			{
				if ((*pos)[0] < 600)
				{
					(*pos)[0] += 5;
				}
				else
				{
					(*pos)[0] += map->scrollRight();
				}
			}

			animationWalkR.OnMove();
		}

		if (dir == "up")
		{
			if (onLadder == 0)
			{
				if (map->isTeleport(pos))
				{
					currentMap = map->setTeleport(pos);
					isMovingUp = false;
				}
				else if (map->isLadder(pos, dir))
				{
					map->setLadder(pos, dir);
					onLadder = 1;
					velocity = initial_velocity;
					animationLadder.OnShow();
					isMovingLeft = false;
					isMovingRight = false;
					isJump = false;
					Fall = 0;
				}
			}
			else
			{
				(*pos)[1] -= 5;
				isJump = false;
				animationLadder.OnMove();

				if (map->isArea(pos))
				{
					onLadder = 0;
				}
			}
		}

		if (dir == "down")
		{
			if (map->isLadder(pos, dir) && onLadder == 0)
			{
				map->setLadder(pos, dir);
				onLadder = 1;
				velocity = initial_velocity;
				animationLadder.OnShow();
				isMovingLeft = false;
				isMovingRight = false;
				isJump = false;
				Fall = 0;
			}
			else if (onLadder == 0 && !isJump && Fall == 0)
			{
				if (direction == 0)
				{
					animationProneR.OnMove();
				}
				else
				{
					animationProneL.OnMove();
				}
			}
			else if (onLadder == 1)
			{
				(*pos)[1] += 5;
				animationLadder.OnMove();

				if (map->isArea(pos))
				{
					onLadder = 0;
				}
			}
		}

		if (dir == "jump" || dir == "fall")
		{
			Jump(pos, dir);

			if (direction == 0)
			{
				animationJumpR.OnMove();
			}
			else
			{
				animationJumpL.OnMove();
			}
		}

		return true;
	}
	bool Character::GetBackpack()
	{
		return openBackpack;
	}
	/////////////////////////////////////////////////////////////////////////////
	// �o��class���C�����C���}�Y�e������
	/////////////////////////////////////////////////////////////////////////////

	CGameStateInit::CGameStateInit(CGame* g)
		: CGameState(g)
	{
	}

	void CGameStateInit::OnInit()
	{
		SetWindowPos(FindWindow(NULL, "game"), HWND_TOP, 400, 150, 0, 0, SWP_NOSIZE);
		ShowInitProgress(0);	// �@�}�l��loading�i�׬�0%
		CAudio::Instance()->Load(bgmtitle, "sounds\\bgmtitle.mp3");
		CAudio::Instance()->Load(bgm01, "sounds\\bgm0_1.mp3");
		CAudio::Instance()->Load(bgm23, "sounds\\bgm2_3.mp3");
		CAudio::Instance()->Load(bgm14, "sounds\\bgm1_4.mp3");
		//CAudio::Instance()->Play(bgmtitle, true);
		title.AddBitmap(IDB_title_0);
		title.AddBitmap(IDB_title_1);
		title.SetTopLeft(0 + title.Width() / 2, 0 + title.Height() / 2);
		title.SetDelayCount(10);
		title.Reset();
	}

	void CGameStateInit::OnBeginState()
	{
	}

	void CGameStateInit::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
	{
		const char KEY_SPACE = ' ';

		if (nChar == KEY_SPACE)
			GotoGameState(GAME_STATE_RUN);						// ������GAME_STATE_RUN
	}

	/*void CGameStateInit::OnLButtonDown(UINT nFlags, CPoint point)
	{
		GotoGameState(GAME_STATE_RUN);		// ������GAME_STATE_RUN
	}*/

	void CGameStateInit::OnShow()
	{
		title.OnShow();
		title.OnMove();
	}

	/////////////////////////////////////////////////////////////////////////////
	// �o��class���C�����������A(Game Over)
	/////////////////////////////////////////////////////////////////////////////

	CGameStateOver::CGameStateOver(CGame* g)
		: CGameState(g)
	{
	}

	void CGameStateOver::OnInit()
	{
		//
		// ���ϫܦh�ɡAOnInit���J�Ҧ����ϭn��ܦh�ɶ��C���קK���C�����H
		//     �������@�СA�C���|�X�{�uLoading ...�v�A���Loading���i�סC
		//
		ShowInitProgress(66);	// ���ӫe�@�Ӫ��A���i�סA���B�i�׵���66%
		//
		// �}�l���J���
		//
		//Sleep(300);				// ��C�A�H�K�ݲM���i�סA��ڹC���ЧR����Sleep
		//
		// �̲׶i�׬�100%
		//
		ShowInitProgress(100);
	}

	void CGameStateOver::OnShow()
	{
		CDC* pDC = CDDraw::GetBackCDC();			// ���o Back Plain �� CDC
		CFont f, *fp;
		f.CreatePointFont(160, "Times New Roman");	// ���� font f; 160����16 point���r
		fp = pDC->SelectObject(&f);					// ��� font f
		pDC->SetBkColor(RGB(0, 0, 0));
		pDC->SetTextColor(RGB(255, 255, 0));
		char str[80];								// Demo �Ʀr��r�ꪺ�ഫ
		pDC->TextOut(240, 210, str);
		pDC->SelectObject(fp);						// �� font f (�d�U���n�|�F��)
		CDDraw::ReleaseBackCDC();					// �� Back Plain �� CDC
	}

	/////////////////////////////////////////////////////////////////////////////
	// �o��class���C�����C�����檫��A�D�n���C���{�����b�o��
	/////////////////////////////////////////////////////////////////////////////

	CGameStateRun::CGameStateRun(CGame* g)
		: CGameState(g) {}

	void CGameStateRun::OnBeginState()
	{
	}

	void CGameStateRun::OnMove()							// ���ʹC������
	{
		map.monsterMove();
		character.OnMove();
	}

	void CGameStateRun::OnInit()  								// �C������Ȥιϧγ]�w
	{
		//
		// ���ϫܦh�ɡAOnInit���J�Ҧ����ϭn��ܦh�ɶ��C���קK���C�����H
		//     �������@�СA�C���|�X�{�uLoading ...�v�A���Loading���i�סC
		//
		ShowInitProgress(33);	// ���ӫe�@�Ӫ��A���i�סA���B�i�׵���33%
		//
		// �}�l���J���
		//
		character.LoadBitmap();
		character.Initialize(&map);
		ShowInitProgress(50);
		// ���J�s��0���n��ding.wav
		//
		// ��OnInit�ʧ@�|����CGameStaterOver::OnInit()�A�ҥH�i���٨S��100%
		//
	}

	void CGameStateRun::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
	{
		const char KEY_ENTER = 0x0D;
		const char KEY_BACKPACK = 0x49;
		const char KEY_PICK = 0x58;
		const char KEY_LEFT = 0x25;
		const char KEY_UP = 0x26;
		const char KEY_RIGHT = 0x27;
		const char KEY_DOWN = 0x28;
		const char KEY_JUMP = 0x5A;
		const char KEY_SKILLQ = 0x51;
		const char KEY_SKILLW = 0x57;
		const char KEY_SKILLE = 0x45;

		if (nChar == KEY_ENTER)
		{
			character.SetUse(true);
		}

		if (nChar == KEY_BACKPACK)
		{
			character.SetBackpack();
		}

		if (nChar == KEY_PICK)
		{
			character.SetPick(true);
		}

		if (nChar == KEY_SKILLQ)
		{
			character.SetAttack(true, "Q");
		}

		if (nChar == KEY_SKILLW)
		{
			character.SetAttack(true, "W");
		}

		if (nChar == KEY_SKILLE)
		{
			character.SetAttack(true, "E");
		}

		if (nChar == KEY_LEFT)
		{
			if (character.GetBackpack())
			{
				if (character.GetItemSelectIndex() > 0)
				{
					character.SetItemSelectIndex(character.GetItemSelectIndex() - 1);
				}
			}
			else
			{
				character.SetMovingLeft(true);
				character.SetMovingRight(false);
			}
		}

		if (nChar == KEY_RIGHT)
		{
			if (character.GetBackpack())
			{
				if (character.GetItemSelectIndex() < 23)
				{
					character.SetItemSelectIndex(character.GetItemSelectIndex() + 1);
				}
			}
			else
			{
				character.SetMovingRight(true);
				character.SetMovingLeft(false);
			}
		}

		if (nChar == KEY_UP)
		{
			if (character.GetBackpack())
			{
				if (character.GetItemSelectIndex() >= 4)
				{
					character.SetItemSelectIndex(character.GetItemSelectIndex() - 4);
				}
			}
			else
			{
				character.SetMovingUp(true);
				character.SetMovingDown(false);
			}
		}

		if (nChar == KEY_DOWN)
		{
			if (character.GetBackpack())
			{
				if (character.GetItemSelectIndex() <= 19)
				{
					character.SetItemSelectIndex(character.GetItemSelectIndex() + 4);
				}
			}
			else
			{
				character.SetMovingDown(true);
				character.SetMovingUp(false);
			}
		}

		if (nChar == KEY_JUMP)
		{
			character.SetJump(true);
		}
	}

	void CGameStateRun::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
	{
		const char KEY_PICK = 0x58;
		const char KEY_LEFT = 0x25;
		const char KEY_UP = 0x26;
		const char KEY_RIGHT = 0x27;
		const char KEY_DOWN = 0x28;
		const char KEY_SKILLQ = 0x51;

		if (nChar == KEY_PICK)
		{
			character.SetPick(false);
		}

		if (nChar == KEY_LEFT)
		{
			character.SetMovingLeft(false);
		}

		if (nChar == KEY_RIGHT)
		{
			character.SetMovingRight(false);
		}

		if (nChar == KEY_UP)
		{
			character.SetMovingUp(false);
		}

		if (nChar == KEY_DOWN)
		{
			character.SetMovingDown(false);
		}
	}

	void CGameStateRun::OnShow()
	{
		map.onShow();
		map.itemShow();
		map.monsterShow(character.GetX1());
		character.OnShow();
	}
}