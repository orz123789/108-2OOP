#pragma once
#include "Item.h"
namespace game_framework
{
	class Monster
	{
	public:
		Monster(int, int, int, vector<int>, int, int, int, int, int);
		~Monster();
		void LoadBitmap();
		void onShow(int, int, int, int);
		void onMove();
		int gethp();
		int getHit(int, int, int, int, int, int, int, bool, int*, vector<Item*>*);//�Ǫ��Q����
		int Hit(int, int, int, int, int);//�Ǫ��������a
	protected:
		CAnimation animationStandR, animationStandL, animationWalkL, animationWalkR, animationHitL, animationHitR, animationDieL, animationDieR, animationSkillL, animationSkillR;
		vector<int> Area, stonex, stoney;
		vector<CMovingBitmap*> stone;
		int direction, state, MapX, MapY, x, y, mh, mw, hp, currentMap, expr, dmg, def, rnd;
		double timer_death, timer_gethit, timer_hit, timer_skill;
		bool skillhit, soundeffect;
	};
}