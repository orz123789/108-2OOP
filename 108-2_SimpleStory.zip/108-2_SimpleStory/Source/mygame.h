#include "Map.h"
#include "Character.h"
enum AUDIO_ID
{
	bgmtitle,//0
	bgm01,//1
	bgm11,//2
	bgm12,//3
	bgm13,//4
	bgm21,//5
	bgm22,//6
	bgm23,//7
	bgm31,//8
	skillq,//9
	skillw,//10
	skille,//11
	skillr,//12
	pickitem,//13
	levelup,//14
	attack23,//15
	attack31,//16
	success,//17
};

namespace game_framework
{
	class CGameStateInit : public CGameState
	{
	public:
		CGameStateInit(CGame* g);
		void OnInit();
		void OnBeginState();
		void OnKeyUp(UINT, UINT, UINT);
	protected:
		void OnShow();
	private:
		CAnimation title;
	};
	class CGameStateRun : public CGameState
	{
	public:
		CGameStateRun(CGame* g);
		void OnBeginState();
		void OnInit();
		void OnKeyDown(UINT, UINT, UINT);
		void OnKeyUp(UINT, UINT, UINT);
	protected:
		void OnMove();
		void OnShow();
	private:
		Character	character;
		Map map;
	};
	class CGameStateOver : public CGameState
	{
	public:
		CGameStateOver(CGame* g);
		void OnInit();
	protected:
		void OnShow();
	};

}