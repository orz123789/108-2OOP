#include "stdafx.h"
#include "Resource.h"
#include <mmsystem.h>
#include <ddraw.h>
#include "audio.h"
#include "gamelib.h"
#include "Character.h"
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>


namespace game_framework
{
	Character::~Character()
	{
		for (int i = 0; i < (int)help.size(); i++)
		{
			delete help[i];
		}
		for (int i = 0; i < (int)backpack.size(); i++)
		{
			delete backpack[i];
		}

		for (int i = 0; i < (int)effect.size(); i++)
		{
			delete effect[i];
		}

		for (int i = 0; i < (int)hp_pic.size(); i++)
		{
			delete hp_pic[i];
		}

		for (int i = 0; i < (int)mp_pic.size(); i++)
		{
			delete mp_pic[i];
		}

		for (int i = 0; i < (int)level_num.size(); i++)
		{
			delete level_num[i];
		}

		for (int i = 0; i < (int)hp_num.size(); i++)
		{
			delete hp_num[i];
		}

		for (int i = 0; i < (int)hplimit_num.size(); i++)
		{
			delete hplimit_num[i];
		}

		for (int i = 0; i < (int)mp_num.size(); i++)
		{
			delete mp_num[i];
		}

		for (int i = 0; i < (int)mplimit_num.size(); i++)
		{
			delete mplimit_num[i];
		}

		for (int i = 0; i < (int)q_cd_time.size(); i++)
		{
			delete q_cd_time[i];
		}

		for (int i = 0; i < (int)w_cd_time.size(); i++)
		{
			delete w_cd_time[i];
		}

		for (int i = 0; i < (int)e_cd_time.size(); i++)
		{
			delete e_cd_time[i];
		}

		for (int i = 0; i < (int)r_cd_time.size(); i++)
		{
			delete r_cd_time[i];
		}

		for (int i = 0; i < (int)damagefont.size(); i++)
		{
			for (int j = 0; j < (int)damagefont[i].size(); j++)
			{
				delete damagefont[i][j];
			}
		}

		for (int i = 0; i < (int)exp.size(); i++)
		{
			delete exp[i];
		}
	}

	int Character::GetX1()
	{
		return x;
	}

	int Character::GetY1()
	{
		return y;
	}

	int Character::GetX2()
	{
		return x + animationStandR.Width();
	}

	int Character::GetY2()
	{
		return y + animationStandR.Height();
	}

	int Character::GetFall()
	{
		return Fall;
	}
	int Character::LevelUp(int lvl)
	{
		if (lvl == 1)
		{
			return 100;
		}
		else
		{
			return LevelUp(lvl - 1) + 200;
		}
	}
	int Character::GetItemSelectIndex()
	{
		return itemselectindex;
	}
	int Character::GetHP()
	{
		return hp;
	}
	void Character::Initialize(Map* MAP)
	{
		map = MAP;
		damage = defense = 0;
		lvl = 1;
		hp = hp_limit = 750;
		mp = mp_limit = 450;
		q_mp = 30;
		w_mp = 150;
		r_mp = 30;
		q_cd = 300;
		w_cd = 2000;
		e_cd = 15000;
		r_cd = 500;
		velocity = initial_velocity = 12;
		hp_timer = mp_timer = q_timer = w_timer = e_timer = r_timer = -1;
		supercount = wcount = -1;
		Fall = onLadder = direction = currentMap = expr = itemselectindex = f2index = 0;
		f1 = f2 = f3 = pass = openBackpack = pickItem = useItem = isJump = isMovingLeft = isMovingRight = isMovingUp = isMovingDown = isAttack = isProne = false;
		map->Initialize(currentMap, 1);
		mh = animationStandR.Height() / 2;
		mw = animationStandR.Width() / 2;
		x = map->getInitX() + map->getMapX();
		y = map->getInitY() + map->getMapY() - 70;
	}

	void Character::Relive()
	{
		hp = hp_limit;
		mp = mp_limit;
		hp_timer = mp_timer = q_timer = w_timer = e_timer = -1;
		supercount = wcount = -1;
		velocity = initial_velocity = 12;
		Fall = onLadder = currentMap = direction = 0;
		openBackpack = pickItem = useItem = isJump = isMovingLeft = isMovingRight = isMovingUp = isMovingDown = isProne = isAttack = false;
		map->Initialize(currentMap, 1);
		x = map->getInitX() + map->getMapX();
		y = map->getInitY() + map->getMapY() - 70;
	}

	void Character::LoadBitmap()
	{
		author.LoadBitmap(IDB_author, RGB(0, 255, 0));
		keymap.LoadBitmap(IDB_keymap, RGB(0, 255, 0));
		mission.LoadBitmap(IDB_help_4, RGB(0, 255, 0));
		success.LoadBitmap(IDB_success, RGB(0, 255, 0));
		playerinfo.LoadBitmap(IDB_playerinfo, RGB(0, 255, 0));
		for (int i = 0; i < 4; i++) {
			help.push_back(new CMovingBitmap);
			help[i]->LoadBitmap(652 + i, RGB(0, 255, 0));
		}
		for (int i = 0; i < 100; i++)
		{
			hp_pic.push_back(new CMovingBitmap);
			mp_pic.push_back(new CMovingBitmap);
			hp_pic[i]->LoadBitmap(IDB_hp, RGB(0, 255, 0));
			mp_pic[i]->LoadBitmap(IDB_mp, RGB(0, 255, 0));
		}

		backpack_ui.LoadBitmap(IDB_backpack_ui);
		itemselected_ui.LoadBitmap(IDB_ItemSelectedUI, RGB(255, 255, 255));
		tomb.LoadBitmap(IDB_tomb, RGB(0, 255, 0));
		expbar.LoadBitmap(IDB_expbar);
		animationStandR.AddBitmap(IDB_standright_0, RGB(0, 255, 0));
		animationStandR.AddBitmap(IDB_standright_1, RGB(0, 255, 0));
		animationStandR.AddBitmap(IDB_standright_2, RGB(0, 255, 0));
		animationStandR.AddBitmap(IDB_standright_3, RGB(0, 255, 0));
		animationStandL.AddBitmap(IDB_standleft_0, RGB(0, 255, 0));
		animationStandL.AddBitmap(IDB_standleft_1, RGB(0, 255, 0));
		animationStandL.AddBitmap(IDB_standleft_2, RGB(0, 255, 0));
		animationStandL.AddBitmap(IDB_standleft_3, RGB(0, 255, 0));
		animationProneR.AddBitmap(IDB_proneright_0, RGB(0, 255, 0));
		animationProneL.AddBitmap(IDB_proneleft_0, RGB(0, 255, 0));
		animationJumpR.AddBitmap(IDB_jumpright_0, RGB(0, 255, 0));
		animationJumpL.AddBitmap(IDB_jumpleft_0, RGB(0, 255, 0));
		animationWalkR.AddBitmap(IDB_walkright_0, RGB(0, 255, 0));
		animationWalkR.AddBitmap(IDB_walkright_1, RGB(0, 255, 0));
		animationWalkR.AddBitmap(IDB_walkright_2, RGB(0, 255, 0));
		animationWalkR.AddBitmap(IDB_walkright_3, RGB(0, 255, 0));
		animationWalkL.AddBitmap(IDB_walkleft_0, RGB(0, 255, 0));
		animationWalkL.AddBitmap(IDB_walkleft_1, RGB(0, 255, 0));
		animationWalkL.AddBitmap(IDB_walkleft_2, RGB(0, 255, 0));
		animationWalkL.AddBitmap(IDB_walkleft_3, RGB(0, 255, 0));
		animationAttackR.AddBitmap(IDB_attackright_0, RGB(0, 255, 0));
		animationAttackR.AddBitmap(IDB_attackright_1, RGB(0, 255, 0));
		animationAttackR.AddBitmap(IDB_attackright_2, RGB(0, 255, 0));
		animationAttackL.AddBitmap(IDB_attackleft_0, RGB(0, 255, 0));
		animationAttackL.AddBitmap(IDB_attackleft_1, RGB(0, 255, 0));
		animationAttackL.AddBitmap(IDB_attackleft_2, RGB(0, 255, 0));
		animationLadder.AddBitmap(IDB_ladder_0, RGB(0, 255, 0));
		animationLadder.AddBitmap(IDB_ladder_1, RGB(0, 255, 0));
		animationGetHitR.AddBitmap(IDB_hitright_0, RGB(0, 255, 0));
		animationGetHitL.AddBitmap(IDB_hitleft_0, RGB(0, 255, 0));
		SkillQ.LoadBitmap(IDB_SkillQ);
		SkillW.LoadBitmap(IDB_SkillW);
		SkillE.LoadBitmap(IDB_SkillE);
		SkillR.LoadBitmap(IDB_SkillR);
		animationSkillQL.AddBitmap(IDB_SkillQleft_0, RGB(255, 255, 255));
		animationSkillQL.AddBitmap(IDB_SkillQleft_1, RGB(255, 255, 255));
		animationSkillQL.AddBitmap(IDB_SkillQleft_2, RGB(255, 255, 255));
		animationSkillQL.AddBitmap(IDB_SkillQleft_3, RGB(255, 255, 255));
		animationSkillQL.AddBitmap(IDB_SkillQleft_4, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_0, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_1, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_2, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_3, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_4, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_0, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_1, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_2, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_3, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_4, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_5, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_6, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_7, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_8, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_9, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_10, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_11, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_12, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_13, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_14, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_15, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_0, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_1, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_2, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_3, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_4, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_5, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_6, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_7, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_8, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_9, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_10, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_11, RGB(255, 255, 255));
		animationSkillE.AddBitmap(IDB_SkillE1_0, RGB(0, 255, 0));
		animationSkillE.AddBitmap(IDB_SkillE1_1, RGB(0, 255, 0));
		animationSkillE.AddBitmap(IDB_SkillE1_2, RGB(0, 255, 0));
		animationSkillE.AddBitmap(IDB_SkillE1_3, RGB(0, 255, 0));
		animationAttackR.SetDelayCount(3);
		animationAttackL.SetDelayCount(3);
		animationSkillQR.SetDelayCount(3);
		animationSkillQL.SetDelayCount(3);
		animationSkillW1.SetDelayCount(3);
		animationSkillW2.SetDelayCount(3);
		animationSkillE.SetDelayCount(4);
		animationAttackR.Reset();
		animationAttackL.Reset();
		animationSkillQR.Reset();
		animationSkillQL.Reset();
		animationSkillW1.Reset();
		animationSkillW2.Reset();
		animationSkillE.Reset();
	}

	void Character::MakeFont(int num, string type)
	{
		string mkfont;

		if (type == "HP")
		{
			mkfont = to_string(num);

			for (int i = 0; i < (int)hp_num.size(); i++)
			{
				delete hp_num[i];
			}

			hp_num.clear();

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				hp_num.push_back(new CMovingBitmap);
				hp_num[i]->LoadBitmap(335 + mkfont[i] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "MP")
		{
			mkfont = to_string(num);

			for (int i = 0; i < (int)mp_num.size(); i++)
			{
				delete mp_num[i];
			}

			mp_num.clear();

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				mp_num.push_back(new CMovingBitmap);
				mp_num[i]->LoadBitmap(335 + mkfont[i] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "HPLimit")
		{
			mkfont = to_string(num);

			for (int i = 0; i < (int)hplimit_num.size(); i++)
			{
				delete hplimit_num[i];
			}

			hplimit_num.clear();
			hplimit_num.push_back(new CMovingBitmap);
			hplimit_num[0]->LoadBitmap(IDB_mphp_line, RGB(0, 255, 0));

			for (int i = 1; i < (int)mkfont.size() + 1; i++)
			{
				hplimit_num.push_back(new CMovingBitmap);
				hplimit_num[i]->LoadBitmap(335 + mkfont[i - 1] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "MPLimit")
		{
			mkfont = to_string(num);

			for (int i = 0; i < (int)mplimit_num.size(); i++)
			{
				delete mplimit_num[i];
			}

			mplimit_num.clear();
			mplimit_num.push_back(new CMovingBitmap);
			mplimit_num[0]->LoadBitmap(IDB_mphp_line, RGB(0, 255, 0));

			for (int i = 1; i < (int)mkfont.size() + 1; i++)
			{
				mplimit_num.push_back(new CMovingBitmap);
				mplimit_num[i]->LoadBitmap(335 + mkfont[i - 1] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "Damage")
		{
			mkfont = to_string(num);
			vector<CMovingBitmap*> dmg_vector;
			int init_x, init_y;
			init_x = x + (animationStandR.Width() / 2) - ((mkfont.length() * 38) / 2);
			init_y = y - 15 - 59;

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				dmg_vector.push_back(new CMovingBitmap);
				dmg_vector[i]->LoadBitmap(302 + mkfont[i] - 48, RGB(0, 255, 0));
				dmg_vector[i]->SetTopLeft(init_x + i * 38, init_y);
			}

			damagefont.push_back(dmg_vector);
			damagefont_timer.push_back(clock());
		}
		else if (type == "level")
		{
			mkfont = to_string(num);

			for (int i = 0; i < (int)level_num.size(); i++)
			{
				delete level_num[i];
			}

			level_num.clear();

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				level_num.push_back(new CMovingBitmap);
				level_num[i]->LoadBitmap(312 + mkfont[i] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "Q_cd")
		{
			ostringstream stream;
			stream << fixed << setprecision(1);
			stream << (double)num / 1000;
			mkfont = stream.str();

			for (int i = 0; i < (int)q_cd_time.size(); i++)
			{
				delete q_cd_time[i];
			}

			q_cd_time.clear();

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				q_cd_time.push_back(new CMovingBitmap);

				if (mkfont[i] == '.')
				{
					q_cd_time[i]->LoadBitmap(IDB_skill_dot, RGB(0, 255, 0));
				}
				else
				{
					q_cd_time[i]->LoadBitmap(324 + mkfont[i] - 48, RGB(0, 255, 0));
				}
			}
		}
		else if (type == "W_cd")
		{
			ostringstream stream;
			stream << fixed << setprecision(1);
			stream << (double)num / 1000;
			mkfont = stream.str();

			for (int i = 0; i < (int)w_cd_time.size(); i++)
			{
				delete w_cd_time[i];
			}

			w_cd_time.clear();

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				w_cd_time.push_back(new CMovingBitmap);

				if (mkfont[i] == '.')
				{
					w_cd_time[i]->LoadBitmap(IDB_skill_dot, RGB(0, 255, 0));
				}
				else
				{
					w_cd_time[i]->LoadBitmap(324 + mkfont[i] - 48, RGB(0, 255, 0));
				}
			}
		}
		else if (type == "E_cd")
		{
			ostringstream stream;
			stream << fixed << setprecision(1);
			stream << (double)num / 1000;
			mkfont = stream.str();

			for (int i = 0; i < (int)e_cd_time.size(); i++)
			{
				delete e_cd_time[i];
			}

			e_cd_time.clear();

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				if (mkfont[i] == '.')
				{
					break;
				}
				else
				{
					e_cd_time.push_back(new CMovingBitmap);
					e_cd_time[i]->LoadBitmap(324 + mkfont[i] - 48, RGB(0, 255, 0));
				}
			}
		}
		else if (type == "R_cd")
		{
			ostringstream stream;
			stream << fixed << setprecision(1);
			stream << (double)num / 1000;
			mkfont = stream.str();

			for (int i = 0; i < (int)r_cd_time.size(); i++)
			{
				delete r_cd_time[i];
			}

			r_cd_time.clear();

			for (int i = 0; i < (int)mkfont.size(); i++)
			{
				r_cd_time.push_back(new CMovingBitmap);

				if (mkfont[i] == '.')
				{
					r_cd_time[i]->LoadBitmap(IDB_skill_dot, RGB(0, 255, 0));
				}
				else
				{
					r_cd_time[i]->LoadBitmap(324 + mkfont[i] - 48, RGB(0, 255, 0));
				}
			}
		}
	}

	void Character::ShowDamageFont()
	{
		int del = -1;

		for (int i = 0; i < (int)damagefont.size(); i++)
		{
			for (int j = 0; j < (int)damagefont[i].size(); j++)
			{
				if (clock() - damagefont_timer[i] <= 400)
				{
					damagefont[i][j]->SetTopLeft(damagefont[i][j]->Left(), damagefont[i][j]->Top() - (int)(((clock() - damagefont_timer[i]) / 100) * 2));
					damagefont[i][j]->ShowBitmap();
				}
			}

			if (clock() - damagefont_timer[i] >= 1500)
			{
				del = i;
			}
		}

		if (del != -1)
		{
			for (int i = 0; i < del + 1; i++)
			{
				for (int j = 0; j < (int)damagefont[i].size(); j++)
				{
					delete damagefont[i][j];
				}
			}

			damagefont_timer.erase(damagefont_timer.begin(), damagefont_timer.begin() + del + 1);
			damagefont.erase(damagefont.begin(), damagefont.begin() + del + 1);
		}
	}

	void Character::ShowAuthor()
	{
		f1 = !f1;
		if (f1) {
			f2 = false;
			f3 = false;
		}
	}

	void Character::ShowHelp()
	{
		f2 = !f2;
		if (f2) {
			f2index = 0;
			f1 = false;
			f3 = false;
		}
	}

	void Character::ShowMission()
	{
		f3 = !f3;
		if (f3) {
			f1 = false;
			f2 = false;
		}
	}

	void Character::SetCheat()
	{
		lvl = 1000;
		damage = 10000;
		defense = 10000;
		hp = 10000;
		hp_limit = 10000;
		mp = 10000;
		mp_limit = 10000;
	}

	void Character::SetBackpack()
	{
		openBackpack = !openBackpack;
	}

	void Character::SetItemSelectIndex(int index)
	{
		itemselectindex = index;
	}

	void Character::SetPick(bool flag)
	{
		pickItem = flag;
	}

	void Character::SetUse(bool flag)
	{
		useItem = flag;
	}

	void Character::SetMovingDown(bool flag)
	{
		isMovingDown = flag;
		if (!flag) {
			isProne = flag;
		}
	}

	void Character::SetMovingLeft(bool flag)
	{
		if (isAttack && attackstate == "Q")
		{
			isMovingLeft = false;
		}
		else
		{
			isMovingLeft = flag;
		}
	}

	void Character::SetMovingRight(bool flag)
	{
		if (isAttack && attackstate == "Q")
		{
			isMovingRight = false;
		}
		else
		{
			isMovingRight = flag;
		}
	}

	void Character::SetMovingUp(bool flag)
	{
		isMovingUp = flag;
	}

	void Character::SetAttack(bool flag, string s)
	{
		isAttack = false;
		attackstate = s;
		if (attackstate == "Q"&& mp >= q_mp && (clock() - q_timer >= q_cd || q_timer == -1) && q_timer != 1 && onLadder == 0)
		{
			isAttack = flag;
			q_timer = 1;
			isMovingLeft = false;
			isMovingRight = false;
			isJump = false;
			CAudio::Instance()->Play(9);
		}
		if (attackstate == "W" && mp >= w_mp && (clock() - w_timer >= w_cd || w_timer == -1) && w_timer != 1)
		{
			isAttack = flag;
			wcount = 0;
			mp -= w_mp;
			w_timer = 1;
			wx = x + mw - map->getMapX();
			wy = y - 125 - map->getMapY();
			animationSkillW1.SetTopLeft(wx, wy);
			animationSkillW2.SetTopLeft(wx, wy);
			animationSkillW1.Reset();
			animationSkillW2.Reset();
			CAudio::Instance()->Play(10);
		}
		if (attackstate == "E" &&supercount == -1 && (clock() - e_timer >= e_cd || e_timer == -1) && e_timer != 1) {
			e_timer = 1;
			supercount = 0;
			isAttack = flag;
			CAudio::Instance()->Play(11);
		}
		if (attackstate == "R" && mp >= r_mp && (clock() - r_timer >= r_cd || r_timer == -1) && r_timer != 1 && onLadder == 0 && !isProne)
		{
			isAttack = flag;
			mp -= r_mp;
			r_timer = 1;
			CAudio::Instance()->Play(12);
		}
	}

	void Character::SetJump(bool flag)
	{
		if (isAttack && attackstate == "Q")
		{
			isJump = false;
		}
		else
		{
			isJump = flag;
		}
	}

	void Character::setEffect()
	{
		bool flag = false;
		backpack[itemselectindex]->SetNum(backpack[itemselectindex]->GetNum() - 1);
		useItem = false;

		if (backpack[itemselectindex]->GetName() == "�����Ĥ�")
		{
			for (int i = 0; i < (int)effect.size(); i++)
			{
				if (effect[i]->getName() == backpack[itemselectindex]->GetName())
				{
					effect[i]->setTime(10);
					flag = true;
				}
			}

			if (!flag)
			{
				effect.push_back(new Effect(backpack[itemselectindex]->GetName(), 10, 40));
			}
		}
		if (backpack[itemselectindex]->GetName() == "�W�Ŭ����Ĥ�")
		{
			for (int i = 0; i < (int)effect.size(); i++)
			{
				if (effect[i]->getName() == backpack[itemselectindex]->GetName())
				{
					effect[i]->setTime(10);
					flag = true;
				}
			}

			if (!flag)
			{
				effect.push_back(new Effect(backpack[itemselectindex]->GetName(), 10, 80));
			}
		}
		else if (backpack[itemselectindex]->GetName() == "�Ŧ��Ĥ�")
		{
			for (int i = 0; i < (int)effect.size(); i++)
			{
				if (effect[i]->getName() == backpack[itemselectindex]->GetName())
				{
					effect[i]->setTime(10);
					flag = true;
				}
			}

			if (!flag)
			{
				effect.push_back(new Effect(backpack[itemselectindex]->GetName(), 10, 50));
			}
		}
		else if (backpack[itemselectindex]->GetName() == "�W���Ŧ��Ĥ�")
		{
			for (int i = 0; i < (int)effect.size(); i++)
			{
				if (effect[i]->getName() == backpack[itemselectindex]->GetName())
				{
					effect[i]->setTime(10);
					flag = true;
				}
			}

			if (!flag)
			{
				effect.push_back(new Effect(backpack[itemselectindex]->GetName(), 10, 100));
			}
		}
		else if (backpack[itemselectindex]->GetName() == "���C0")
		{
			damage += 20;
		}
		else if (backpack[itemselectindex]->GetName() == "���C1")
		{
			damage += 50;
		}
		else if (backpack[itemselectindex]->GetName() == "���C2")
		{
			damage += 75;
		}
		else if (backpack[itemselectindex]->GetName() == "���C3")
		{
			damage += 200;
		}
		else if (backpack[itemselectindex]->GetName() == "�޵P0")
		{
			defense += 10;
		}
		else if (backpack[itemselectindex]->GetName() == "�޵P1")
		{
			defense += 30;
		}
		else if (backpack[itemselectindex]->GetName() == "�W��0")
		{
			hp_limit += 20;
		}
		else if (backpack[itemselectindex]->GetName() == "�W��1")
		{
			hp_limit += 50;
		}
		else if (backpack[itemselectindex]->GetName() == "�W��2")
		{
			hp_limit += 100;
		}

		if (backpack[itemselectindex]->GetNum() == 0)
		{
			delete backpack[itemselectindex];
			backpack.erase(backpack.begin() + itemselectindex);
		}
	}

	void Character::getEffect(string type)
	{
		for (int i = 0; i < (int)effect.size(); i++)
		{
			if (type == "hp")
			{
				if (effect[i]->getName() == "�����Ĥ�")
				{
					hp += effect[i]->getNum();
					effect[i]->setTime(-1);
				}
				if (effect[i]->getName() == "�W�Ŭ����Ĥ�")
				{
					hp += effect[i]->getNum();
					effect[i]->setTime(-1);
				}
			}
			else if (type == "mp")
			{
				if (effect[i]->getName() == "�Ŧ��Ĥ�")
				{
					mp += effect[i]->getNum();
					effect[i]->setTime(-1);
				}
				if (effect[i]->getName() == "�W���Ŧ��Ĥ�")
				{
					mp += effect[i]->getNum();
					effect[i]->setTime(-1);
				}
			}
		}

		for (int i = (int)effect.size() - 1; i >= 0; i--)
		{
			if (effect[i]->getTime() == 0)
			{
				delete effect[i];
				effect.erase(effect.begin() + i);
			}
		}
	}

	void Character::OnShow()
	{
		vector<int> del;
		playerinfo.SetTopLeft(338, 677);
		playerinfo.ShowBitmap();
		SkillQ.SetTopLeft(824, 0);
		SkillQ.ShowBitmap();
		SkillW.SetTopLeft(874, 0);
		SkillW.ShowBitmap();
		SkillE.SetTopLeft(924, 0);
		SkillE.ShowBitmap();
		SkillR.SetTopLeft(974, 0);
		SkillR.ShowBitmap();
		keymap.SetTopLeft(0, 768 - keymap.Height());
		keymap.ShowBitmap();
		MakeFont(lvl, "level");
		if (useItem) {
			if (f1) {
				f1 = false;
				useItem = false;
			}
			else if (f2) {
				f2index++;
				if (f2index > 3) {
					f2 = false;
					f2index = 0;
				}
				useItem = false;
			}
			else if (f3) {
				f3 = false;
				useItem = false;
			}
			if (currentMap == 7 && map->getMonsterHP() <= 0) {
				pass = true;
				useItem = false;
			}
		}
		for (int i = 0; i < (int)level_num.size(); i++)
		{
			level_num[i]->SetTopLeft(405 + 16 * i, 685);
			level_num[i]->ShowBitmap();
		}
		int tmp = (int)ceil((double)hp / hp_limit * 100);
		if (tmp > 100) {
			tmp = 100;
		}
		for (int i = 0; i < tmp; i++)
		{
			hp_pic[i]->SetTopLeft(379 + 3 * i, 717);
			hp_pic[i]->ShowBitmap();
		}
		tmp = (int)ceil((double)mp / mp_limit * 100);
		if (tmp > 100) {
			tmp = 100;
		}
		for (int i = 0; i < tmp; i++)
		{
			mp_pic[i]->SetTopLeft(379 + 3 * i, 741);
			mp_pic[i]->ShowBitmap();
		}

		MakeFont(hp, "HP");

		for (int i = (int)hp_num.size() - 1; i >= 0; i--)
		{
			hp_num[i]->SetTopLeft(519 - ((int)hp_num.size() - 1 - i) * 11, 720);
			hp_num[i]->ShowBitmap();
		}

		MakeFont(mp, "MP");

		for (int i = (int)mp_num.size() - 1; i >= 0; i--)
		{
			mp_num[i]->SetTopLeft(519 - ((int)mp_num.size() - 1 - i) * 11, 744);
			mp_num[i]->ShowBitmap();
		}

		MakeFont(hp_limit, "HPLimit");

		for (int i = (int)hplimit_num.size() - 1; i >= 0; i--)
		{
			hplimit_num[i]->SetTopLeft(529 + i * 11, 720);
			hplimit_num[i]->ShowBitmap();
		}

		MakeFont(mp_limit, "MPLimit");

		for (int i = (int)mplimit_num.size() - 1; i >= 0; i--)
		{
			mplimit_num[i]->SetTopLeft(529 + i * 11, 744);
			mplimit_num[i]->ShowBitmap();
		}

		expbar.SetTopLeft(0, 763);
		expbar.ShowBitmap();
		for (int i = 0; i < (int)exp.size(); i++) {
			delete exp[i];
		}
		exp.clear();
		int temp = (int)ceil((double)expr / LevelUp(lvl) * 128);
		if (temp > 128) {
			temp = 128;
		}
		for (int i = 0; i < temp; i++) {
			exp.push_back(new CMovingBitmap);
			exp[i]->LoadBitmap(IDB_exp);
			exp[i]->SetTopLeft(8 * i, 763);
			exp[i]->ShowBitmap();
		}
		if (hp <= 0) {
			hp = 0;
			if (tomb.Top() < y - 29) {
				tomb.SetTopLeft(x, tomb.Top() + 15);
			}
			else {
				vector<int> pos;
				pos.push_back(tomb.Left());
				pos.push_back(tomb.Top() + 29);
				JudgeArea(&pos, "tomb");
				tomb.SetTopLeft(x, pos[1] - 29);
				if (useItem) {
					Relive();
				}
			}
			tomb.ShowBitmap();
			CMovingBitmap die_dialog;
			die_dialog.LoadBitmap(IDB_die_dialog);
			die_dialog.SetTopLeft(256, 304);
			die_dialog.ShowBitmap();
			return;
		}
		if (openBackpack)
		{
			backpack_ui.SetTopLeft(858, 75);
			backpack_ui.ShowBitmap();

			for (int i = 0; i < (int)backpack.size(); i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (backpack[i]->GetName() == backpack[j]->GetName())
					{
						backpack[j]->SetNum(backpack[j]->GetNum() + 1);
						del.push_back(i);
						break;
					}
				}
			}

			for (int i = (int)del.size() - 1; i >= 0; i--)
			{
				delete backpack[del[i]];
				backpack.erase(backpack.begin() + del[i]);
			}

			for (int i = 0; i < (int)backpack.size(); i++)
			{
				backpack[i]->SetTopLeft(867 + (i % 4) * 36, 103 + (i / 4) * 35);
				backpack[i]->onShow(0, 0, false);
				backpack[i]->ShowNum();
			}

			itemselected_ui.SetTopLeft(865 + (itemselectindex % 4) * 36, 101 + (itemselectindex / 4) * 35);
			itemselected_ui.ShowBitmap();
		}

		if (useItem && openBackpack && itemselectindex < (int)backpack.size())
		{
			setEffect();
		}
		ShowDamageFont();
		if (q_cd - (clock() - q_timer) > 0 && q_timer != -1 && q_timer != 1)
		{
			MakeFont(int(q_cd - (clock() - q_timer)), "Q_cd");

			for (int i = 0; i < (int)q_cd_time.size(); i++)
			{
				q_cd_time[i]->SetTopLeft(830 + i * 12, 50);
				q_cd_time[i]->ShowBitmap();
			}
		}

		if (w_cd - (clock() - w_timer) > 0 && w_timer != -1 && w_timer != 1)
		{
			MakeFont(int(w_cd - (clock() - w_timer)), "W_cd");

			for (int i = 0; i < (int)w_cd_time.size(); i++)
			{
				w_cd_time[i]->SetTopLeft(880 + i * 12, 50);
				w_cd_time[i]->ShowBitmap();
			}
		}

		if (e_cd - (clock() - e_timer) > 0 && e_timer != -1 && e_timer != 1)
		{
			MakeFont(int(e_cd - (clock() - e_timer)), "E_cd");

			for (int i = 0; i < (int)e_cd_time.size(); i++)
			{
				e_cd_time[i]->SetTopLeft(935 + i * 12, 50);
				e_cd_time[i]->ShowBitmap();
			}
		}

		if (r_cd - (clock() - r_timer) > 0 && r_timer != -1 && r_timer != 1)
		{
			MakeFont(int(r_cd - (clock() - r_timer)), "R_cd");

			for (int i = 0; i < (int)r_cd_time.size(); i++)
			{
				r_cd_time[i]->SetTopLeft(985 + i * 12, 50);
				r_cd_time[i]->ShowBitmap();
			}
		}

		if (w_timer == 1)
		{
			if (wcount == 3)
			{
				animationSkillW2.SetTopLeft(wx + map->getMapX(), wy + map->getMapY());
				animationSkillW2.OnShow();
			}
			else
			{
				animationSkillW1.SetTopLeft(wx + map->getMapX(), wy + map->getMapY());
				animationSkillW1.OnShow();
			}
		}
		if (e_timer == 1) {
			animationSkillE.SetTopLeft(x + mw, y - mh * 2);
			animationSkillE.OnShow();
		}

		if (isJump)
		{
			if (direction == 0)
			{
				animationJumpR.SetTopLeft(x + mw, y + mh);
				animationJumpR.OnShow();
			}
			else
			{
				animationJumpL.SetTopLeft(x + mw, y + mh);
				animationJumpL.OnShow();
			}
		}
		else if (q_timer == 1)
		{
			if (direction == 0)
			{
				animationAttackR.SetTopLeft(x + mw, y + mh);
				animationAttackR.OnShow();

				if (animationAttackR.IsFinalBitmap())
				{
					animationSkillQR.SetTopLeft(x + animationStandR.Width() + (animationSkillQL.Width() / 2), y + (animationSkillQL.Height() / 2));
					animationSkillQR.OnShow();
				}
			}
			else
			{
				animationAttackL.SetTopLeft(x + mw, y + mh);
				animationAttackL.OnShow();

				if (animationAttackL.IsFinalBitmap())
				{
					animationSkillQL.SetTopLeft(x - (animationSkillQL.Width() / 2), y + (animationSkillQL.Height() / 2));
					animationSkillQL.OnShow();
				}
			}
		}
		else if (isMovingRight && onLadder == 0)
		{
			animationWalkR.SetTopLeft(x + mw, y + mh);
			animationWalkR.OnShow();
			direction = 0;
		}
		else if (isMovingLeft && onLadder == 0)
		{
			animationWalkL.SetTopLeft(x + mw, y + mh);
			animationWalkL.OnShow();
			direction = 1;
		}
		else if (isMovingDown && onLadder == 0 && !isJump && Fall == 0)
		{
			if (direction == 0)
			{
				animationProneR.SetTopLeft(x + mw, y + mh);
				animationProneR.OnShow();
			}
			else
			{
				animationProneL.SetTopLeft(x + mw, y + mh);
				animationProneL.OnShow();
			}
		}
		else if (onLadder == 1)
		{
			animationLadder.SetTopLeft(x + mw, y + mh);
			animationLadder.OnShow();
		}
		else if (direction == 0 && onLadder == 0)
		{
			if (ishit && clock() - hit_timer <= 1000)
			{
				animationGetHitR.SetTopLeft(x + mw, y + mh);
				animationGetHitR.OnShow();
			}
			else
			{
				animationStandR.SetTopLeft(x + mw, y + mh);
				animationStandR.OnShow();
			}
		}
		else if (direction == 1 && onLadder == 0)
		{
			if (ishit && clock() - hit_timer <= 1000)
			{
				animationGetHitL.SetTopLeft(x + mw, y + mh);
				animationGetHitL.OnShow();
			}
			else
			{
				animationStandL.SetTopLeft(x + mw, y + mh);
				animationStandL.OnShow();
			}
		}
		if (currentMap == 7 && map->getMonsterHP() <= 0 && !pass) {
			success.SetTopLeft((1024 - success.Width()) / 2, (768 - success.Height()) / 2);
			success.ShowBitmap();
		}
		if (f1) {
			author.SetTopLeft(252, 256);
			author.ShowBitmap();
		}
		if (f2) {
			help[f2index]->SetTopLeft((1024 - help[f2index]->Width()) / 2, (768 - help[f2index]->Height()) / 2);
			help[f2index]->ShowBitmap();
		}
		if (f3) {
			mission.SetTopLeft((1024 - mission.Width()) / 2, (768 - mission.Height()) / 2);
			mission.ShowBitmap();
		}
	}

	void Character::OnMove()
	{
		if (hp <= 0) {
			return;
		}
		int totaldmg = 0, getdmg = map->Monsterhit(x, y, x + animationStandR.Width(), y + animationStandR.Height(), defense);
		if (supercount != -1) {
			getdmg = 0;
		}
		if (getdmg != 0)
		{
			hp -= getdmg;
			getdmg = 0;
			ishit = true;
			hit_timer = clock();
			if (hp <= 0) {
				tomb.SetTopLeft(x, 0);
				tomb.ShowBitmap();
			}
		}

		if (clock() - mp_timer >= 1000 && hp != 0)
		{
			getEffect("mp");
			mp += lvl;
			mp_timer = clock();

			if (mp > mp_limit)
			{
				mp = mp_limit;
			}
		}

		if (clock() - hp_timer >= 1000 && hp != 0)
		{
			getEffect("hp");
			hp += 3 * lvl;
			hp_timer = clock();

			if (hp > hp_limit)
			{
				hp = hp_limit;
			}
		}

		if (expr >= LevelUp(lvl))
		{
			CAudio::Instance()->Play(14);
			expr -= LevelUp(lvl);
			lvl++;
			hp_limit += 50;
			mp_limit += 30;
			hp = hp_limit;
			mp = mp_limit;
			q_mp += 15;
			w_mp += 30;
		}
		if (pickItem)
		{
			map->PickItem(x - map->getMapX(), y - map->getMapY(), animationStandR.Width(), animationStandR.Height(), &backpack);
		}

		pos.clear();
		pos.push_back(x);
		pos.push_back(y);
		JudgeArea(&pos, "null");

		if (w_timer == 1)
		{
			if (wcount == 3)
			{
				animationSkillW2.OnMove();

				if (animationSkillW2.IsFinalBitmap())
				{
					expr += map->hitMonster(x, y, animationSkillW1.Left(), animationSkillW1.Top(), animationSkillW1.Left() + animationSkillW1.Width(), animationSkillW1.Top() + animationSkillW1.Height(), 150 + damage + 25 * (lvl - 1), animationSkillW2.IsFinalBitmap(), &totaldmg);
					isAttack = false;
					w_timer = clock();

					if (totaldmg > 0)
					{
						MakeFont(totaldmg, "Damage");
					}

					animationSkillW1.Reset();
					animationSkillW2.Reset();
					wcount = -1;
				}
			}
			else if (animationSkillW1.IsFinalBitmap())
			{
				expr += map->hitMonster(x, y, animationSkillW1.Left(), animationSkillW1.Top(), animationSkillW1.Left() + animationSkillW1.Width(), animationSkillW1.Top() + animationSkillW1.Height(), 50 + damage + 25 * (lvl - 1), animationSkillW1.IsFinalBitmap(), &totaldmg);

				if (totaldmg > 0)
				{
					MakeFont(totaldmg, "Damage");
				}

				if (wcount < 3)
				{
					wcount++;
					animationSkillW1.Reset();
				}
			}
			else
			{
				animationSkillW1.OnMove();
			}
		}
		if (e_timer == 1) {
			animationSkillE.OnMove();
			if (animationSkillE.IsFinalBitmap()) {
				supercount++;
				animationSkillE.Reset();
			}
			if (supercount == 5) {
				supercount = -1;
				animationSkillE.Reset();
				isAttack = false;
				e_timer = clock();
			}
		}
		if (q_timer == 1)
		{
			if (direction == 0)
			{
				if (animationAttackR.IsFinalBitmap())
				{
					animationSkillQR.OnMove();
					expr += map->hitMonster(x, y, animationSkillQR.Left(), animationSkillQR.Top(), animationSkillQR.Left() + animationSkillQR.Width(), animationSkillQR.Top() + (animationSkillQR.Height() / 2), 100 + damage + 25 * (lvl - 1), animationSkillQR.IsFinalBitmap(), &totaldmg);

					if (animationSkillQR.IsFinalBitmap())
					{
						isAttack = false;
						animationAttackR.Reset();
						animationSkillQR.Reset();
						q_timer = clock();
						mp -= q_mp;

						if (totaldmg > 0)
						{
							MakeFont(totaldmg, "Damage");
						}
					}
				}
				else
				{
					animationAttackR.OnMove();
				}
			}
			else
			{
				if (animationAttackL.IsFinalBitmap())
				{
					animationSkillQL.OnMove();
					expr += map->hitMonster(x, y, animationSkillQL.Left(), animationSkillQL.Top(), animationSkillQL.Left() + animationSkillQL.Width(), animationSkillQL.Top() + (animationSkillQL.Height() / 2), 100 + damage + 25 * (lvl - 1), animationSkillQL.IsFinalBitmap(), &totaldmg);

					if (animationSkillQL.IsFinalBitmap())
					{
						isAttack = false;
						animationAttackL.Reset();
						animationSkillQL.Reset();
						q_timer = clock();
						mp -= q_mp;

						if (totaldmg > 0)
						{
							MakeFont(totaldmg, "Damage");
						}
					}
				}
				else
				{
					animationAttackL.OnMove();
				}
			}
		}
		if (isAttack&&attackstate == "R") {
			if (direction == 0) {
				if (JudgeArea(&pos, "RR"))
				{
					direction = 0;
					x = pos[0];
					y = pos[1];
				}
			}
			else {
				if (JudgeArea(&pos, "RL"))
				{
					direction = 1;
					x = pos[0];
					y = pos[1];
				}
			}
		}

		if (isMovingLeft)
		{
			if (JudgeArea(&pos, "left"))
			{
				direction = 1;
				x = pos[0];
				y = pos[1];
			}
		}
		else if (isMovingRight)
		{
			if (JudgeArea(&pos, "right"))
			{
				direction = 0;
				x = pos[0];
				y = pos[1];
			}
		}
		else if (isMovingUp)
		{
			if (JudgeArea(&pos, "up"))
			{
				x = pos[0];
				y = pos[1];
			}
		}
		else if (isMovingDown)
		{
			if (JudgeArea(&pos, "down"))
			{
				x = pos[0];
				y = pos[1];
			}
		}
		else if (direction == 0)
		{
			if (ishit && clock() - hit_timer <= 1000)
			{
				animationGetHitR.OnMove();
			}
			else
			{
				ishit = false;
				animationStandR.OnMove();
			}
		}
		else if (direction == 1)
		{
			if (ishit && clock() - hit_timer <= 1000)
			{
				animationGetHitL.OnMove();
			}
			else
			{
				ishit = false;
				animationStandL.OnMove();
			}
		}

		if (isJump)
		{
			if (onLadder == 1)
			{
				onLadder = 0;
				velocity = 6;
			}

			if (Fall == 1)
			{
				isJump = false;
			}
			else if (JudgeArea(&pos, "jump"))
			{
				y = pos[1];
			}
		}

		if (Fall == 1)
		{
			if (JudgeArea(&pos, "fall"))
			{
				if (map->isArea(&pos))
				{
					Fall = 0;
					velocity = initial_velocity;
					isJump = false;
				}

				x = pos[0];
				y = pos[1];
			}
		}
	}
	void Character::Jump(vector<int>* pos, string move)
	{
		if (move == "jump")
		{
			if (velocity > initial_velocity)
			{
				velocity = initial_velocity;
			}

			if (velocity > 0)
			{
				(*pos)[1] -= velocity;
				velocity--;
			}
			else
			{
				Fall = 1;
				velocity = 1;
			}
		}
		else
		{
			if (velocity < 18)
			{
				velocity++;
			}

			(*pos)[1] += velocity;
		}
	}

	bool Character::JudgeArea(vector<int>* pos, string dir)
	{
		if (!isJump && onLadder == 0)
		{
			if (!map->isArea(pos))
			{
				if (Fall == 1)
				{
					isJump = false;
				}
				else
				{
					Fall = 1;
					velocity = 1;
				}
			}
		}
		if (dir == "tomb") {
			if (!map->isArea(pos))
			{
				(*pos)[1] += 15;
			}
		}
		if (dir == "RR"&&onLadder == 0) {
			if (!map->isEdge(pos, "RR"))
			{
				if ((*pos)[0] + 250 <= 600)
				{
					(*pos)[0] += 250;
				}
				else {
					(*pos)[0] += map->scrollRight(250);
				}
				if ((*pos)[0] - map->getMapX() > map->getEdgex2()) {
					(*pos)[0] = map->getEdgex2() + map->getMapX() - 34;
				}
			}
			isAttack = false;
			r_timer = clock();
		}
		else if (dir == "RL"&&onLadder == 0) {
			if (!map->isEdge(pos, "RL"))
			{
				if ((*pos)[0] - 250 >= 350)
				{
					(*pos)[0] -= 250;
				}
				else
				{
					(*pos)[0] -= map->scrollLeft(250);
				}
				if ((*pos)[0] - map->getMapX() < map->getEdgex1()) {
					(*pos)[0] = map->getEdgex1() + map->getMapX() - 34;
				}
			}
			isAttack = false;
			r_timer = clock();
		}
		if (dir == "left" && onLadder == 0)
		{
			if (!map->isEdge(pos, "left"))
			{
				if ((*pos)[0] - 5 >= 350)
				{
					(*pos)[0] -= 5;
				}
				else
				{
					(*pos)[0] -= map->scrollLeft(5);
				}
			}

			animationWalkL.OnMove();
		}

		if (dir == "right" && onLadder == 0)
		{
			if (!map->isEdge(pos, "right"))
			{
				if ((*pos)[0] + 5 <= 600)
				{
					(*pos)[0] += 5;
				}
				else
				{
					(*pos)[0] += map->scrollRight(5);
				}
			}

			animationWalkR.OnMove();
		}

		if (dir == "up")
		{
			if (onLadder == 0)
			{
				if (map->isTeleport(pos))
				{
					int tmp = currentMap;
					currentMap = map->setTeleport(pos);
					isMovingUp = false;
					if (tmp != currentMap) {
						if (q_timer == 1) {
							q_timer = clock();
							isAttack = false;
						}
						if (w_timer == 1) {
							w_timer = clock();
							isAttack = false;
							wcount = -1;
						}
					}
				}
				else if (map->isLadder(pos, dir))
				{
					map->setLadder(pos, dir);
					onLadder = 1;
					velocity = initial_velocity;
					animationLadder.OnShow();
					isMovingLeft = false;
					isMovingRight = false;
					isJump = false;
					Fall = 0;
				}
			}
			else
			{
				(*pos)[1] -= 5;
				isJump = false;
				animationLadder.OnMove();

				if (map->isArea(pos))
				{
					onLadder = 0;
				}
			}
		}

		if (dir == "down")
		{
			if (map->isLadder(pos, dir) && onLadder == 0)
			{
				map->setLadder(pos, dir);
				onLadder = 1;
				velocity = initial_velocity;
				animationLadder.OnShow();
				isMovingLeft = false;
				isMovingRight = false;
				isJump = false;
				Fall = 0;
			}
			else if (onLadder == 0 && !isJump && Fall == 0)
			{
				isProne = true;
				if (direction == 0)
				{
					animationProneR.OnMove();
				}
				else
				{
					animationProneL.OnMove();
				}
			}
			else if (onLadder == 1)
			{
				(*pos)[1] += 5;
				animationLadder.OnMove();

				if (map->isArea(pos))
				{
					onLadder = 0;
				}
			}
		}

		if (dir == "jump" || dir == "fall")
		{
			Jump(pos, dir);

			if (direction == 0)
			{
				animationJumpR.OnMove();
			}
			else
			{
				animationJumpL.OnMove();
			}
		}

		return true;
	}
	bool Character::GetBackpack()
	{
		return openBackpack;
	}
}