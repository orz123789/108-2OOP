#include "stdafx.h"
#include "Resource.h"
#include <mmsystem.h>
#include <ddraw.h>
#include "audio.h"
#include "gamelib.h"
#include "Item.h"
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
namespace game_framework
{
	Item::Item(int px, int py, string s)
	{
		timer_show = clock();
		x = px;
		y = py;
		name = s;
		num = 1;
		LoadBitmap();
	}
	Item::~Item()
	{
		for (int i = 0; i < (int)numfont.size(); i++)
		{
			delete numfont[i];
		}
	}
	void Item::LoadBitmap()
	{
		if (name == "�����Ĥ�")
		{
			item_pic.LoadBitmap(IDB_potion_red, RGB(0, 255, 0));
		}
		else if (name == "�W�Ŭ����Ĥ�")
		{
			item_pic.LoadBitmap(IDB_superred, RGB(0, 255, 0));
		}
		else if (name == "�Ŧ��Ĥ�")
		{
			item_pic.LoadBitmap(IDB_potion_blue, RGB(0, 255, 0));
		}
		else if (name == "�W���Ŧ��Ĥ�")
		{
			item_pic.LoadBitmap(IDB_superblue, RGB(0, 255, 0));
		}
		else if (name == "���C0")
		{
			item_pic.LoadBitmap(IDB_sword_0, RGB(0, 255, 0));
		}
		else if (name == "���C1")
		{
			item_pic.LoadBitmap(IDB_sword_1, RGB(0, 255, 0));
		}
		else if (name == "���C2")
		{
			item_pic.LoadBitmap(IDB_sword_2, RGB(0, 255, 0));
		}
		else if (name == "���C3")
		{
			item_pic.LoadBitmap(IDB_sword_3, RGB(0, 255, 0));
		}
		else if (name == "�޵P0")
		{
			item_pic.LoadBitmap(IDB_shield_0, RGB(0, 255, 0));
		}
		else if (name == "�޵P1")
		{
			item_pic.LoadBitmap(IDB_shield_1, RGB(0, 255, 0));
		}
		else if (name == "�W��0")
		{
			item_pic.LoadBitmap(IDB_cloth_0, RGB(0, 255, 0));
		}
		else if (name == "�W��1")
		{
			item_pic.LoadBitmap(IDB_cloth_1, RGB(0, 255, 0));
		}
		else if (name == "�W��2")
		{
			item_pic.LoadBitmap(IDB_cloth_2, RGB(0, 255, 0));
		}
	}
	void Item::SetTopLeft(int x1, int y1)
	{
		x = x1;
		y = y1;
	}
	void Item::onShow(int MapX, int MapY, bool floating)
	{
		if (floating)
		{
			item_pic.SetTopLeft(x + MapX, y + MapY - 5);
		}
		else
		{
			item_pic.SetTopLeft(x + MapX, y + MapY);
		}

		item_pic.ShowBitmap();
	}
	int Item::GetX()
	{
		return x;
	}
	int Item::GetY()
	{
		return y;
	}
	int Item::GetWidth()
	{
		return item_pic.Width();
	}
	int Item::GetHeight()
	{
		return item_pic.Height();
	}
	int Item::GetNum()
	{
		return num;
	}
	string Item::GetName()
	{
		return name;
	}
	double Item::GetShowTime()
	{
		return timer_show;
	}
	void Item::SetNum(int n)
	{
		num = n;
	}
	void Item::ShowNum()
	{
		string s = to_string(num);

		for (int i = 0; i < (int)numfont.size(); i++)
		{
			delete numfont[i];
		}

		numfont.clear();

		for (int i = 0; i < (int)s.size(); i++)
		{
			numfont.push_back(new CMovingBitmap);
			numfont[i]->LoadBitmap(335 + s[i] - 48, RGB(0, 255, 0));
			numfont[i]->SetTopLeft(x + 30 - (s.length() - i)*numfont[i]->Width(), y + 30 - numfont[i]->Height());
			numfont[i]->ShowBitmap();
		}
	}
}