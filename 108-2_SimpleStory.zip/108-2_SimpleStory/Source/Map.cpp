#include "stdafx.h"
#include "Resource.h"
#include <mmsystem.h>
#include <ddraw.h>
#include "audio.h"
#include "gamelib.h"
#include "Map.h"
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>

namespace game_framework
{
	Map::~Map()
	{
		for (int i = 0; i < (int)monster.size(); i++)
		{
			delete monster[i];
		}

		for (int i = 0; i < (int)item.size(); i++)
		{
			delete item[i];
		}

		delete background;
	}
	void Map::Initialize(int map, int tmp)
	{
		vector<int> Areaxy;
		vector<int> Ladderxy;
		vector<int> Teleportxy;
		int random;
		currentMap = map;
		Area.clear();
		Ladder.clear();
		Teleport.clear();
		music = floating = false;
		item_floating = -1;

		for (int i = 0; i < int(monster.size()); i++)
		{
			delete monster[i];
		}

		monster.clear();

		if (background != NULL)
		{
			delete background;
		}

		for (int i = 0; i < int(item.size()); i++)
		{
			delete item[i];
		}

		item.clear();

		if (currentMap == 0)
		{
			Areaxy.clear();
			Areaxy.push_back(80);
			Areaxy.push_back(440);
			Areaxy.push_back(715);
			Areaxy.push_back(440);
			Area.push_back(Areaxy);
			Teleportxy.clear();
			Teleportxy.push_back(650);
			Teleportxy.push_back(440);
			Teleportxy.push_back(715);
			Teleportxy.push_back(440);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map01);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];
		}
		else if (currentMap == 1)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(610);
			Areaxy.push_back(1985);
			Areaxy.push_back(610);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(313);
			Areaxy.push_back(610);
			Areaxy.push_back(313);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(630);
			Areaxy.push_back(363);
			Areaxy.push_back(1130);
			Areaxy.push_back(363);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(480);
			Areaxy.push_back(116);
			Areaxy.push_back(1057);
			Areaxy.push_back(116);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(1075);
			Areaxy.push_back(165);
			Areaxy.push_back(1796);
			Areaxy.push_back(165);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(1667);
			Areaxy.push_back(313);
			Areaxy.push_back(1985);
			Areaxy.push_back(313);
			Area.push_back(Areaxy);
			Ladderxy.clear();
			Ladderxy.push_back(260);
			Ladderxy.push_back(313);
			Ladderxy.push_back(292);
			Ladderxy.push_back(495);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(575);
			Ladderxy.push_back(116);
			Ladderxy.push_back(607);
			Ladderxy.push_back(220);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(994);
			Ladderxy.push_back(116);
			Ladderxy.push_back(1026);
			Ladderxy.push_back(250);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(769);
			Ladderxy.push_back(363);
			Ladderxy.push_back(801);
			Ladderxy.push_back(495);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(1684);
			Ladderxy.push_back(165);
			Ladderxy.push_back(1716);
			Ladderxy.push_back(222);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(1772);
			Ladderxy.push_back(313);
			Ladderxy.push_back(1804);
			Ladderxy.push_back(495);
			Ladder.push_back(Ladderxy);
			Teleportxy.clear();
			Teleportxy.push_back(25);
			Teleportxy.push_back(610);
			Teleportxy.push_back(95);
			Teleportxy.push_back(610);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			Teleportxy.clear();
			Teleportxy.push_back(1895);
			Teleportxy.push_back(610);
			Teleportxy.push_back(1965);
			Teleportxy.push_back(610);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map11);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];

			for (int i = 0; i < int(Area.size()); i++)
			{
				srand((unsigned)time(NULL));

				for (int j = Area[i][0]; j < Area[i][2]; j += random)
				{
					random = rand() % 2;
					monster.push_back(new Monster(j, Area[i][1], random, Area[i], currentMap, 10, 150, 25, 5));
					random = rand() % 50 + 70;
				}
			}
		}
		else if (currentMap == 2)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(628);
			Areaxy.push_back(1500);
			Areaxy.push_back(628);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(32);
			Areaxy.push_back(363);
			Areaxy.push_back(412);
			Areaxy.push_back(363);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(428);
			Areaxy.push_back(408);
			Areaxy.push_back(940);
			Areaxy.push_back(408);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(1023);
			Areaxy.push_back(408);
			Areaxy.push_back(1500);
			Areaxy.push_back(408);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(33);
			Areaxy.push_back(145);
			Areaxy.push_back(413);
			Areaxy.push_back(145);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(429);
			Areaxy.push_back(189);
			Areaxy.push_back(940);
			Areaxy.push_back(189);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(956);
			Areaxy.push_back(144);
			Areaxy.push_back(1335);
			Areaxy.push_back(144);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(1285);
			Areaxy.push_back(57);
			Areaxy.push_back(1467);
			Areaxy.push_back(57);
			Area.push_back(Areaxy);
			Ladderxy.clear();
			Ladderxy.push_back(299);
			Ladderxy.push_back(363);
			Ladderxy.push_back(327);
			Ladderxy.push_back(525);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(602);
			Ladderxy.push_back(408);
			Ladderxy.push_back(630);
			Ladderxy.push_back(525);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(1141);
			Ladderxy.push_back(408);
			Ladderxy.push_back(1169);
			Ladderxy.push_back(525);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(225);
			Ladderxy.push_back(145);
			Ladderxy.push_back(253);
			Ladderxy.push_back(264);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(743);
			Ladderxy.push_back(189);
			Ladderxy.push_back(771);
			Ladderxy.push_back(307);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(1244);
			Ladderxy.push_back(144);
			Ladderxy.push_back(1272);
			Ladderxy.push_back(319);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(1337);
			Ladderxy.push_back(57);
			Ladderxy.push_back(1365);
			Ladderxy.push_back(93);
			Ladder.push_back(Ladderxy);
			Teleportxy.clear();
			Teleportxy.push_back(25);
			Teleportxy.push_back(628);
			Teleportxy.push_back(95);
			Teleportxy.push_back(628);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			Teleportxy.clear();
			Teleportxy.push_back(1420);
			Teleportxy.push_back(628);
			Teleportxy.push_back(1490);
			Teleportxy.push_back(628);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map12);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];

			for (int i = 0; i < int(Area.size()); i++)
			{
				srand((unsigned)time(NULL));

				for (int j = Area[i][0]; j < Area[i][2]; j += random)
				{
					random = rand() % 2;
					monster.push_back(new Monster(j, Area[i][1], random, Area[i], currentMap, 25, 300, 40, 15));
					random = rand() % 50 + 70;
				}
			}
		}
		else if (currentMap == 3)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(508);
			Areaxy.push_back(1420);
			Areaxy.push_back(508);
			Area.push_back(Areaxy);
			Teleportxy.clear();
			Teleportxy.push_back(20);
			Teleportxy.push_back(508);
			Teleportxy.push_back(95);
			Teleportxy.push_back(508);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			Teleportxy.clear();
			Teleportxy.push_back(1345);
			Teleportxy.push_back(508);
			Teleportxy.push_back(1420);
			Teleportxy.push_back(508);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map14);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];
			monster.push_back(new Monster(750, Area[0][1], 0, Area[0], currentMap, 300, 500, 150, 100));
		}
		else if (currentMap == 4)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(595);
			Areaxy.push_back(1805);
			Areaxy.push_back(595);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(240);
			Areaxy.push_back(355);
			Areaxy.push_back(655);
			Areaxy.push_back(355);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(690);
			Areaxy.push_back(295);
			Areaxy.push_back(1195);
			Areaxy.push_back(295);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(175);
			Areaxy.push_back(295);
			Areaxy.push_back(175);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(330);
			Areaxy.push_back(115);
			Areaxy.push_back(835);
			Areaxy.push_back(115);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(1230);
			Areaxy.push_back(355);
			Areaxy.push_back(1555);
			Areaxy.push_back(355);
			Area.push_back(Areaxy);
			Ladderxy.clear();
			Ladderxy.push_back(435);
			Ladderxy.push_back(355);
			Ladderxy.push_back(480);
			Ladderxy.push_back(515);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(240);
			Ladderxy.push_back(175);
			Ladderxy.push_back(285);
			Ladderxy.push_back(275);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(705);
			Ladderxy.push_back(115);
			Ladderxy.push_back(750);
			Ladderxy.push_back(215);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(1025);
			Ladderxy.push_back(295);
			Ladderxy.push_back(1070);
			Ladderxy.push_back(500);
			Ladder.push_back(Ladderxy);
			Teleportxy.clear();
			Teleportxy.push_back(25);
			Teleportxy.push_back(595);
			Teleportxy.push_back(100);
			Teleportxy.push_back(595);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			Teleportxy.clear();
			Teleportxy.push_back(1715);
			Teleportxy.push_back(595);
			Teleportxy.push_back(1790);
			Teleportxy.push_back(595);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map23);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];

			for (int i = 0; i < int(Area.size()); i++)
			{
				srand((unsigned)time(NULL));

				for (int j = Area[i][0]; j < Area[i][2]; j += random)
				{
					random = rand() % 2;
					monster.push_back(new Monster(j, Area[i][1], random, Area[i], currentMap, 200, 750, 100, 30));
					random = rand() % 80 + 90;
				}
			}
		}
		else if (currentMap == 5)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(622);
			Areaxy.push_back(1199);
			Areaxy.push_back(622);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(385);
			Areaxy.push_back(1119);
			Areaxy.push_back(385);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(145);
			Areaxy.push_back(849);
			Areaxy.push_back(145);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(885);
			Areaxy.push_back(145);
			Areaxy.push_back(939);
			Areaxy.push_back(145);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(975);
			Areaxy.push_back(145);
			Areaxy.push_back(1029);
			Areaxy.push_back(145);
			Area.push_back(Areaxy);
			Ladderxy.clear();
			Ladderxy.push_back(378);
			Ladderxy.push_back(385);
			Ladderxy.push_back(410);
			Ladderxy.push_back(515);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(800);
			Ladderxy.push_back(385);
			Ladderxy.push_back(832);
			Ladderxy.push_back(515);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(261);
			Ladderxy.push_back(145);
			Ladderxy.push_back(293);
			Ladderxy.push_back(272);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(581);
			Ladderxy.push_back(145);
			Ladderxy.push_back(613);
			Ladderxy.push_back(272);
			Ladder.push_back(Ladderxy);
			Teleportxy.clear();
			Teleportxy.push_back(15);
			Teleportxy.push_back(145);
			Teleportxy.push_back(86);
			Teleportxy.push_back(145);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			Teleportxy.clear();
			Teleportxy.push_back(1127);
			Teleportxy.push_back(622);
			Teleportxy.push_back(1198);
			Teleportxy.push_back(622);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map22);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];

			for (int i = 0; i < int(Area.size()); i++)
			{
				srand((unsigned)time(NULL));

				for (int j = Area[i][0]; j < Area[i][2]; j += random)
				{
					random = rand() % 2;
					monster.push_back(new Monster(j, Area[i][1], random, Area[i], currentMap, 300, 900, 125, 50));
					random = rand() % 80 + 90;
				}
			}
		}
		else if (currentMap == 6)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(660);
			Areaxy.push_back(1190);
			Areaxy.push_back(660);
			Area.push_back(Areaxy);
			Teleportxy.clear();
			Teleportxy.push_back(10);
			Teleportxy.push_back(660);
			Teleportxy.push_back(85);
			Teleportxy.push_back(660);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			Teleportxy.clear();
			Teleportxy.push_back(1113);
			Teleportxy.push_back(660);
			Teleportxy.push_back(1188);
			Teleportxy.push_back(660);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map24);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];
			monster.push_back(new Monster((Area[0][3] - Area[0][0]) / 2, Area[0][1], 1, Area[0], currentMap, 5000, 2000, 600, 100));
		}
		else if (currentMap == 7)
		{
			Areaxy.clear();
			Areaxy.push_back(0);
			Areaxy.push_back(625);
			Areaxy.push_back(1326);
			Areaxy.push_back(626);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(390);
			Areaxy.push_back(565);
			Areaxy.push_back(1020);
			Areaxy.push_back(565);
			Area.push_back(Areaxy);
			Teleportxy.clear();
			Teleportxy.push_back(15);
			Teleportxy.push_back(625);
			Teleportxy.push_back(80);
			Teleportxy.push_back(625);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map31);
			edgex1 = Area[0][0];
			edgex2 = Area[0][2];
			monster.push_back(new Monster(528, 525, 1, Area[0], currentMap, 10000, 5000, 0, 1000));
		}

		if (background->Width() < 1024)
		{
			MapX = (1024 - background->Width()) / 2;
		}
		else if (tmp > 0)
		{
			MapX = 0;
		}
		else
		{
			MapX = 1024 - background->Width();
		}

		if (background->Height() < 768)
		{
			MapY = (768 - background->Height()) / 2;
		}
		else
		{
			MapY = 768 - background->Height();
		}

		background->SetTopLeft(MapX, MapY);
	}

	int Map::getInitX()
	{
		return 350;
	}

	int Map::getInitY()
	{
		return Area[0][1];
	}

	int Map::getMapX()
	{
		return MapX;
	}

	int Map::getMapY()
	{
		return MapY;
	}

	int Map::getEdgex1()
	{
		return edgex1;
	}

	int Map::getEdgex2()
	{
		return edgex2;
	}

	int Map::scrollRight(int step)
	{
		if (background->Width() <= 1024) {
			return step;
		}
		else if (background->Width() + MapX - step >= 1024)
		{
			MapX -= step;
			background->SetTopLeft(MapX, MapY);
			background->ShowBitmap();
			step = 0;
		}
		else if (background->Width() + MapX > 1024)
		{
			step -= ((background->Width() + MapX) - 1024);
			MapX = 1024 - background->Width();
			background->SetTopLeft(MapX, MapY);
			background->ShowBitmap();
		}
		return step;
	}

	int Map::scrollLeft(int step)
	{
		if (background->Width() <= 1024) {
			return step;
		}
		else if (MapX + step <= 0)
		{
			MapX += step;
			background->SetTopLeft(MapX, MapY);
			background->ShowBitmap();
			step = 0;
		}
		else
		{
			step += MapX;
			MapX = 0;
			background->SetTopLeft(MapX, MapY);
			background->ShowBitmap();
		}
		return step;
	}

	void Map::onShow()
	{
		if (!music) {
			for (int i = 0; i < 18; i++) {
				CAudio::Instance()->Stop(i);
			}
			CAudio::Instance()->Play(currentMap + 1, true);
			music = true;
		}
		background->ShowBitmap();
	}

	void Map::itemShow()
	{
		int del = -1;

		if (clock() - item_floating >= 500)
		{
			floating = !floating;
			item_floating = clock();
		}

		for (int i = 0; i < (int)item.size(); i++)
		{
			if (clock() - item[i]->GetShowTime() >= 10000)
			{
				del = i;
			}
		}

		if (del != -1)
		{
			for (int i = 0; i < del; i++)
			{
				delete item[i];
			}

			item.erase(item.begin(), item.begin() + del);
		}

		for (int i = 0; i < (int)item.size(); i++)
		{
			item[i]->onShow(MapX, MapY, floating);
		}
	}

	void Map::monsterMove()
	{
		for (int i = 0; i < int(monster.size()); i++)
		{
			monster[i]->onMove();
		}
	}

	void Map::monsterShow(int px)
	{
		srand((unsigned)time(NULL));

		for (int i = 0; i < int(monster.size()); i++)
		{
			monster[i]->onShow(MapX, MapY, rand() % 5, px);
		}
	}

	int Map::hitMonster(int cx, int cy, int skillx1, int skilly1, int skillx2, int skilly2, int damage, bool finalbitmap, int* totaldamage)
	{
		int expr = 0;

		for (int i = 0; i < int(monster.size()); i++)
		{
			expr += monster[i]->getHit(cx, cy, skillx1, skilly1, skillx2, skilly2, damage, finalbitmap, totaldamage, &item);
		}

		return expr;
	}

	int Map::Monsterhit(int x1, int y1, int x2, int y2, int def)
	{
		int damage = 0;

		for (int i = 0; i < int(monster.size()); i++)
		{
			damage += monster[i]->Hit(x1, y1, x2, y2, def);
		}

		return damage;
	}

	int Map::getMonsterHP()
	{
		return monster[0]->gethp();
	}

	void Map::PickItem(int x, int y, int w, int h, vector<Item*>* backpack)
	{
		vector<int> del;

		for (int i = 0; i < (int)item.size(); i++)
		{
			if (item[i]->GetX() + item[i]->GetWidth() / 2 >= x && item[i]->GetX() + item[i]->GetWidth() / 2 <= x + w && item[i]->GetY() + item[i]->GetHeight() / 2 >= y && item[i]->GetY() + item[i]->GetHeight() / 2 <= y + h)
			{
				CAudio::Instance()->Play(13);
				backpack->push_back(item[i]);
				del.push_back(i);
			}
		}

		for (int i = (int)del.size() - 1; i >= 0; i--)
		{
			item.erase(item.begin() + del[i]);
		}
	}

	void Map::setArea(vector<int>* pos)
	{
		double y = 0;

		for (int i = 0; i < int(Area.size()); i++)
		{
			if ((*pos)[0] - MapX + 34 >= Area[i][0] && (*pos)[0] - MapX + 34 <= Area[i][2])
			{
				if (Area[i][1] != Area[i][3])
				{
					y = double((*pos)[0] - MapX + 34 - Area[i][0]) * double(Area[i][3] - Area[i][1]) / double(Area[i][2] - Area[i][0]);
					y = (int)y + Area[i][1];
				}
				else
				{
					y = Area[i][1];
				}

				if ((abs((*pos)[1] - MapY - (y - 70)) <= 15))
				{
					(*pos)[1] = (int)y + MapY - 70;
				}
			}
		}
	}

	void Map::setLadder(vector<int>* pos, string position)
	{
		if (position == "up")
		{
			for (int i = 0; i < int(Ladder.size()); i++)
			{
				if ((*pos)[0] - MapX + 34 >= Ladder[i][0] && (*pos)[0] - MapX + 34 <= Ladder[i][2] && (*pos)[1] - MapY >= Ladder[i][1] && (*pos)[1] - MapY <= Ladder[i][3])
				{
					(*pos)[0] = Ladder[i][0] + MapX - (62 - (Ladder[i][2] - Ladder[i][0])) / 2 - 7;
				}
			}
		}
		else
		{
			for (int i = 0; i < int(Ladder.size()); i++)
			{
				if ((*pos)[0] - MapX + 34 >= Ladder[i][0] && (*pos)[0] - MapX + 34 <= Ladder[i][2] && (*pos)[1] - MapY + 70 >= Ladder[i][1] && (*pos)[1] - MapY + 70 <= Ladder[i][3])
				{
					(*pos)[0] = Ladder[i][0] + MapX - (62 - (Ladder[i][2] - Ladder[i][0])) / 2 - 7;
					(*pos)[1] += 15;
				}
			}
		}
	}

	int Map::setTeleport(vector<int>* pos)
	{
		int tmp;
		if (currentMap == 3 || currentMap == 6) {
			if (monster[0]->gethp() > 0) {
				return currentMap;
			}
		}
		for (int i = 0; i < int(Teleport.size()); i++)
		{
			if ((*pos)[0] - MapX + 34 >= Teleport[i][0] && (*pos)[0] - MapX + 34 <= Teleport[i][2] && (abs((*pos)[1] - MapY - (Teleport[i][1] - 70)) <= 10))
			{

				tmp = Teleport[i][4];
				CAudio::Instance()->Stop(currentMap);
				currentMap += tmp;
				Initialize(currentMap, tmp);

				if (tmp > 0 || currentMap == 0)
				{
					(*pos)[0] = Teleport[0][0] + MapX;
					(*pos)[1] = Teleport[0][1] + MapY - 70;
				}
				else
				{
					(*pos)[0] = Teleport[(int)Teleport.size() - 1][0] + MapX;
					(*pos)[1] = Teleport[(int)Teleport.size() - 1][1] + MapY - 70;
				}

				break;
			}
		}

		return currentMap;
	}

	bool Map::isEdge(vector<int>* pos, string direction)
	{
		if ((*pos)[0] - MapX + 34 <= edgex1 && direction == "left")
		{
			(*pos)[0] = edgex1 + MapX - 34;
			return true;
		}
		else if ((*pos)[0] - MapX + 34 >= edgex2 && direction == "right")
		{
			(*pos)[0] = edgex2 + MapX - 34;
			return true;
		}

		return false;
	}

	bool Map::isArea(vector<int>* pos)
	{
		double y = 0;

		for (int i = 0; i < int(Area.size()); i++)
		{
			if ((*pos)[0] - MapX + 34 >= Area[i][0] && (*pos)[0] - MapX + 34 <= Area[i][2])
			{
				if (Area[i][1] != Area[i][3])
				{
					y = double((*pos)[0] - MapX + 34 - Area[i][0]) * double(Area[i][3] - Area[i][1]) / double(Area[i][2] - Area[i][0]);
					y = (int)y + Area[i][1];
				}
				else
				{
					y = Area[i][1];
				}

				if ((abs((*pos)[1] - MapY - (y - 70)) <= 15))
				{
					setArea(pos);
					return true;
				}
			}
		}

		return false;
	}

	bool Map::isLadder(vector<int>* pos, string position)
	{
		if (position == "up")
		{
			for (int i = 0; i < int(Ladder.size()); i++)
			{
				if ((*pos)[0] - MapX + 34 >= Ladder[i][0] && (*pos)[0] - MapX + 34 <= Ladder[i][2] && (*pos)[1] - MapY >= Ladder[i][1] && (*pos)[1] - MapY <= Ladder[i][3])
				{
					return true;
				}
			}
		}
		else
		{
			for (int i = 0; i < int(Ladder.size()); i++)
			{
				if ((*pos)[0] - MapX + 34 >= Ladder[i][0] && (*pos)[0] - MapX + 34 <= Ladder[i][2] && (*pos)[1] - MapY + 70 >= Ladder[i][1] && (*pos)[1] - MapY + 70 <= Ladder[i][3])
				{
					return true;
				}
			}
		}

		return false;
	}

	bool Map::isTeleport(vector<int>* pos)
	{
		for (int i = 0; i < int(Teleport.size()); i++)
		{
			if ((*pos)[0] - MapX + 34 >= Teleport[i][0] && (*pos)[0] - MapX + 34 <= Teleport[i][2] && (abs((*pos)[1] - MapY - (Teleport[i][1] - 70)) <= 10))
			{
				return true;
			}
		}

		return false;
	}

}