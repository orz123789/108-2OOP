#include "stdafx.h"
#include "Resource.h"
#include <mmsystem.h>
#include <ddraw.h>
#include "audio.h"
#include "gamelib.h"
#include "Effect.h"
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>

namespace game_framework
{
	Effect::Effect(string name, int time, int num)
	{
		effectname = name;
		effecttime = time;
		effectnum = num;
	}
	string Effect::getName()
	{
		return effectname;
	}
	int Effect::getNum()
	{
		return effectnum;
	}
	int Effect::getTime()
	{
		return effecttime;
	}
	void Effect::setTime(int time)
	{
		effecttime += time;
	}
}
