#include "stdafx.h"
#include "Resource.h"
#include <mmsystem.h>
#include <ddraw.h>
#include "audio.h"
#include "gamelib.h"
#include "Monster.h"
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>

namespace game_framework
{
	Monster::Monster(int MapX, int MapY, int dir, vector<int> area, int map, int mexp, int hpnum, int dmgnum, int defnum)
	{
		expr = mexp;
		dmg = dmgnum;
		def = defnum;
		hp = hpnum;
		timer_death = timer_gethit = timer_hit = timer_skill = -1;
		currentMap = map;
		Area = area;
		LoadBitmap();
		x = MapX;
		y = MapY - animationStandR.Height();
		direction = dir;
		stone.clear();
		soundeffect = false;
		mh = animationStandR.Height() / 2;
		mw = animationStandR.Width() / 2;

		if (currentMap == 6)
		{
			timer_skill = clock();
			rnd = (rand() % 4 + 1) * 1000;
		}
		else if (currentMap == 7)
		{
			timer_skill = clock();
			rnd = 3000;
		}
	}

	Monster::~Monster()
	{
		for (int i = 0; i < (int)stone.size(); i++) {
			delete stone[i];
		}
	}

	void Monster::LoadBitmap()
	{
		if (currentMap == 1)
		{
			animationStandR.AddBitmap(IDB_11STANDRIGHT_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_11STANDLEFT_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_11MOVERIGHT_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_11MOVERIGHT_1, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_11MOVERIGHT_2, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_11MOVERIGHT_3, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_11MOVERIGHT_4, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_11MOVELEFT_0, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_11MOVELEFT_1, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_11MOVELEFT_2, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_11MOVELEFT_3, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_11MOVELEFT_4, RGB(0, 255, 0));
			animationHitL.AddBitmap(IDB_11HITLEFT_0, RGB(0, 255, 0));
			animationHitR.AddBitmap(IDB_11HITRIGHT_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_1, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_2, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_3, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_4, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_5, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_6, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_7, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_11DIELEFT_8, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_0, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_1, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_2, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_3, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_4, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_5, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_6, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_7, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_11DIERIGHT_8, RGB(0, 255, 0));
		}
		else if (currentMap == 2)
		{
			animationStandR.AddBitmap(IDB_12STANDRIGHT_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_12STANDLEFT_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_12MOVERIGHT_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_12MOVERIGHT_1, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_12MOVERIGHT_2, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_12MOVELEFT_0, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_12MOVELEFT_1, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_12MOVELEFT_2, RGB(0, 255, 0));
			animationHitL.AddBitmap(IDB_12HITLEFT_0, RGB(0, 255, 0));
			animationHitR.AddBitmap(IDB_12HITRIGHT_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_12DIELEFT_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_12DIELEFT_1, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_12DIELEFT_2, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_12DIERIGHT_0, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_12DIERIGHT_1, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_12DIERIGHT_2, RGB(0, 255, 0));
		}
		else if (currentMap == 3)
		{
			animationStandR.AddBitmap(IDB_14standright_0, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_1, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_2, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_3, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_4, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_5, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_6, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_7, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_14standright_8, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_1, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_2, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_3, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_4, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_5, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_6, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_7, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_14standleft_8, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_14moveright_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_14moveright_1, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_14moveright_2, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_14moveright_3, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_14moveright_4, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_14moveright_5, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_14moveleft_0, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_14moveleft_1, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_14moveleft_2, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_14moveleft_3, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_14moveleft_4, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_14moveleft_5, RGB(0, 255, 0));
			animationHitL.AddBitmap(IDB_14hitleft_0, RGB(0, 255, 0));
			animationHitR.AddBitmap(IDB_14hitright_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_1, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_2, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_3, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_4, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_5, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_6, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_7, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_14dieleft_8, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_0, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_1, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_2, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_3, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_4, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_5, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_6, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_7, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_14dieright_8, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_0, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_1, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_2, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_3, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_4, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_5, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_6, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_7, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_8, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_14skillleft_9, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_0, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_1, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_2, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_3, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_4, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_5, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_6, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_7, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_8, RGB(0, 255, 0));
			animationSkillR.AddBitmap(IDB_14skillright_9, RGB(0, 255, 0));
		}
		else if (currentMap == 4)
		{
			animationStandR.AddBitmap(IDB_23standright_0, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_23standright_1, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_23standright_2, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_23standleft_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_23standleft_1, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_23standleft_2, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_23moveright_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_23moveright_1, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_23moveright_2, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_23moveleft_0, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_23moveleft_1, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_23moveleft_2, RGB(0, 255, 0));
			animationHitL.AddBitmap(IDB_23hitleft_0, RGB(0, 255, 0));
			animationHitR.AddBitmap(IDB_23hitright_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_23dieleft_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_23dieleft_1, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_23dieleft_2, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_23dieright_0, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_23dieright_1, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_23dieright_2, RGB(0, 255, 0));
		}
		else if (currentMap == 5)
		{
			animationStandR.AddBitmap(IDB_21standright_0, RGB(255, 0, 0));
			animationStandR.AddBitmap(IDB_21standright_1, RGB(255, 0, 0));
			animationStandR.AddBitmap(IDB_21standright_2, RGB(255, 0, 0));
			animationStandL.AddBitmap(IDB_21standleft_0, RGB(255, 0, 0));
			animationStandL.AddBitmap(IDB_21standleft_1, RGB(255, 0, 0));
			animationStandL.AddBitmap(IDB_21standleft_2, RGB(255, 0, 0));
			animationWalkR.AddBitmap(IDB_21moveright_0, RGB(255, 0, 0));
			animationWalkR.AddBitmap(IDB_21moveright_1, RGB(255, 0, 0));
			animationWalkR.AddBitmap(IDB_21moveright_2, RGB(255, 0, 0));
			animationWalkR.AddBitmap(IDB_21moveright_3, RGB(255, 0, 0));
			animationWalkR.AddBitmap(IDB_21moveright_4, RGB(255, 0, 0));
			animationWalkR.AddBitmap(IDB_21moveright_5, RGB(255, 0, 0));
			animationWalkL.AddBitmap(IDB_21moveleft_0, RGB(255, 0, 0));
			animationWalkL.AddBitmap(IDB_21moveleft_1, RGB(255, 0, 0));
			animationWalkL.AddBitmap(IDB_21moveleft_2, RGB(255, 0, 0));
			animationWalkL.AddBitmap(IDB_21moveleft_3, RGB(255, 0, 0));
			animationWalkL.AddBitmap(IDB_21moveleft_4, RGB(255, 0, 0));
			animationWalkL.AddBitmap(IDB_21moveleft_5, RGB(255, 0, 0));
			animationHitL.AddBitmap(IDB_21hitleft_0, RGB(255, 0, 0));
			animationHitR.AddBitmap(IDB_21hitright_0, RGB(255, 0, 0));
			animationDieL.AddBitmap(IDB_21dieleft_0, RGB(255, 0, 0));
			animationDieL.AddBitmap(IDB_21dieleft_1, RGB(255, 0, 0));
			animationDieL.AddBitmap(IDB_21dieleft_2, RGB(255, 0, 0));
			animationDieL.AddBitmap(IDB_21dieleft_3, RGB(255, 0, 0));
			animationDieR.AddBitmap(IDB_21dieright_0, RGB(255, 0, 0));
			animationDieR.AddBitmap(IDB_21dieright_1, RGB(255, 0, 0));
			animationDieR.AddBitmap(IDB_21dieright_2, RGB(255, 0, 0));
			animationDieR.AddBitmap(IDB_21dieright_3, RGB(255, 0, 0));
		}
		else if (currentMap == 6)
		{
			animationStandR.AddBitmap(IDB_24standright_0, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_24standright_1, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_24standright_2, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_24standright_3, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_24standright_4, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_24standright_5, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_24standleft_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_24standleft_1, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_24standleft_2, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_24standleft_3, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_24standleft_4, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_24standleft_5, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_24moveright_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_24moveright_1, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_24moveright_2, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_24moveright_3, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_24moveright_4, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_24moveright_5, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_24moveleft_0, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_24moveleft_1, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_24moveleft_2, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_24moveleft_3, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_24moveleft_4, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_24moveleft_5, RGB(0, 255, 0));
			animationHitL.AddBitmap(IDB_24hitleft_0, RGB(0, 255, 0));
			animationHitR.AddBitmap(IDB_24hitright_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_1, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_2, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_3, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_4, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_5, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_6, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_7, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_8, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_9, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_24dieleft_10, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_0, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_1, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_2, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_3, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_4, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_5, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_6, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_7, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_8, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_9, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_24dieright_10, RGB(0, 255, 0));
			animationDieL.SetDelayCount(5);
			animationDieR.SetDelayCount(5);
			animationDieL.Reset();
			animationDieR.Reset();
		}
		else if (currentMap == 7)
		{
			animationStandR.AddBitmap(IDB_31standleft_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_1, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_2, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_3, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_4, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_5, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_31standleft_6, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_0, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_1, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_2, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_3, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_4, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_5, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_6, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_7, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_8, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_9, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_10, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_11, RGB(0, 255, 0));
			animationSkillL.AddBitmap(IDB_31skillleft_12, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_31dieleft_0, RGB(0, 255, 0));
			animationHitL.AddBitmap(IDB_31dieleft_0, RGB(0, 255, 0));
			animationStandL.SetDelayCount(5);
			animationSkillL.SetDelayCount(5);
			animationStandL.Reset();
			animationSkillL.Reset();
		}
	}

	void Monster::onShow(int Map_X, int Map_Y, int random, int px)
	{
		MapX = Map_X;
		MapY = Map_Y;

		if (clock() - timer_skill == rnd && currentMap == 6)
		{
			skillhit = false;
		}

		if (currentMap == 6 && ((direction == 0 && x + MapX > px) || (direction == 1 && x + MapX < px)))
		{
			soundeffect = false;
			timer_skill = clock();
			rnd = (rand() % 4 + 1) * 1000;
		}

		if ((px < x + MapX && currentMap == 6 && hp > 0) || currentMap == 7)
		{
			direction = 1;
		}
		else if (px > x + MapX && currentMap == 6 && hp > 0)
		{
			direction = 0;
		}

		if (clock() - timer_skill >= rnd && currentMap == 6)
		{
			state = 1;
		}
		else if ((clock() - timer_skill < rnd && currentMap == 6) || currentMap == 7)
		{
			state = 0;
		}
		else
		{
			state = random;
		}

		if ((clock() - timer_skill) / CLOCKS_PER_SEC > 15 && timer_skill != -1 && currentMap == 3)
		{
			timer_skill = -1;
			def /= 2;
		}

		if (hp <= 0)
		{
			if (direction == 0)
			{
				if (!animationDieR.IsFinalBitmap())
				{
					animationDieR.SetTopLeft(x + MapX + mw, y + MapY + mh);
					animationDieR.OnShow();
				}
				else if (int(timer_death) == -1)
				{
					timer_death = clock();
				}
				else if ((clock() - timer_death) / CLOCKS_PER_SEC >= 3 && (currentMap == 1 || currentMap == 2 || currentMap == 4 || currentMap == 5))
				{
					srand(x);
					direction = rand() % 2;
					state = rand() % 2;
					x = rand() % (Area[2] - Area[0] - (animationStandR.Width() / 2)) + Area[0];
					timer_death = -1;
					hp = 500;
					animationDieR.Reset();
				}
			}
			else
			{
				if (!animationDieL.IsFinalBitmap())
				{
					animationDieL.SetTopLeft(x + MapX + mw, y + MapY + mh);
					animationDieL.OnShow();
				}
				else if (int(timer_death) == -1)
				{
					timer_death = clock();
				}
				else if ((clock() - timer_death) / CLOCKS_PER_SEC >= 3 && (currentMap == 1 || currentMap == 2 || currentMap == 4 || currentMap == 5))
				{
					srand(x);
					direction = rand() % 2;
					state = rand() % 2;
					x = rand() % (Area[2] - Area[0] - (animationStandR.Width() / 2)) + Area[0];
					timer_death = -1;
					hp = 500;
					animationDieL.Reset();
				}
			}
		}
		else
		{
			if (direction == 0)
			{
				if (timer_gethit != -1 && clock() - timer_gethit <= 350)
				{
					animationHitR.SetTopLeft(x + MapX + mw, y + MapY + mh);
					animationHitR.OnShow();
				}
				else
				{
					timer_gethit = -1;

					if (state == 0)
					{
						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillR.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationSkillR.OnShow();
						}
						else
						{
							animationStandR.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationStandR.OnShow();
						}
					}
					else if (currentMap != 7)
					{
						if (!soundeffect&&clock() - timer_skill >= double(rnd - 4) && currentMap == 6) {
							CAudio::Instance()->Play(15);
							soundeffect = true;
						}
						if (clock() - timer_skill >= rnd && currentMap == 6)
						{
							if (x + (animationStandR.Width() / 2) + 10 < Area[2])
							{
								x += 10;
							}
							else
							{
								direction = 1;
								x -= 10;
							}
						}
						else if (x + (animationStandR.Width() / 2) + 1 < Area[2])
						{
							x += 1;
						}
						else
						{
							direction = 1;
							x -= 1;
						}

						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillR.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationSkillR.OnShow();
						}
						else
						{
							animationWalkR.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationWalkR.OnShow();
						}
					}
				}
			}
			else
			{
				if (timer_gethit != -1 && clock() - timer_gethit <= 350)
				{
					animationHitL.SetTopLeft(x + MapX + mw, y + MapY + mh);
					animationHitL.OnShow();
				}
				else
				{
					timer_gethit = -1;

					if (state == 0)
					{
						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillL.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationSkillL.OnShow();
						}
						else if (!soundeffect&&clock() - timer_skill >= double(rnd - 3) && currentMap == 7) {
							CAudio::Instance()->Play(16);
							soundeffect = true;
						}
						else if (clock() - timer_skill >= rnd && currentMap == 7)
						{

							if (stone.empty())
							{
								animationSkillL.SetTopLeft(x + MapX + mw, y + MapY + mh);
								animationSkillL.OnShow();
							}
							else
							{
								animationStandL.SetTopLeft(x + MapX + mw, y + MapY + mh);
								animationStandL.OnShow();

								if (stone[0]->Top() + stone[0]->Height() >= Area[1])
								{
									for (int i = 0; i < (int)stone.size(); i++)
									{
										delete stone[i];
									}

									stone.clear();
									stonex.clear();
									stoney.clear();
									timer_skill = clock();
									soundeffect = false;
								}
								else
								{
									for (int i = 0; i < (int)stone.size(); i++)
									{
										stoney[i] += 20;
										stone[i]->SetTopLeft(stonex[i] + MapX, stoney[i] + MapY);
										stone[i]->ShowBitmap();
									}
								}
							}
						}
						else
						{
							animationStandL.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationStandL.OnShow();
						}
					}
					else if (currentMap != 7)
					{
						if (!soundeffect&&clock() - timer_skill >= double(rnd - 4) && currentMap == 6) {
							CAudio::Instance()->Play(15);
							soundeffect = true;
						}
						if (clock() - timer_skill >= rnd && currentMap == 6)
						{
							if (x + (animationStandR.Width() / 2) - 10 > Area[0])
							{
								x -= 10;
							}
							else
							{
								direction = 0;
								x += 10;
							}
						}
						else if (x + (animationStandR.Width() / 2) - 1 > Area[0])
						{
							x -= 1;
						}
						else
						{
							direction = 0;
							x += 1;
						}

						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillL.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationSkillL.OnShow();
						}
						else
						{
							animationWalkL.SetTopLeft(x + MapX + mw, y + MapY + mh);
							animationWalkL.OnShow();
						}
					}
				}
			}
		}
	}

	void Monster::onMove()
	{
		if (hp <= 0)
		{
			if (direction == 0)
			{
				if (!animationDieR.IsFinalBitmap())
				{
					animationDieR.OnMove();
				}
			}
			else
			{
				if (!animationDieL.IsFinalBitmap())
				{
					animationDieL.OnMove();
				}
			}
		}
		else
		{
			if (direction == 0)
			{
				if (timer_gethit != -1 && clock() - timer_gethit <= 350)
				{
					animationHitR.OnMove();
				}
				else
				{
					timer_gethit = -1;

					if (state == 0)
					{
						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillR.OnMove();
						}
						else
						{
							animationStandR.OnMove();
						}
					}
					else
					{
						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillR.OnMove();
						}
						else
						{
							animationWalkR.OnMove();
						}
					}
				}
			}
			else
			{
				if (timer_gethit != -1 && clock() - timer_gethit <= 350)
				{
					animationHitL.OnMove();
				}
				else
				{
					timer_gethit = -1;

					if (state == 0)
					{
						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillL.OnMove();
						}
						else if (clock() - timer_skill >= rnd && currentMap == 7)
						{
							if (stone.empty())
							{
								animationSkillL.OnMove();

								if (animationSkillL.IsFinalBitmap())
								{
									srand((unsigned)time(NULL));

									for (int i = rand() % 89; i <= Area[2]; i += 85)
									{
										stone.push_back(new CMovingBitmap);
										stonex.push_back(i);
										stoney.push_back(0);
										stone[(int)stone.size() - 1]->LoadBitmap(IDB_stone, RGB(0, 255, 0));
										stone[(int)stone.size() - 1]->SetTopLeft(stonex[(int)stonex.size() - 1] + MapX, stoney[(int)stoney.size() - 1] + MapY);
										stone[(int)stone.size() - 1]->ShowBitmap();
									}

									skillhit = false;
									animationSkillL.Reset();
								}
							}
							else
							{
								animationStandL.OnMove();
							}
						}
						else
						{
							animationStandL.OnMove();
						}
					}
					else
					{
						if (timer_skill != -1 && (clock() - timer_skill) / CLOCKS_PER_SEC <= 15 && currentMap == 3)
						{
							animationSkillL.OnMove();
						}
						else
						{
							animationWalkL.OnMove();
						}
					}
				}
			}
		}
	}

	int Monster::gethp()
	{
		return hp;
	}

	int Monster::getHit(int cx, int cy, int skillx1, int skilly1, int skillx2, int skilly2, int damage, bool finalbitmap, int* totaldamage, vector<Item*>* item)
	{
		bool flag = false;
		int srcx = x + MapX + (animationStandR.Width() / 2);

		for (int k = y + MapY; k <= y + MapY + animationStandR.Height(); k++)
		{
			if (srcx >= skillx1 && srcx <= skillx2 && k >= skilly1 && k <= skilly2)
			{
				flag = true;
				break;
			}
		}

		if (flag)
		{
			if (timer_gethit == -1)
			{
				timer_gethit = clock();
				if (currentMap != 3 && currentMap != 6 && currentMap != 7) {
					if (srcx > cx)
					{
						x += 25;

						if (x > Area[2])
						{
							x = Area[2];
						}
					}
					else
					{
						x -= 25;

						if (x < Area[0])
						{
							x = Area[0];
						}
					}
				}
			}

			if (finalbitmap)
			{
				if (hp > 0 && damage > def)
				{
					(*totaldamage) = (*totaldamage) + (damage - def);
					hp = hp - (damage - def);

					if (damage - def > 0 && timer_skill == -1 && currentMap == 3)
					{
						timer_skill = clock();
						def *= 2;
					}

					if (hp <= 0)
					{
						int itemnum, itemtype, potiontype;
						srand(x);

						if (currentMap == 1 || currentMap == 2)
						{
							itemnum = rand() % 2 + 1;

							for (int i = 0; i < itemnum; i++)
							{
								itemtype = rand() % 100;

								if (itemtype >= 0 && itemtype < 70)
								{
									potiontype = rand() % 2;

									if (potiontype == 0)
									{
										item->push_back(new Item(x + 35 * i, Area[1] - 30, "�����Ĥ�"));
									}
									else
									{
										item->push_back(new Item(x + 35 * i, Area[1] - 30, "�Ŧ��Ĥ�"));
									}
								}
								else if (itemtype >= 70 && itemtype < 80)
								{
									item->push_back(new Item(x + 35 * i, Area[1] - 30, "���C0"));
								}
								else if (itemtype >= 80 && itemtype < 90)
								{
									item->push_back(new Item(x + 35 * i, Area[1] - 30, "�޵P0"));
								}
								else if (itemtype >= 90 && itemtype < 100)
								{
									item->push_back(new Item(x + 35 * i, Area[1] - 30, "�W��0"));
								}
							}
						}
						else if (currentMap == 3) {
							item->push_back(new Item(x + 35, Area[1] - 30, "�W�Ŭ����Ĥ�"));
							item->push_back(new Item(x + 70, Area[1] - 30, "�W���Ŧ��Ĥ�"));
							item->push_back(new Item(x + 105, Area[1] - 30, "�޵P1"));
							item->push_back(new Item(x + 140, Area[1] - 30, "���C1"));
							item->push_back(new Item(x + 175, Area[1] - 30, "�W��1"));
						}
						else if (currentMap == 4 || currentMap == 5)
						{
							itemnum = rand() % 2 + 1;

							for (int i = 0; i < itemnum; i++)
							{
								itemtype = rand() % 100;

								if (itemtype >= 0 && itemtype < 70)
								{
									potiontype = rand() % 4;

									if (potiontype == 0)
									{
										item->push_back(new Item(x + 35 * i, Area[1] - 30, "�����Ĥ�"));
									}
									else if (potiontype == 1)
									{
										item->push_back(new Item(x + 35 * i, Area[1] - 30, "�Ŧ��Ĥ�"));
									}
									else if (potiontype == 2)
									{
										item->push_back(new Item(x + 35 * i, Area[1] - 30, "�W�Ŭ����Ĥ�"));
									}
									else if (potiontype == 3)
									{
										item->push_back(new Item(x + 35 * i, Area[1] - 30, "�W���Ŧ��Ĥ�"));
									}
								}
								else if (itemtype == 70)
								{
									item->push_back(new Item(x + 35 * i, Area[1] - 30, "���C2"));
								}
								else if (itemtype > 70 && itemtype < 80)
								{
									item->push_back(new Item(x + 35 * i, Area[1] - 30, "���C1"));
								}
								else if (itemtype >= 80 && itemtype < 90)
								{
									item->push_back(new Item(x + 35 * i, Area[1] - 30, "�޵P1"));
								}
								else if (itemtype >= 90 && itemtype < 100)
								{
									item->push_back(new Item(x + 35 * i, Area[1] - 30, "�W��1"));
								}
							}
						}
						else if (currentMap == 6) {
							item->push_back(new Item(x + 35, Area[1] - 30, "�W�Ŭ����Ĥ�"));
							item->push_back(new Item(x + 70, Area[1] - 30, "�W���Ŧ��Ĥ�"));
							item->push_back(new Item(x + 105, Area[1] - 30, "�޵P1"));
							item->push_back(new Item(x + 140, Area[1] - 30, "���C3"));
							item->push_back(new Item(x + 175, Area[1] - 30, "�W��2"));
						}
						else if (currentMap == 7) {
							for (int i = 0; i < 17; i++) {
								CAudio::Instance()->Stop(i);
							}
							CAudio::Instance()->Play(17);
						}
						return expr;
					}
				}
			}
		}

		return 0;
	}

	int Monster::Hit(int x1, int y1, int x2, int y2, int def)
	{
		bool flag = false;
		int srcx;

		if (direction == 0)
		{
			srcx = x + animationStandR.Width() + MapX;
		}
		else
		{
			srcx = x + MapX;
		}

		for (int i = y + MapY; i <= y + MapY + animationStandR.Height(); i++)
		{
			if (srcx >= x1 && srcx <= x2 && i >= y1 && i <= y2)
			{
				flag = true;
				break;
			}
		}

		if (currentMap == 6 && hp > 0 && flag && !skillhit)
		{
			skillhit = true;
			return dmg - def;
		}
		else if (currentMap == 7)
		{
			for (int i = 0; i < (int)stone.size(); i++)
			{
				flag = false;
				srcx = stone[i]->Left() + stone[i]->Width() / 2 + MapX;

				for (int j = stone[i]->Top() + MapY; j <= stone[i]->Top() + stone[i]->Height() + MapY; j++)
				{
					if (srcx >= x1 && srcx <= x2 && j >= y1 && j <= y2)
					{
						flag = true;
						break;
					}
				}

				if (hp > 0 && flag && !skillhit)
				{
					skillhit = true;
					return 900 - def;
				}
			}
		}
		else if (hp > 0 && clock() - timer_hit >= 3000 && flag)
		{
			timer_hit = clock();
			return dmg - def;
		}

		return 0;
	}
}