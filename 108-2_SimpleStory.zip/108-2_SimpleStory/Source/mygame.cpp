#include "stdafx.h"
#include "Resource.h"
#include <mmsystem.h>
#include <ddraw.h>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include "audio.h"
#include "gamelib.h"
#include "mygame.h"

namespace game_framework
{
	CGameStateInit::CGameStateInit(CGame* g)
		: CGameState(g)
	{
	}

	void CGameStateInit::OnInit()
	{
		ShowInitProgress(0);
		CAudio::Instance()->Load(bgmtitle, "sounds\\bgmtitle.mp3");
		CAudio::Instance()->Load(bgm01, "sounds\\bgm0_1.mp3");
		CAudio::Instance()->Load(bgm11, "sounds\\bgm1_1.mp3");
		CAudio::Instance()->Load(bgm12, "sounds\\bgm1_2.mp3");
		CAudio::Instance()->Load(bgm13, "sounds\\bgm1_3.mp3");
		CAudio::Instance()->Load(bgm21, "sounds\\bgm2_1.mp3");
		CAudio::Instance()->Load(bgm22, "sounds\\bgm2_2.mp3");
		CAudio::Instance()->Load(bgm23, "sounds\\bgm2_3.mp3");
		CAudio::Instance()->Load(bgm31, "sounds\\bgm3_1.mp3");
		CAudio::Instance()->Load(skillq, "sounds\\SkillQ.wav");
		CAudio::Instance()->Load(skillw, "sounds\\SkillW.wav");
		CAudio::Instance()->Load(skille, "sounds\\SkillE.mp3");
		CAudio::Instance()->Load(skillr, "sounds\\SkillR.wav");
		CAudio::Instance()->Load(pickitem, "sounds\\pickitem.wav");
		CAudio::Instance()->Load(levelup, "sounds\\lvlup.wav");
		CAudio::Instance()->Load(attack23, "sounds\\23attack.wav");
		CAudio::Instance()->Load(attack31, "sounds\\31attack.wav");
		CAudio::Instance()->Load(success, "sounds\\success.wav");
		CAudio::Instance()->Play(bgmtitle, true);
		title.AddBitmap(IDB_title_0);
		title.AddBitmap(IDB_title_1);
		title.SetTopLeft(0 + title.Width() / 2, 0 + title.Height() / 2);
		title.SetDelayCount(10);
		title.Reset();
	}

	void CGameStateInit::OnBeginState()
	{
	}

	void CGameStateInit::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
	{
		const char KEY_SPACE = ' ';

		if (nChar == KEY_SPACE)
			GotoGameState(GAME_STATE_RUN);
	}

	void CGameStateInit::OnShow()
	{
		title.OnShow();
		title.OnMove();
	}

	CGameStateOver::CGameStateOver(CGame* g)
		: CGameState(g)
	{
	}

	void CGameStateOver::OnInit()
	{
		ShowInitProgress(66);
		ShowInitProgress(100);
	}

	void CGameStateOver::OnShow()
	{
		CDC* pDC = CDDraw::GetBackCDC();
		CFont f, *fp;
		f.CreatePointFont(160, "Times New Roman");
		fp = pDC->SelectObject(&f);
		pDC->SetBkColor(RGB(0, 0, 0));
		pDC->SetTextColor(RGB(255, 255, 0));
		char str[80];
		pDC->TextOut(240, 210, str);
		pDC->SelectObject(fp);
		CDDraw::ReleaseBackCDC();
	}
	CGameStateRun::CGameStateRun(CGame* g)
		: CGameState(g) {}

	void CGameStateRun::OnBeginState()
	{
	}

	void CGameStateRun::OnMove()
	{
		map.monsterMove();
		character.OnMove();
	}

	void CGameStateRun::OnInit()
	{
		ShowInitProgress(33);
		character.LoadBitmap();
		character.Initialize(&map);
		ShowInitProgress(50);
	}

	void CGameStateRun::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
	{
		const char KEY_ENTER = 0x0D;
		const char KEY_BACKPACK = 0x49;
		const char KEY_PICK = 0x58;
		const char KEY_LEFT = 0x25;
		const char KEY_UP = 0x26;
		const char KEY_RIGHT = 0x27;
		const char KEY_DOWN = 0x28;
		const char KEY_JUMP = 0x5A;
		const char KEY_SKILLQ = 0x51;
		const char KEY_SKILLW = 0x57;
		const char KEY_SKILLE = 0x45;
		const char KEY_SKILLR = 0x52;
		const char KEY_F1 = 0x70;
		const char KEY_F2 = 0x71;
		const char KEY_F3 = 0x72;
		const char KEY_F4 = 0x73;
		if(nChar==KEY_F1){
			character.ShowAuthor();
		}
		if (nChar == KEY_F2) {
			character.ShowHelp();
		}
		if (nChar == KEY_F3) {
			character.ShowMission();
		}
		if (nChar == KEY_F4) {
			character.SetCheat();
		}
		if (nChar == KEY_ENTER)
		{
			character.SetUse(true);
		}

		if (character.GetHP() <= 0) {
			return;
		}

		if (nChar == KEY_BACKPACK)
		{
			character.SetBackpack();
		}

		if (nChar == KEY_PICK)
		{
			character.SetPick(true);
		}

		if (nChar == KEY_SKILLQ)
		{
			character.SetAttack(true, "Q");
		}

		if (nChar == KEY_SKILLW)
		{
			character.SetAttack(true, "W");
		}

		if (nChar == KEY_SKILLE)
		{
			character.SetAttack(true, "E");
		}

		if (nChar == KEY_SKILLR) {
			character.SetAttack(true, "R");
		}

		if (nChar == KEY_LEFT)
		{
			if (character.GetBackpack())
			{
				if (character.GetItemSelectIndex() > 0)
				{
					character.SetItemSelectIndex(character.GetItemSelectIndex() - 1);
				}
			}
			else
			{
				character.SetMovingLeft(true);
				character.SetMovingRight(false);
			}
		}

		if (nChar == KEY_RIGHT)
		{
			if (character.GetBackpack())
			{
				if (character.GetItemSelectIndex() < 23)
				{
					character.SetItemSelectIndex(character.GetItemSelectIndex() + 1);
				}
			}
			else
			{
				character.SetMovingRight(true);
				character.SetMovingLeft(false);
			}
		}

		if (nChar == KEY_UP)
		{
			if (character.GetBackpack())
			{
				if (character.GetItemSelectIndex() >= 4)
				{
					character.SetItemSelectIndex(character.GetItemSelectIndex() - 4);
				}
			}
			else
			{
				character.SetMovingUp(true);
				character.SetMovingDown(false);
			}
		}

		if (nChar == KEY_DOWN)
		{
			if (character.GetBackpack())
			{
				if (character.GetItemSelectIndex() <= 19)
				{
					character.SetItemSelectIndex(character.GetItemSelectIndex() + 4);
				}
			}
			else
			{
				character.SetMovingDown(true);
				character.SetMovingUp(false);
			}
		}

		if (nChar == KEY_JUMP)
		{
			character.SetJump(true);
		}
	}

	void CGameStateRun::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
	{
		const char KEY_ENTER = 0x0D;
		const char KEY_PICK = 0x58;
		const char KEY_LEFT = 0x25;
		const char KEY_UP = 0x26;
		const char KEY_RIGHT = 0x27;
		const char KEY_DOWN = 0x28;

		if (nChar == KEY_ENTER)
		{
			character.SetUse(false);
		}

		if (nChar == KEY_PICK)
		{
			character.SetPick(false);
		}

		if (nChar == KEY_LEFT)
		{
			character.SetMovingLeft(false);
		}

		if (nChar == KEY_RIGHT)
		{
			character.SetMovingRight(false);
		}

		if (nChar == KEY_UP)
		{
			character.SetMovingUp(false);
		}

		if (nChar == KEY_DOWN)
		{
			character.SetMovingDown(false);
		}
	}

	void CGameStateRun::OnShow()
	{
		map.onShow();
		map.itemShow();
		map.monsterShow(character.GetX1());
		character.OnShow();
	}
}