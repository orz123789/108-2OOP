/*
 * mygame.cpp: ���ɮ��x�C��������class��implementation
 * Copyright (C) 2002-2008 Woei-Kae Chen <wkc@csie.ntut.edu.tw>
 *
 * This file is part of game, a free game development framework for windows.
 *
 * game is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * game is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * History:
 *   2002-03-04 V3.1
 *          Add codes to demostrate the use of CMovingBitmap::ShowBitmap(CMovingBitmap &).
 *	 2004-03-02 V4.0
 *      1. Add CGameStateInit, CGameStateRun, and CGameStateOver to
 *         demonstrate the use of states.
 *      2. Demo the use of CInteger in CGameStateRun.
 *   2005-09-13
 *      Rewrite the codes for CBall and CEraser.
 *   2005-09-20 V4.2Beta1.
 *   2005-09-29 V4.2Beta2.
 *      1. Add codes to display IDC_GAMECURSOR in GameStateRun.
 *   2006-02-08 V4.2
 *      1. Revise sample screens to display in English only.
 *      2. Add code in CGameStateInit to demo the use of PostQuitMessage().
 *      3. Rename OnInitialUpdate() -> OnInit().
 *      4. Fix the bug that OnBeginState() of GameStateInit is not called.
 *      5. Replace AUDIO_CANYON as AUDIO_NTUT.
 *      6. Add help bitmap to CGameStateRun.
 *   2006-09-09 V4.3
 *      1. Rename Move() and Show() as OnMove and OnShow() to emphasize that they are
 *         event driven.
 *   2006-12-30
 *      1. Bug fix: fix a memory leak problem by replacing PostQuitMessage(0) as
 *         PostMessage(AfxGetMainWnd()->m_hWnd, WM_CLOSE,0,0).
 *   2008-02-15 V4.4
 *      1. Add namespace game_framework.
 *      2. Replace the demonstration of animation as a new bouncing ball.
 *      3. Use ShowInitProgress(percent) to display loading progress.
 *   2010-03-23 V4.6
 *      1. Demo MP3 support: use lake.mp3 to replace lake.wav.
*/

#include "stdafx.h"
#include "Resource.h"
#include <mmsystem.h>
#include <ddraw.h>
#include <vector>
#include "audio.h"
#include "gamelib.h"
#include "mygame.h"

namespace game_framework
{
Monster::Monster(int MapX, int MapY, int dir, vector<int> area, int map)
{
    hp = 500;
    timer_death = -1;
	timer_gethit = -1;
    currentMap = map;
    Area = area;
    LoadBitmap();
    x = MapX;
    y = MapY - animationStandR.Height() - 5;
    direction = dir;
}

void Monster::LoadBitmap()
{
    if (currentMap == 0)
    {
        animationStandR.AddBitmap(IDB_23standright_0, RGB(0, 255, 0));
        animationStandR.AddBitmap(IDB_23standright_1, RGB(0, 255, 0));
        animationStandR.AddBitmap(IDB_23standright_2, RGB(0, 255, 0));
        animationStandL.AddBitmap(IDB_23standleft_0, RGB(0, 255, 0));
        animationStandL.AddBitmap(IDB_23standleft_1, RGB(0, 255, 0));
        animationStandL.AddBitmap(IDB_23standleft_2, RGB(0, 255, 0));
        animationWalkR.AddBitmap(IDB_23moveright_0, RGB(0, 255, 0));
        animationWalkR.AddBitmap(IDB_23moveright_1, RGB(0, 255, 0));
        animationWalkR.AddBitmap(IDB_23moveright_2, RGB(0, 255, 0));
        animationWalkL.AddBitmap(IDB_23moveleft_0, RGB(0, 255, 0));
        animationWalkL.AddBitmap(IDB_23moveleft_1, RGB(0, 255, 0));
        animationWalkL.AddBitmap(IDB_23moveleft_2, RGB(0, 255, 0));
        animationHitL.AddBitmap(IDB_23hitleft_0, RGB(0, 255, 0));
        animationHitR.AddBitmap(IDB_23hitright_0, RGB(0, 255, 0));
        animationDieL.AddBitmap(IDB_23dieleft_0, RGB(0, 255, 0));
        animationDieL.AddBitmap(IDB_23dieleft_1, RGB(0, 255, 0));
        animationDieL.AddBitmap(IDB_23dieleft_2, RGB(0, 255, 0));
        animationDieR.AddBitmap(IDB_23dieright_0, RGB(0, 255, 0));
        animationDieR.AddBitmap(IDB_23dieright_1, RGB(0, 255, 0));
        animationDieR.AddBitmap(IDB_23dieright_2, RGB(0, 255, 0));
    }
}

void Monster::onShow(int Map_X, int Map_Y, int random)
{
    state = random;
    MapX = Map_X;
    MapY = Map_Y;

    if (hp <= 0)
    {
        if (direction == 0)
        {
            if (!animationDieR.IsFinalBitmap())
            {
                animationDieR.SetTopLeft(x + MapX, y + MapY - 5);
                animationDieR.OnShow();
            }
            else if (int(timer_death) == -1)
            {
                timer_death = clock();
            }
            else if ((clock() - timer_death) / CLOCKS_PER_SEC >= 3)
            {
                srand(x);
                direction = rand() % 2;
                state = rand() % 2;
                x = rand() % (Area[2] - Area[0]) + Area[0];
                timer_death = -1;
                hp = 500;
				animationDieR.Reset();
            }
        }
        else
        {
            if (!animationDieL.IsFinalBitmap())
            {
                animationDieL.SetTopLeft(x + MapX, y + MapY - 5);
                animationDieL.OnShow();
            }
            else if (int(timer_death) == -1)
            {
                timer_death = clock();
            }
            else if ((clock() - timer_death) / CLOCKS_PER_SEC >= 3)
            {
                srand(x);
                direction = rand() % 2;
                state = rand() % 2;
                x = rand() % (Area[2] - Area[0]) + Area[0];
                timer_death = -1;
                hp = 500;
				animationDieL.Reset();
            }
        }
    }
    else
    {
        if (direction == 0)
        {
            if (timer_gethit!=-1&&clock()-timer_gethit<=350)
            {
                animationHitR.SetTopLeft(x + MapX, y + MapY - 10);
                animationHitR.OnShow();
            }
            else
            {
				timer_gethit = -1;
                if (state == 0)
                {
                    animationStandR.SetTopLeft(x + MapX, y + MapY);
                    animationStandR.OnShow();
                }
                else
                {
                    if (x + 1 < Area[2])
                    {
                        x += 1;
                    }
                    else
                    {
                        direction = 1;
                        x -= 1;
                    }

                    animationWalkR.SetTopLeft(x + MapX, y + MapY);
                    animationWalkR.OnShow();
                }
            }
        }
        else
        {
            if (timer_gethit != -1 && clock() - timer_gethit <= 350)
            {
                animationHitL.SetTopLeft(x + MapX, y + MapY - 10);
                animationHitL.OnShow();
            }
            else
            {
				timer_gethit = -1;
                if (state == 0)
                {
                    animationStandL.SetTopLeft(x + MapX, y + MapY);
                    animationStandL.OnShow();
                }
                else
                {
                    if (x - 1 > Area[0])
                    {
                        x -= 1;
                    }
                    else
                    {
                        direction = 0;
                        x += 1;
                    }

                    animationWalkL.SetTopLeft(x + MapX, y + MapY);
                    animationWalkL.OnShow();
                }
            }
        }
    }
}

void Monster::onMove()
{
    if (hp <= 0)
    {
        if (direction == 0)
        {
            if (!animationDieR.IsFinalBitmap())
            {
                animationDieR.OnMove();
            }
        }
        else
        {
            if (!animationDieL.IsFinalBitmap())
            {
                animationDieL.OnMove();
            }
        }
    }
    else
    {
        if (direction == 0)
        {
            if (timer_gethit != -1 && clock() - timer_gethit <= 350)
            {
                animationHitR.OnMove();
            }
            else
            {
				timer_gethit = -1;
                if (state == 0)
                {
                    animationStandR.OnMove();
                }
                else
                {
                    animationWalkR.OnMove();
                }
            }
        }
        else
        {
            if (timer_gethit != -1 && clock() - timer_gethit <= 350)
            {
                animationHitL.OnMove();
            }
            else
            {
				timer_gethit = -1;
                if (state == 0)
                {
                    animationStandL.OnMove();
                }
                else
                {
                    animationWalkL.OnMove();
                }
            }
        }
    }
}

void Monster::getHit(int skillx1, int skilly1, int skillx2, int skilly2, int damage)
{
    if (x + MapX + (animationStandR.Width() / 2) >= skillx1 && x + MapX + (animationStandR.Width() / 2) <= skillx2 && y + MapY >= skilly1 && y + MapY <= skilly2)
    {
		if (timer_gethit == -1) {
			timer_gethit = clock();
			hp -= damage;
		}
    }
}

void Map::Initialize(int map)
{
    vector<int> Areaxy;
    vector<int> Ladderxy;
    int random;
    currentMap = map;
    Area.clear();
    Ladder.clear();

    if (currentMap == 0)
    {
        CAudio::Instance()->Load(bgm22, "sounds\\bgm2-2.mp3");
        CAudio::Instance()->Play(bgm22, true);
        Areaxy.clear();
        Areaxy.push_back(-25);
        Areaxy.push_back(595);
        Areaxy.push_back(1800);
        Areaxy.push_back(595);
        Area.push_back(Areaxy);
        Areaxy.clear();
        Areaxy.push_back(200);
        Areaxy.push_back(355);
        Areaxy.push_back(620);
        Areaxy.push_back(355);
        Area.push_back(Areaxy);
        Areaxy.clear();
        Areaxy.push_back(650);
        Areaxy.push_back(295);
        Areaxy.push_back(1155);
        Areaxy.push_back(295);
        Area.push_back(Areaxy);
        Areaxy.clear();
        Areaxy.push_back(-25);
        Areaxy.push_back(175);
        Areaxy.push_back(270);
        Areaxy.push_back(175);
        Area.push_back(Areaxy);
        Areaxy.clear();
        Areaxy.push_back(290);
        Areaxy.push_back(115);
        Areaxy.push_back(810);
        Areaxy.push_back(115);
        Area.push_back(Areaxy);
        Areaxy.clear();
        Areaxy.push_back(1190);
        Areaxy.push_back(355);
        Areaxy.push_back(1515);
        Areaxy.push_back(355);
        Area.push_back(Areaxy);
        Ladderxy.clear();
        Ladderxy.push_back(420);
        Ladderxy.push_back(355);
        Ladderxy.push_back(465);
        Ladderxy.push_back(515);
        Ladder.push_back(Ladderxy);
        Ladderxy.clear();
        Ladderxy.push_back(225);
        Ladderxy.push_back(175);
        Ladderxy.push_back(270);
        Ladderxy.push_back(275);
        Ladder.push_back(Ladderxy);
        Ladderxy.clear();
        Ladderxy.push_back(690);
        Ladderxy.push_back(115);
        Ladderxy.push_back(735);
        Ladderxy.push_back(215);
        Ladder.push_back(Ladderxy);
        Ladderxy.clear();
        Ladderxy.push_back(1010);
        Ladderxy.push_back(295);
        Ladderxy.push_back(1040);
        Ladderxy.push_back(500);
        Ladder.push_back(Ladderxy);
        background.LoadBitmap(IDB_map23);
        MapX = 0;
        MapY = 768 - background.Height();
        background.SetTopLeft(MapX, MapY);

        for (int i = 0; i < int(Area.size()); i++)
        {
            srand((unsigned)time(NULL));

            for (int j = Area[i][0]; j < Area[i][2]; j += random)
            {
                random = rand() % 2;
                monster.push_back(new Monster(j, Area[i][1], random, Area[i], currentMap));
                random = rand() % 80 + 90;
            }
        }
    }
}

int Map::getInitX()
{
    /*if (currentMap == 0) {
    	return 25;
    }*/
    return 30;
}

int Map::getInitY()
{
    return Area[0][1];
}

int Map::getMapX()
{
    return MapX;
}

int Map::getMapY()
{
    return MapY;
}

int Map::scrollRight()
{
    int step;

    if (background.Width() + MapX - 5 > 1024)
    {
        MapX -= 5;
        background.SetTopLeft(MapX, MapY);
        background.ShowBitmap();
        step = 0;
    }
    else if (background.Width() + MapX > 1024)
    {
        step = 5 - ((background.Width() + MapX) - 1024);
        MapX = 1024 - background.Width();
        background.SetTopLeft(MapX, MapY);
        background.ShowBitmap();
    }
    else
    {
        step = 5;
    }

    return step;
}

int Map::scrollLeft()
{
    int step;

    if (MapX + 5  < 0)
    {
        MapX += 5;
        background.SetTopLeft(MapX, MapY);
        background.ShowBitmap();
        step = 0;
    }
    else if (MapX < 0)
    {
        step = 5 + MapX;
        MapX = 0;
        background.SetTopLeft(MapX, MapY);
        background.ShowBitmap();
    }
    else
    {
        step = 5;
    }

    return step;
}

void Map::onShow()
{
    background.ShowBitmap();
}

void Map::monsterMove()
{
    for (int i = 0; i < int(monster.size()); i++)
    {
        monster[i]->onMove();
    }
}

void Map::monsterShow()
{
    srand((unsigned)time(NULL));

    for (int i = 0; i < int(monster.size()); i++)
    {
        monster[i]->onShow(MapX, MapY, rand() % 5);
    }
}

void Map::hitMonster(int skillx1, int skilly1, int skillx2, int skilly2, int damage)
{
    for (int i = 0; i < int(monster.size()); i++)
    {
        monster[i]->getHit(skillx1, skilly1, skillx2, skilly2, damage);
    }
}

void Map::setArea(vector<int>* pos)
{
    for (int i = 0; i < int(Area.size()); i++)
    {
        if ((*pos)[0] - MapX >= Area[i][0] && (*pos)[0] - MapX <= Area[i][2] && (abs((*pos)[1] - MapY - (Area[i][1] - 75)) <= 10))
        {
            (*pos)[1] = Area[i][1] - MapY - 70;
        }
    }
}

void Map::setLadder(vector<int>* pos)
{
    for (int i = 0; i < int(Ladder.size()); i++)
    {
        if ((*pos)[0] - MapX >= Ladder[i][0] && (*pos)[0] - MapX <= Ladder[i][2] && (*pos)[1] - MapY >= Ladder[i][1] && (*pos)[1] - MapY <= Ladder[i][3])
        {
            (*pos)[0] = Ladder[i][0] + MapX;
        }
    }
}

bool Map::isArea(vector<int>* pos)
{
    for (int i = 0; i < int(Area.size()); i++)
    {
        if ((*pos)[0] - MapX >= Area[i][0] && (*pos)[0] - MapX <= Area[i][2] && (abs((*pos)[1] - MapY - (Area[i][1] - 75)) <= 10))
        {
            return true;
        }
    }

    return false;
}

bool Map::isLadder(vector<int>* pos)
{
    for (int i = 0; i < int(Ladder.size()); i++)
    {
        if ((*pos)[0] - MapX >= Ladder[i][0] && (*pos)[0] - MapX <= Ladder[i][2] && (*pos)[1] - MapY >= Ladder[i][1] && (*pos)[1] - MapY <= Ladder[i][3])
        {
            return true;
        }
    }

    return false;
}

/////////////////////////////////////////////////////////////////////////////
// CEraser: Eraser class
/////////////////////////////////////////////////////////////////////////////

int Character::GetX1()
{
    return x;
}

int Character::GetY1()
{
    return y;
}

int Character::GetX2()
{
    return x + animationStandR.Width();
}

int Character::GetY2()
{
    return y + animationStandR.Height();
}

int Character::GetFall()
{
    return Fall;
}
void Character::Initialize(Map* MAP)
{
    map = MAP;
    velocity = 13;
    initial_velocity = 13;
    Fall = 0;
    onLadder = 0;
    index = 0;
    State = 0;
    currentMap = 0;
    isJump = isMovingLeft = isMovingRight = isMovingUp = isMovingDown = isAttack = false;
    map->Initialize(currentMap);
    y = map->getInitY() - map->getMapY() - 70;
    x = map->getInitX();
}

void Character::LoadBitmap()
{
    animationStandR.AddBitmap(IDB_standright_0, RGB(0, 255, 0));
    animationStandR.AddBitmap(IDB_standright_1, RGB(0, 255, 0));
    animationStandR.AddBitmap(IDB_standright_2, RGB(0, 255, 0));
    animationStandR.AddBitmap(IDB_standright_3, RGB(0, 255, 0));
    animationStandL.AddBitmap(IDB_standleft_0, RGB(0, 255, 0));
    animationStandL.AddBitmap(IDB_standleft_1, RGB(0, 255, 0));
    animationStandL.AddBitmap(IDB_standleft_2, RGB(0, 255, 0));
    animationStandL.AddBitmap(IDB_standleft_3, RGB(0, 255, 0));
    animationProneR.AddBitmap(IDB_proneright_0, RGB(0, 255, 0));
    animationProneL.AddBitmap(IDB_proneleft_0, RGB(0, 255, 0));
    animationJumpR.AddBitmap(IDB_jumpright_0, RGB(0, 255, 0));
    animationJumpL.AddBitmap(IDB_jumpleft_0, RGB(0, 255, 0));
    animationWalkR.AddBitmap(IDB_walkright_0, RGB(0, 255, 0));
    animationWalkR.AddBitmap(IDB_walkright_1, RGB(0, 255, 0));
    animationWalkR.AddBitmap(IDB_walkright_2, RGB(0, 255, 0));
    animationWalkR.AddBitmap(IDB_walkright_3, RGB(0, 255, 0));
    animationWalkL.AddBitmap(IDB_walkleft_0, RGB(0, 255, 0));
    animationWalkL.AddBitmap(IDB_walkleft_1, RGB(0, 255, 0));
    animationWalkL.AddBitmap(IDB_walkleft_2, RGB(0, 255, 0));
    animationWalkL.AddBitmap(IDB_walkleft_3, RGB(0, 255, 0));
    animationAttackR.AddBitmap(IDB_attackright_0, RGB(0, 255, 0));
    animationAttackR.AddBitmap(IDB_attackright_1, RGB(0, 255, 0));
    animationAttackR.AddBitmap(IDB_attackright_2, RGB(0, 255, 0));
    animationAttackL.AddBitmap(IDB_attackleft_0, RGB(0, 255, 0));
    animationAttackL.AddBitmap(IDB_attackleft_1, RGB(0, 255, 0));
    animationAttackL.AddBitmap(IDB_attackleft_2, RGB(0, 255, 0));
    animationLadder.AddBitmap(IDB_ladder_0, RGB(0, 255, 0));
    animationLadder.AddBitmap(IDB_ladder_1, RGB(0, 255, 0));
    animationSkillQL.AddBitmap(IDB_SkillQleft_0, RGB(255, 255, 255));
    animationSkillQL.AddBitmap(IDB_SkillQleft_1, RGB(255, 255, 255));
    animationSkillQL.AddBitmap(IDB_SkillQleft_2, RGB(255, 255, 255));
    animationSkillQL.AddBitmap(IDB_SkillQleft_3, RGB(255, 255, 255));
    animationSkillQL.AddBitmap(IDB_SkillQleft_4, RGB(255, 255, 255));
    animationSkillQR.AddBitmap(IDB_SkillQright_0, RGB(255, 255, 255));
    animationSkillQR.AddBitmap(IDB_SkillQright_1, RGB(255, 255, 255));
    animationSkillQR.AddBitmap(IDB_SkillQright_2, RGB(255, 255, 255));
    animationSkillQR.AddBitmap(IDB_SkillQright_3, RGB(255, 255, 255));
    animationSkillQR.AddBitmap(IDB_SkillQright_4, RGB(255, 255, 255));
    animationAttackR.SetDelayCount(3);
    animationAttackL.SetDelayCount(3);
    animationSkillQR.SetDelayCount(3);
    animationSkillQL.SetDelayCount(3);
}

void Character::OnMove()
{
    pos.clear();
    pos.push_back(x);
    pos.push_back(y);
    JudgeArea(&pos, "null");

    if (isAttack)
    {
        if (State == 0)
        {
            if (animationAttackR.IsFinalBitmap())
            {
                if (attackstate == 'Q')
                {
                    animationSkillQR.OnMove();
                    map->hitMonster(animationSkillQR.Left(), animationSkillQR.Top(), animationSkillQR.Left() + animationSkillQR.Width(), animationSkillQR.Top() + (animationSkillQR.Height() / 2), 100);

                    if (animationSkillQR.IsFinalBitmap())
                    {
                        isAttack = false;
                        animationAttackR.Reset();
                        animationSkillQR.Reset();
                    }
                }
            }
            else
            {
                animationAttackR.OnMove();
            }
        }
        else
        {
            if (animationAttackL.IsFinalBitmap())
            {
                if (attackstate == 'Q')
                {
                    animationSkillQL.OnMove();
                    map->hitMonster(animationSkillQL.Left(), animationSkillQL.Top(), animationSkillQL.Left() + animationSkillQL.Width(), animationSkillQL.Top() + (animationSkillQL.Height() / 2), 100);

                    if (animationSkillQL.IsFinalBitmap())
                    {
                        isAttack = false;
                        animationAttackL.Reset();
                        animationSkillQL.Reset();
                    }
                }
            }
            else
            {
                animationAttackL.OnMove();
            }
        }
    }

    if (isMovingLeft)
    {
        if (JudgeArea(&pos, "left"))
        {
            State = 1;
            x = pos[0];
            y = pos[1];
        }
    }
    else if (isMovingRight)
    {
        if (JudgeArea(&pos, "right"))
        {
            State = 0;
            x = pos[0];
            y = pos[1];
        }
    }
    else if (isMovingUp)
    {
        if (JudgeArea(&pos, "up"))
        {
            x = pos[0];
            y = pos[1];
        }
    }
    else if (isMovingDown)
    {
        if (JudgeArea(&pos, "down"))
        {
            x = pos[0];
            y = pos[1];
        }
    }
    else if (State == 0)
    {
        animationStandR.OnMove();
    }
    else if (State == 1)
    {
        animationStandL.OnMove();
    }

    if (isJump && onLadder == 0)
    {
        if (Fall == 1)
        {
            isJump = false;
        }
        else if (JudgeArea(&pos, "jump"))
        {
            y = pos[1];
        }
    }

    if (Fall == 1)
    {
        if (JudgeArea(&pos, "fall"))
        {
            if (map->isArea(&pos))
            {
                map->setArea(&pos);
                Fall = 0;
                velocity = initial_velocity;
            }

            x = pos[0];
            y = pos[1];
        }
    }
}

void Character::SetMovingDown(bool flag)
{
    isMovingDown = flag;
}

void Character::SetMovingLeft(bool flag)
{
    if (isAttack)
    {
        isMovingLeft = false;
    }
    else
    {
        isMovingLeft = flag;
    }
}

void Character::SetMovingRight(bool flag)
{
    if (isAttack)
    {
        isMovingRight = false;
    }
    else
    {
        isMovingRight = flag;
    }
}

void Character::SetMovingUp(bool flag)
{
    isMovingUp = flag;
}

void Character::SetAttack(bool flag, char c)
{
    isAttack = flag;
    attackstate = c;

    if (isAttack)
    {
        isMovingLeft = false;
        isMovingRight = false;
        isJump = false;
    }
}

void Character::SetJump(bool flag)
{
    if (isAttack)
    {
        isJump = false;
    }
    else
    {
        isJump = true;
    }
}

void Character::Jump(vector<int>* pos, string move)
{
    if (move == "jump")
    {
        if (velocity > initial_velocity)
        {
            velocity = initial_velocity;
        }

        if (velocity > 0)
        {
            (*pos)[1] -= velocity;
            velocity--;
        }
        else
        {
            Fall = 1;
            velocity = 1;
        }
    }
    else
    {
        if (velocity < 18)
        {
            velocity++;
        }

        (*pos)[1] += velocity;
    }
}

void Character::OnShow()
{
    if (isJump && onLadder == 0)
    {
        if (State == 0)
        {
            animationJumpR.SetTopLeft(x, y);
            animationJumpR.OnShow();
        }
        else
        {
            animationJumpL.SetTopLeft(x, y);
            animationJumpL.OnShow();
        }
    }
    else if (isAttack)
    {
        if (State == 0)
        {
            animationAttackR.SetTopLeft(x, y);
            animationAttackR.OnShow();

            if (animationAttackR.IsFinalBitmap())
            {
                animationSkillQR.SetTopLeft(x + 80, y - 25);
                animationSkillQR.OnShow();
            }
        }
        else
        {
            animationAttackL.SetTopLeft(x, y);
            animationAttackL.OnShow();

            if (animationAttackL.IsFinalBitmap())
            {
                animationSkillQL.SetTopLeft(x - 260, y - 25);
                animationSkillQL.OnShow();
            }
        }
    }
    else if (isMovingRight && onLadder == 0)
    {
        animationWalkR.SetTopLeft(x, y);
        animationWalkR.OnShow();
        State = 0;
    }
    else if (isMovingLeft && onLadder == 0)
    {
        animationWalkL.SetTopLeft(x, y);
        animationWalkL.OnShow();
        State = 1;
    }
    else if (isMovingDown && onLadder == 0 && !isJump && Fall == 0)
    {
        if (State == 0)
        {
            animationProneR.SetTopLeft(x, y);
            animationProneR.OnShow();
        }
        else
        {
            animationProneL.SetTopLeft(x, y);
            animationProneL.OnShow();
        }
    }
    else if (onLadder == 1)
    {
        animationLadder.SetTopLeft(x, y);
        animationLadder.OnShow();
    }
    else if (State == 0 && onLadder == 0)
    {
        animationStandR.SetTopLeft(x, y);
        animationStandR.OnShow();
    }
    else if (State == 1 && onLadder == 0)
    {
        animationStandL.SetTopLeft(x, y);
        animationStandL.OnShow();
    }
}

bool Character::JudgeArea(vector<int>* pos, string dir)
{
    if (!map->isArea(pos) && !isJump && onLadder == 0)
    {
        if (Fall == 1)
        {
            isJump = false;
        }
        else
        {
            Fall = 1;
            velocity = 1;
        }
    }

    if (dir == "left" && onLadder == 0)
    {
        if ((*pos)[0] > 350)
        {
            (*pos)[0] -= 5;
        }
        else
        {
            (*pos)[0] -= map->scrollLeft();

            if ((*pos)[0] < -25)
            {
                (*pos)[0] = -25;
            }
        }

        animationWalkL.OnMove();
    }

    if (dir == "right" && onLadder == 0)
    {
        if ((*pos)[0] < 600)
        {
            (*pos)[0] += 5;
        }
        else
        {
            (*pos)[0] += map->scrollRight();

            if ((*pos)[0] > 985)
            {
                (*pos)[0] = 985;
            }
        }

        animationWalkR.OnMove();
    }

    if (dir == "up")
    {
        if (onLadder == 0)
        {
            if (map->isLadder(pos))
            {
                map->setLadder(pos);
                onLadder = 1;
                velocity = initial_velocity;
                animationLadder.OnShow();
                isMovingLeft = false;
                isMovingRight = false;
                isJump = false;
                Fall = 0;
            }
        }
        else
        {
            (*pos)[1] -= 5;
            isJump = false;
            animationLadder.OnMove();

            if (map->isArea(pos))
            {
                map->setArea(pos);
                onLadder = 0;
            }
        }
    }

    if (dir == "down")
    {
        if (onLadder == 0 && !isJump && Fall == 0)
        {
            if (State == 0)
            {
                animationProneR.OnMove();
            }
            else
            {
                animationProneL.OnMove();
            }
        }
        else if (onLadder == 1)
        {
            (*pos)[1] += 5;
            animationLadder.OnMove();

            if (map->isArea(pos))
            {
                map->setArea(pos);
                onLadder = 0;
            }
        }
    }

    if (dir == "jump" || dir == "fall")
    {
        Jump(pos, dir);

        if (State == 0)
        {
            animationJumpR.OnMove();
        }
        else
        {
            animationJumpL.OnMove();
        }
    }

    return true;
}
/////////////////////////////////////////////////////////////////////////////
// �o��class���C�����C���}�Y�e������
/////////////////////////////////////////////////////////////////////////////

CGameStateInit::CGameStateInit(CGame* g)
    : CGameState(g)
{
}

void CGameStateInit::OnInit()
{
    ShowInitProgress(0);	// �@�}�l��loading�i�׬�0%
}

void CGameStateInit::OnBeginState()
{
}

void CGameStateInit::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
{
    const char KEY_SPACE = ' ';

    if (nChar == KEY_SPACE)
        GotoGameState(GAME_STATE_RUN);						// ������GAME_STATE_RUN
}

void CGameStateInit::OnLButtonDown(UINT nFlags, CPoint point)
{
    GotoGameState(GAME_STATE_RUN);		// ������GAME_STATE_RUN
}

void CGameStateInit::OnShow()
{
    //
    // �K�Wlogo
    //
    //logo.SetTopLeft(CGameState::MapX, CGameState::MapY);
    //logo.ShowBitmap();
    //
    // Demo�ù��r�����ϥΡA���L�}�o�ɽкɶq�קK�����ϥΦr���A���CMovingBitmap����n
    //
    CDC* pDC = CDDraw::GetBackCDC();			// ���o Back Plain �� CDC
    CFont f, *fp;
    f.CreatePointFont(160, "Times New Roman");	// ���� font f; 160����16 point���r
    fp = pDC->SelectObject(&f);					// ��� font f
    pDC->SetBkColor(RGB(0, 0, 0));
    pDC->SetTextColor(RGB(255, 255, 0));
    pDC->TextOut(120, 220, "Please click mouse or press SPACE to begin.");
    pDC->TextOut(5, 395, "Press Ctrl-F to switch in between window mode and full screen mode.");
    pDC->TextOut(5, 455, "Press Alt-F4 or ESC to Quit.");
    pDC->SelectObject(fp);						// �� font f (�d�U���n�|�F��)
    CDDraw::ReleaseBackCDC();					// �� Back Plain �� CDC
}

/////////////////////////////////////////////////////////////////////////////
// �o��class���C�����������A(Game Over)
/////////////////////////////////////////////////////////////////////////////

CGameStateOver::CGameStateOver(CGame* g)
    : CGameState(g)
{
}

void CGameStateOver::OnInit()
{
    //
    // ���ϫܦh�ɡAOnInit���J�Ҧ����ϭn��ܦh�ɶ��C���קK���C�����H
    //     �������@�СA�C���|�X�{�uLoading ...�v�A���Loading���i�סC
    //
    ShowInitProgress(66);	// ���ӫe�@�Ӫ��A���i�סA���B�i�׵���66%
    //
    // �}�l���J���
    //
    //Sleep(300);				// ��C�A�H�K�ݲM���i�סA��ڹC���ЧR����Sleep
    //
    // �̲׶i�׬�100%
    //
    ShowInitProgress(100);
}

void CGameStateOver::OnShow()
{
    CDC* pDC = CDDraw::GetBackCDC();			// ���o Back Plain �� CDC
    CFont f, *fp;
    f.CreatePointFont(160, "Times New Roman");	// ���� font f; 160����16 point���r
    fp = pDC->SelectObject(&f);					// ��� font f
    pDC->SetBkColor(RGB(0, 0, 0));
    pDC->SetTextColor(RGB(255, 255, 0));
    char str[80];								// Demo �Ʀr��r�ꪺ�ഫ
    pDC->TextOut(240, 210, str);
    pDC->SelectObject(fp);						// �� font f (�d�U���n�|�F��)
    CDDraw::ReleaseBackCDC();					// �� Back Plain �� CDC
}

/////////////////////////////////////////////////////////////////////////////
// �o��class���C�����C�����檫��A�D�n���C���{�����b�o��
/////////////////////////////////////////////////////////////////////////////

CGameStateRun::CGameStateRun(CGame* g)
    : CGameState(g) {}

void CGameStateRun::OnBeginState()
{
}

void CGameStateRun::OnMove()							// ���ʹC������
{
    map.monsterMove();
    character.OnMove();
}

void CGameStateRun::OnInit()  								// �C������Ȥιϧγ]�w
{
    //
    // ���ϫܦh�ɡAOnInit���J�Ҧ����ϭn��ܦh�ɶ��C���קK���C�����H
    //     �������@�СA�C���|�X�{�uLoading ...�v�A���Loading���i�סC
    //
    ShowInitProgress(33);	// ���ӫe�@�Ӫ��A���i�סA���B�i�׵���33%
    //
    // �}�l���J���
    //
    character.LoadBitmap();
    character.Initialize(&map);
    ShowInitProgress(50);
    // ���J�s��0���n��ding.wav
    //
    // ��OnInit�ʧ@�|����CGameStaterOver::OnInit()�A�ҥH�i���٨S��100%
    //
}

void CGameStateRun::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
    const char KEY_LEFT = 0x25; // keyboard���b�Y
    const char KEY_UP = 0x26; // keyboard�W�b�Y
    const char KEY_RIGHT = 0x27; // keyboard�k�b�Y
    const char KEY_DOWN = 0x28; // keyboard�U�b�Y
    const char KEY_JUMP = 0x5a;  // keyboard 'z'
    const char KEY_SKILLQ = 0x51;

    if (nChar == KEY_SKILLQ)
    {
        character.SetAttack(true, 'Q');
    }

    if (nChar == KEY_LEFT)
    {
        character.SetMovingLeft(true);
        character.SetMovingRight(false);
    }

    if (nChar == KEY_RIGHT)
    {
        character.SetMovingRight(true);
        character.SetMovingLeft(false);
    }

    if (nChar == KEY_UP)
    {
        character.SetMovingUp(true);
        character.SetMovingDown(false);
    }

    if (nChar == KEY_DOWN)
    {
        character.SetMovingDown(true);
        character.SetMovingUp(false);
    }

    if (nChar == KEY_JUMP)
    {
        character.SetJump(true);
    }
}

void CGameStateRun::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
{
    const char KEY_LEFT = 0x25; // keyboard���b�Y
    const char KEY_UP = 0x26; // keyboard�W�b�Y
    const char KEY_RIGHT = 0x27; // keyboard�k�b�Y
    const char KEY_DOWN = 0x28; // keyboard�U�b�Y
    const char KEY_SkillQ = 0x51;

    if (nChar == KEY_LEFT)
    {
        character.SetMovingLeft(false);
    }

    if (nChar == KEY_RIGHT)
    {
        character.SetMovingRight(false);
    }

    if (nChar == KEY_UP)
    {
        character.SetMovingUp(false);
    }

    if (nChar == KEY_DOWN)
    {
        character.SetMovingDown(false);
    }
}

void CGameStateRun::OnShow()
{
    map.onShow();
    map.monsterShow();
    character.OnShow();
}
}