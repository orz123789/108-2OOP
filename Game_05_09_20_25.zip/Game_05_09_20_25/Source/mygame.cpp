#include "stdafx.h"
#include "Resource.h"
#include <mmsystem.h>
#include <ddraw.h>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include "audio.h"
#include "gamelib.h"
#include "mygame.h"

namespace game_framework
{
	Item::Item(int px, int py, string s)
	{
		timer_show = clock();
		x = px;
		y = py;
		name = s;
		num = 1;
		LoadBitmap();
	}
	Item::~Item()
	{
		for (int i = 0; i < (int)numfont.size(); i++) {
			delete numfont[i];
		}
	}
	void Item::LoadBitmap()
	{
		if (name == "�����Ĥ�") {
			item_pic.LoadBitmap(IDB_potion_red, RGB(0, 255, 0));
		}
		else if (name == "�Ŧ��Ĥ�") {
			item_pic.LoadBitmap(IDB_potion_blue, RGB(0, 255, 0));
		}
		else if (name == "�H����C") {
			item_pic.LoadBitmap(IDB_sword_0, RGB(0, 255, 0));
		}
		else if (name == "�H��޵P") {
			item_pic.LoadBitmap(IDB_shield_0, RGB(0, 255, 0));
		}
		else if (name == "�H��W��") {
			item_pic.LoadBitmap(IDB_cloth_0, RGB(0, 255, 0));
		}
	}
	void Item::SetTopLeft(int x1, int y1)
	{
		x = x1;
		y = y1;
	}
	void Item::onShow(int MapX, int MapY, bool floating)
	{
		if (floating) {
			item_pic.SetTopLeft(x + MapX, y + MapY - 5);
		}
		else {
			item_pic.SetTopLeft(x + MapX, y + MapY);
		}
		item_pic.ShowBitmap();
	}
	int Item::GetX()
	{
		return x;
	}
	int Item::GetY()
	{
		return y;
	}
	int Item::GetWidth()
	{
		return item_pic.Width();
	}
	int Item::GetHeight()
	{
		return item_pic.Height();
	}
	int Item::GetNum()
	{
		return num;
	}
	string Item::GetName()
	{
		return name;
	}
	double Item::GetShowTime()
	{
		return timer_show;
	}
	void Item::AddNum()
	{
		num++;
	}
	void Item::ShowNum()
	{
		string s = to_string(num);
		for (int i = 0; i < (int)numfont.size(); i++) {
			delete numfont[i];
		}
		numfont.clear();
		for (int i = 0; i < (int)s.size(); i++) {
			numfont.push_back(new CMovingBitmap);
			numfont[i]->LoadBitmap(335 + s[i] - 48, RGB(0, 255, 0));
			numfont[i]->SetTopLeft(x+30 - (s.length() - i)*numfont[i]->Width(),y+30-numfont[i]->Height());
			numfont[i]->ShowBitmap();
		}
	}
	Monster::Monster(int MapX, int MapY, int dir, vector<int> area, int map, int mexp, int damage)
	{
		expr = mexp;
		dmg = damage;
		hp = 500;
		timer_death = timer_gethit = timer_hit = -1;
		currentMap = map;
		Area = area;
		LoadBitmap();
		x = MapX;
		y = MapY - animationStandR.Height() - 5;
		direction = dir;
		mh = animationStandR.Height() / 2;
		mw = animationStandR.Width() / 2;
	}

	void Monster::LoadBitmap()
	{
		if (currentMap == 1)
		{
			animationStandR.AddBitmap(IDB_23standright_0, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_23standright_1, RGB(0, 255, 0));
			animationStandR.AddBitmap(IDB_23standright_2, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_23standleft_0, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_23standleft_1, RGB(0, 255, 0));
			animationStandL.AddBitmap(IDB_23standleft_2, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_23moveright_0, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_23moveright_1, RGB(0, 255, 0));
			animationWalkR.AddBitmap(IDB_23moveright_2, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_23moveleft_0, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_23moveleft_1, RGB(0, 255, 0));
			animationWalkL.AddBitmap(IDB_23moveleft_2, RGB(0, 255, 0));
			animationHitL.AddBitmap(IDB_23hitleft_0, RGB(0, 255, 0));
			animationHitR.AddBitmap(IDB_23hitright_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_23dieleft_0, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_23dieleft_1, RGB(0, 255, 0));
			animationDieL.AddBitmap(IDB_23dieleft_2, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_23dieright_0, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_23dieright_1, RGB(0, 255, 0));
			animationDieR.AddBitmap(IDB_23dieright_2, RGB(0, 255, 0));
		}
	}

	void Monster::onShow(int Map_X, int Map_Y, int random)
	{
		state = random;
		MapX = Map_X;
		MapY = Map_Y;

		if (hp <= 0)
		{
			if (direction == 0)
			{
				if (!animationDieR.IsFinalBitmap())
				{
					animationDieR.SetTopLeft(x + MapX + mw, y + MapY - 5 + mh);
					animationDieR.OnShow();
				}
				else if (int(timer_death) == -1)
				{
					timer_death = clock();
				}
				else if ((clock() - timer_death) / CLOCKS_PER_SEC >= 3)
				{
					srand(x);
					direction = rand() % 2;
					state = rand() % 2;
					x = rand() % (Area[2] - Area[0]) + Area[0];
					timer_death = -1;
					hp = 500;
					animationDieR.Reset();
				}
			}
			else
			{
				if (!animationDieL.IsFinalBitmap())
				{
					animationDieL.SetTopLeft(x + MapX + mw, y + MapY - 5 + mh);
					animationDieL.OnShow();
				}
				else if (int(timer_death) == -1)
				{
					timer_death = clock();
				}
				else if ((clock() - timer_death) / CLOCKS_PER_SEC >= 3)
				{
					srand(x);
					direction = rand() % 2;
					state = rand() % 2;
					x = rand() % (Area[2] - Area[0]) + Area[0];
					timer_death = -1;
					hp = 500;
					animationDieL.Reset();
				}
			}
		}
		else
		{
			if (direction == 0)
			{
				if (timer_gethit != -1 && clock() - timer_gethit <= 350)
				{
					animationHitR.SetTopLeft(x + MapX + mw, y + MapY - 10 + mh);
					animationHitR.OnShow();
				}
				else
				{
					timer_gethit = -1;
					if (state == 0)
					{
						animationStandR.SetTopLeft(x + MapX + mw, y + MapY + mh);
						animationStandR.OnShow();
					}
					else
					{
						if (x + 1 < Area[2])
						{
							x += 1;
						}
						else
						{
							direction = 1;
							x -= 1;
						}

						animationWalkR.SetTopLeft(x + MapX + mw, y + MapY + mh);
						animationWalkR.OnShow();
					}
				}
			}
			else
			{
				if (timer_gethit != -1 && clock() - timer_gethit <= 350)
				{
					animationHitL.SetTopLeft(x + MapX + mw, y + MapY - 10 + mh);
					animationHitL.OnShow();
				}
				else
				{
					timer_gethit = -1;
					if (state == 0)
					{
						animationStandL.SetTopLeft(x + MapX + mw, y + MapY + mh);
						animationStandL.OnShow();
					}
					else
					{
						if (x - 1 > Area[0])
						{
							x -= 1;
						}
						else
						{
							direction = 0;
							x += 1;
						}

						animationWalkL.SetTopLeft(x + MapX + mw, y + MapY + mh);
						animationWalkL.OnShow();
					}
				}
			}
		}
	}

	void Monster::onMove()
	{
		if (hp <= 0)
		{
			if (direction == 0)
			{
				if (!animationDieR.IsFinalBitmap())
				{
					animationDieR.OnMove();
				}
			}
			else
			{
				if (!animationDieL.IsFinalBitmap())
				{
					animationDieL.OnMove();
				}
			}
		}
		else
		{
			if (direction == 0)
			{
				if (timer_gethit != -1 && clock() - timer_gethit <= 350)
				{
					animationHitR.OnMove();
				}
				else
				{
					timer_gethit = -1;
					if (state == 0)
					{
						animationStandR.OnMove();
					}
					else
					{
						animationWalkR.OnMove();
					}
				}
			}
			else
			{
				if (timer_gethit != -1 && clock() - timer_gethit <= 350)
				{
					animationHitL.OnMove();
				}
				else
				{
					timer_gethit = -1;
					if (state == 0)
					{
						animationStandL.OnMove();
					}
					else
					{
						animationWalkL.OnMove();
					}
				}
			}
		}
	}

	int Monster::getHit(int cx, int cy, int skillx1, int skilly1, int skillx2, int skilly2, int damage, bool finalbitmap, int* totaldamage, vector<Item*>* item)
	{
		int srcx = x + MapX + (animationStandR.Width() / 2), srcy = y + MapY;
		if (srcx >= skillx1 && srcx <= skillx2 && srcy >= skilly1 && srcy <= skilly2)
		{
			if (timer_gethit == -1) {
				timer_gethit = clock();
				if (srcx > cx) {
					x += 25;
					if (x > Area[2]) {
						x = Area[2];
					}
				}
				else {
					x -= 25;
					if (x < Area[0]) {
						x = Area[0];
					}
				}
			}
			if (finalbitmap) {
				if (hp > 0) {
					(*totaldamage) = (*totaldamage) + damage;
					hp -= damage;
					if (hp <= 0) {
						int itemnum, itemtype, potiontype;
						srand(x);
						itemnum = rand() % 2 + 1;
						for (int i = 0; i < itemnum; i++) {
							itemtype = rand() % 100;
							if (itemtype >= 0 && itemtype < 70) {
								potiontype = rand() % 2;
								if (potiontype == 0) {
									item->push_back(new Item(x + 35 * i, Area[1] - 30, "�����Ĥ�"));
								}
								else {
									item->push_back(new Item(x + 35 * i, Area[1] - 30, "�Ŧ��Ĥ�"));
								}
							}
							else if (itemtype >= 70 && itemtype < 80) {
								item->push_back(new Item(x + 35 * i, Area[1] - 30, "�H����C"));
							}
							else if (itemtype >= 80 && itemtype < 90) {
								item->push_back(new Item(x + 35 * i, Area[1] - 30, "�H��޵P"));
							}
							else if (itemtype >= 90 && itemtype < 100) {
								item->push_back(new Item(x + 35 * i, Area[1] - 30, "�H��W��"));
							}
						}
						return expr;
					}
				}
			}
		}
		return 0;
	}

	int Monster::Hit(int x1, int y1, int x2, int y2)
	{
		int srcx, srcy = y + MapY;
		if (direction == 0) {
			srcx = x + animationStandR.Width() + MapX;
		}
		else {
			srcx = x + MapX;
		}
		if (hp > 0 && clock() - timer_hit >= 3000 && srcx >= x1 && srcx <= x2 && srcy + (animationStandR.Height() / 2) >= y1 && srcy + (animationStandR.Height() / 2) <= y2) {
			timer_hit = clock();
			return dmg;
		}
		return 0;
	}

	Map::~Map() {
		for (int i = 0; i < (int)monster.size(); i++) {
			delete monster[i];
		}
		for (int i = 0; i < (int)item.size(); i++) {
			delete item[i];
		}
		delete background;
	}
	void Map::Initialize(int map)
	{
		vector<int> Areaxy;
		vector<int> Ladderxy;
		vector<int> Teleportxy;
		int random;
		currentMap = map;
		Area.clear();
		Ladder.clear();
		Teleport.clear();
		floating = false;
		item_floating = -1;
		if (CAudio::Instance()->Load(bgm01, "sounds\\bgm0_1.mp3")) {
			CAudio::Instance()->Load(bgm23, "sounds\\bgm2_3.mp3");
		}
		for (int i = 0; i<int(monster.size()); i++) {
			delete monster[i];
		}
		monster.clear();
		if (currentMap == 0) {
			CAudio::Instance()->Play(bgm01, true);
			Areaxy.clear();
			Areaxy.push_back(70);
			Areaxy.push_back(440);
			Areaxy.push_back(680);
			Areaxy.push_back(440);
			Area.push_back(Areaxy);
			Teleportxy.clear();
			Teleportxy.push_back(620);
			Teleportxy.push_back(440);
			Teleportxy.push_back(700);
			Teleportxy.push_back(440);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);
			delete background;
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map01);
			MapX = (1024 - background->Width()) / 2;
			MapY = (768 - background->Height()) / 2;
			background->SetTopLeft(MapX, MapY);
		}
		else if (currentMap == 1)
		{
			CAudio::Instance()->Play(bgm23, true);
			Areaxy.clear();
			Areaxy.push_back(-25);
			Areaxy.push_back(595);
			Areaxy.push_back(1780);
			Areaxy.push_back(595);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(200);
			Areaxy.push_back(355);
			Areaxy.push_back(620);
			Areaxy.push_back(355);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(650);
			Areaxy.push_back(295);
			Areaxy.push_back(1155);
			Areaxy.push_back(295);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(-25);
			Areaxy.push_back(175);
			Areaxy.push_back(270);
			Areaxy.push_back(175);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(290);
			Areaxy.push_back(115);
			Areaxy.push_back(810);
			Areaxy.push_back(115);
			Area.push_back(Areaxy);
			Areaxy.clear();
			Areaxy.push_back(1190);
			Areaxy.push_back(355);
			Areaxy.push_back(1515);
			Areaxy.push_back(355);
			Area.push_back(Areaxy);
			Ladderxy.clear();
			Ladderxy.push_back(420);
			Ladderxy.push_back(355);
			Ladderxy.push_back(465);
			Ladderxy.push_back(515);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(225);
			Ladderxy.push_back(175);
			Ladderxy.push_back(270);
			Ladderxy.push_back(275);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(690);
			Ladderxy.push_back(115);
			Ladderxy.push_back(735);
			Ladderxy.push_back(215);
			Ladder.push_back(Ladderxy);
			Ladderxy.clear();
			Ladderxy.push_back(1010);
			Ladderxy.push_back(295);
			Ladderxy.push_back(1040);
			Ladderxy.push_back(500);
			Ladder.push_back(Ladderxy);
			Teleportxy.clear();
			Teleportxy.push_back(25);
			Teleportxy.push_back(595);
			Teleportxy.push_back(105);
			Teleportxy.push_back(595);
			Teleportxy.push_back(-1);
			Teleport.push_back(Teleportxy);
			/*Teleportxy.clear();
			Teleportxy.push_back(1715);
			Teleportxy.push_back(595);
			Teleportxy.push_back(1765);
			Teleportxy.push_back(595);
			Teleportxy.push_back(1);
			Teleport.push_back(Teleportxy);*/
			delete background;
			background = new CMovingBitmap;
			background->LoadBitmap(IDB_map23);
			MapX = 0;
			MapY = 768 - background->Height();
			background->SetTopLeft(MapX, MapY);

			for (int i = 0; i < int(Area.size()); i++)
			{
				srand((unsigned)time(NULL));

				for (int j = Area[i][0]; j < Area[i][2]; j += random)
				{
					random = rand() % 2;
					monster.push_back(new Monster(j, Area[i][1], random, Area[i], currentMap, 50, 50));
					random = rand() % 80 + 90;
				}
			}
		}
		edgex1 = Area[0][0];
		edgex2 = Area[0][2];
	}

	int Map::getInitX()
	{
		return 350;
	}

	int Map::getInitY()
	{
		return Area[0][1];
	}

	int Map::getMapX()
	{
		return MapX;
	}

	int Map::getMapY()
	{
		return MapY;
	}

	int Map::scrollRight()
	{
		int step;

		if (background->Width() + MapX - 5 > 1024)
		{
			MapX -= 5;
			background->SetTopLeft(MapX, MapY);
			background->ShowBitmap();
			step = 0;
		}
		else if (background->Width() + MapX > 1024)
		{
			step = 5 - ((background->Width() + MapX) - 1024);
			MapX = 1024 - background->Width();
			background->SetTopLeft(MapX, MapY);
			background->ShowBitmap();
		}
		else
		{
			step = 5;
		}

		return step;
	}

	int Map::scrollLeft()
	{
		int step;

		if (MapX + 5 < 0)
		{
			MapX += 5;
			background->SetTopLeft(MapX, MapY);
			background->ShowBitmap();
			step = 0;
		}
		else if (MapX < 0)
		{
			step = 5 + MapX;
			MapX = 0;
			background->SetTopLeft(MapX, MapY);
			background->ShowBitmap();
		}
		else
		{
			step = 5;
		}

		return step;
	}

	void Map::onShow()
	{
		background->ShowBitmap();
	}

	void Map::itemShow()
	{
		int del = -1;
		if (clock() - item_floating >= 500) {
			floating = !floating;
			item_floating = clock();
		}
		for (int i = 0; i < (int)item.size(); i++) {
			if (clock() - item[i]->GetShowTime() >= 10000) {
				del = i;
			}
		}
		if (del != -1) {
			item.erase(item.begin(), item.begin() + del + 1);
		}
		for (int i = 0; i < (int)item.size(); i++) {
			item[i]->onShow(MapX, MapY, floating);
		}
	}

	void Map::monsterMove()
	{
		for (int i = 0; i < int(monster.size()); i++)
		{
			monster[i]->onMove();
		}
	}

	void Map::monsterShow()
	{
		srand((unsigned)time(NULL));

		for (int i = 0; i < int(monster.size()); i++)
		{
			monster[i]->onShow(MapX, MapY, rand() % 5);
		}
	}

	int Map::hitMonster(int cx, int cy, int skillx1, int skilly1, int skillx2, int skilly2, int damage, bool finalbitmap, int* totaldamage)
	{
		int expr = 0;
		for (int i = 0; i < int(monster.size()); i++)
		{
			expr += monster[i]->getHit(cx, cy, skillx1, skilly1, skillx2, skilly2, damage, finalbitmap, totaldamage, &item);
		}
		return expr;
	}

	int Map::Monsterhit(int x1, int y1, int x2, int y2)
	{
		int damage = 0;
		for (int i = 0; i < int(monster.size()); i++)
		{
			damage += monster[i]->Hit(x1, y1, x2, y2);
		}
		return damage;
	}

	void Map::PickItem(int x, int y, int w, int h, vector<Item*>* backpack)
	{
		vector<int> del;
		for (int i = 0; i < (int)item.size(); i++) {
			if (item[i]->GetX() + item[i]->GetWidth() / 2 >= x && item[i]->GetX() + item[i]->GetWidth() / 2 <= x + w && item[i]->GetY() + item[i]->GetHeight() / 2 >= y && item[i]->GetY() + item[i]->GetHeight() / 2 <= y + h) {
				backpack->push_back(item[i]);
				del.push_back(i);
			}
		}
		for (int i = (int)del.size() - 1; i >= 0; i--) {
			item.erase(item.begin() + del[i]);
		}
	}

	void Map::setArea(vector<int>* pos)
	{
		for (int i = 0; i < int(Area.size()); i++)
		{
			if ((*pos)[0] - MapX >= Area[i][0] && (*pos)[0] - MapX <= Area[i][2] && (abs((*pos)[1] - MapY - (Area[i][1] - 70)) <= 10))
			{
				(*pos)[1] = Area[i][1] + MapY - 70;
			}
		}
	}

	void Map::setLadder(vector<int>* pos)
	{
		for (int i = 0; i < int(Ladder.size()); i++)
		{
			if ((*pos)[0] - MapX >= Ladder[i][0] && (*pos)[0] - MapX <= Ladder[i][2] && (*pos)[1] - MapY >= Ladder[i][1] && (*pos)[1] - MapY <= Ladder[i][3])
			{
				(*pos)[0] = Ladder[i][0] + MapX;
			}
		}
	}

	int Map::setTeleport(vector<int>* pos)
	{
		int tmp;
		for (int i = 0; i < int(Teleport.size()); i++)
		{
			if ((*pos)[0] - MapX >= Teleport[i][0] && (*pos)[0] - MapX <= Teleport[i][2] && (abs((*pos)[1] - MapY - (Teleport[i][1] - 70)) <= 10))
			{
				tmp = Teleport[i][4];
				CAudio::Instance()->Stop(currentMap);
				currentMap += tmp;
				Initialize(currentMap);
				if (tmp == 1) {
					(*pos)[0] = Teleport[0][0] + MapX;
					(*pos)[1] = Teleport[0][1] + MapY - 70;
				}
				else {
					(*pos)[0] = Teleport[int(Teleport.size()) - 1][0] + MapX;
					(*pos)[1] = Teleport[int(Teleport.size()) - 1][1] + MapY - 70;
				}
				break;
			}
		}
		return currentMap;
	}

	bool Map::isEdge(vector<int>* pos, string direction)
	{
		if ((*pos)[0] - MapX - 5 < edgex1&&direction == "left") {
			(*pos)[0] = edgex1 + MapX;
			return true;
		}
		else if ((*pos)[0] - MapX + 5 > edgex2&&direction == "right") {
			(*pos)[0] = edgex2 + MapX;
			return true;
		}
		return false;
	}

	bool Map::isArea(vector<int>* pos)
	{
		for (int i = 0; i < int(Area.size()); i++)
		{
			if ((*pos)[0] - MapX >= Area[i][0] && (*pos)[0] - MapX <= Area[i][2] && (abs((*pos)[1] - MapY - (Area[i][1] - 70)) <= 10))
			{
				return true;
			}
		}

		return false;
	}

	bool Map::isLadder(vector<int>* pos)
	{
		for (int i = 0; i < int(Ladder.size()); i++)
		{
			if ((*pos)[0] - MapX >= Ladder[i][0] && (*pos)[0] - MapX <= Ladder[i][2] && (*pos)[1] - MapY >= Ladder[i][1] && (*pos)[1] - MapY <= Ladder[i][3])
			{
				return true;
			}
		}

		return false;
	}

	bool Map::isTeleport(vector<int>* pos)
	{
		for (int i = 0; i < int(Teleport.size()); i++)
		{
			if ((*pos)[0] - MapX >= Teleport[i][0] && (*pos)[0] - MapX <= Teleport[i][2] && (abs((*pos)[1] - MapY - (Teleport[i][1] - 70)) <= 10))
			{
				return true;
			}
		}
		return false;
	}

	Character::~Character()
	{
		for (int i = 0; i < (int)backpack.size(); i++) {
			delete backpack[i];
		}
		for (int i = 0; i < (int)hp_pic.size(); i++) {
			delete hp_pic[i];
		}
		for (int i = 0; i < (int)mp_pic.size(); i++) {
			delete mp_pic[i];
		}
		for (int i = 0; i < (int)level_num.size(); i++) {
			delete level_num[i];
		}
		for (int i = 0; i < (int)hp_num.size(); i++) {
			delete hp_num[i];
		}
		for (int i = 0; i < (int)hplimit_num.size(); i++) {
			delete hplimit_num[i];
		}
		for (int i = 0; i < (int)mp_num.size(); i++) {
			delete mp_num[i];
		}
		for (int i = 0; i < (int)mplimit_num.size(); i++) {
			delete mplimit_num[i];
		}
		for (int i = 0; i < (int)q_cd_time.size(); i++) {
			delete q_cd_time[i];
		}
		for (int i = 0; i < (int)w_cd_time.size(); i++) {
			delete w_cd_time[i];
		}
		for (int i = 0; i < (int)damagefont.size(); i++) {
			for (int j = 0; j < (int)damagefont[i].size(); j++) {
				delete damagefont[i][j];
			}
		}
	}

	int Character::GetX1()
	{
		return x;
	}

	int Character::GetY1()
	{
		return y;
	}

	int Character::GetX2()
	{
		return x + animationStandR.Width();
	}

	int Character::GetY2()
	{
		return y + animationStandR.Height();
	}

	int Character::GetFall()
	{
		return Fall;
	}
	int Character::LevelUp(int lvl)
	{
		if (lvl == 1) {
			return 100;
		}
		else {
			return LevelUp(lvl - 1) + 200;
		}
	}
	void Character::Initialize(Map* MAP)
	{
		map = MAP;
		lvl = 1;
		hp = hp_limit = 500;
		mp = mp_limit = 500;
		q_mp = 50;
		w_mp = 200;
		hp_timer = mp_timer = q_timer = w_timer = -1;
		q_cd = 300;
		w_cd = 2000;
		velocity = 13;
		initial_velocity = 13;
		Fall = onLadder = direction = currentMap = expr = 0;
		openBackpack = pickItem = isJump = isMovingLeft = isMovingRight = isMovingUp = isMovingDown = isAttack = false;
		map->Initialize(currentMap);
		mh = animationStandR.Height() / 2;
		mw = animationStandR.Width() / 2;
		x = map->getInitX() + map->getMapX();
		y = map->getInitY() + map->getMapY() - 70;
	}

	void Character::LoadBitmap()
	{
		playerinfo.LoadBitmap(IDB_playerinfo, RGB(0, 255, 0));
		for (int i = 0; i < 100; i++) {
			hp_pic.push_back(new CMovingBitmap);
			mp_pic.push_back(new CMovingBitmap);
			hp_pic[i]->LoadBitmap(IDB_hp, RGB(0, 255, 0));
			mp_pic[i]->LoadBitmap(IDB_mp, RGB(0, 255, 0));
		}
		backpack_ui.LoadBitmap(IDB_backpack_ui);
		animationStandR.AddBitmap(IDB_standright_0, RGB(0, 255, 0));
		animationStandR.AddBitmap(IDB_standright_1, RGB(0, 255, 0));
		animationStandR.AddBitmap(IDB_standright_2, RGB(0, 255, 0));
		animationStandR.AddBitmap(IDB_standright_3, RGB(0, 255, 0));
		animationStandL.AddBitmap(IDB_standleft_0, RGB(0, 255, 0));
		animationStandL.AddBitmap(IDB_standleft_1, RGB(0, 255, 0));
		animationStandL.AddBitmap(IDB_standleft_2, RGB(0, 255, 0));
		animationStandL.AddBitmap(IDB_standleft_3, RGB(0, 255, 0));
		animationProneR.AddBitmap(IDB_proneright_0, RGB(0, 255, 0));
		animationProneL.AddBitmap(IDB_proneleft_0, RGB(0, 255, 0));
		animationJumpR.AddBitmap(IDB_jumpright_0, RGB(0, 255, 0));
		animationJumpL.AddBitmap(IDB_jumpleft_0, RGB(0, 255, 0));
		animationWalkR.AddBitmap(IDB_walkright_0, RGB(0, 255, 0));
		animationWalkR.AddBitmap(IDB_walkright_1, RGB(0, 255, 0));
		animationWalkR.AddBitmap(IDB_walkright_2, RGB(0, 255, 0));
		animationWalkR.AddBitmap(IDB_walkright_3, RGB(0, 255, 0));
		animationWalkL.AddBitmap(IDB_walkleft_0, RGB(0, 255, 0));
		animationWalkL.AddBitmap(IDB_walkleft_1, RGB(0, 255, 0));
		animationWalkL.AddBitmap(IDB_walkleft_2, RGB(0, 255, 0));
		animationWalkL.AddBitmap(IDB_walkleft_3, RGB(0, 255, 0));
		animationAttackR.AddBitmap(IDB_attackright_0, RGB(0, 255, 0));
		animationAttackR.AddBitmap(IDB_attackright_1, RGB(0, 255, 0));
		animationAttackR.AddBitmap(IDB_attackright_2, RGB(0, 255, 0));
		animationAttackL.AddBitmap(IDB_attackleft_0, RGB(0, 255, 0));
		animationAttackL.AddBitmap(IDB_attackleft_1, RGB(0, 255, 0));
		animationAttackL.AddBitmap(IDB_attackleft_2, RGB(0, 255, 0));
		animationLadder.AddBitmap(IDB_ladder_0, RGB(0, 255, 0));
		animationLadder.AddBitmap(IDB_ladder_1, RGB(0, 255, 0));
		animationGetHitR.AddBitmap(IDB_hitright_0, RGB(0, 255, 0));
		animationGetHitL.AddBitmap(IDB_hitleft_0, RGB(0, 255, 0));
		SkillQ.LoadBitmap(IDB_SkillQ, RGB(0, 255, 0));
		SkillW.LoadBitmap(IDB_SkillW, RGB(0, 255, 0));
		animationSkillQL.AddBitmap(IDB_SkillQleft_0, RGB(255, 255, 255));
		animationSkillQL.AddBitmap(IDB_SkillQleft_1, RGB(255, 255, 255));
		animationSkillQL.AddBitmap(IDB_SkillQleft_2, RGB(255, 255, 255));
		animationSkillQL.AddBitmap(IDB_SkillQleft_3, RGB(255, 255, 255));
		animationSkillQL.AddBitmap(IDB_SkillQleft_4, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_0, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_1, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_2, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_3, RGB(255, 255, 255));
		animationSkillQR.AddBitmap(IDB_SkillQright_4, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_0, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_1, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_2, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_3, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_4, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_5, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_6, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_7, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_8, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_9, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_10, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_11, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_12, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_13, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_14, RGB(255, 255, 255));
		animationSkillW1.AddBitmap(IDB_SkillW1_15, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_0, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_1, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_2, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_3, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_4, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_5, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_6, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_7, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_8, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_9, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_10, RGB(255, 255, 255));
		animationSkillW2.AddBitmap(IDB_SkillW2_11, RGB(255, 255, 255));
		animationAttackR.SetDelayCount(3);
		animationAttackL.SetDelayCount(3);
		animationSkillQR.SetDelayCount(3);
		animationSkillQL.SetDelayCount(3);
		animationSkillW1.SetDelayCount(3);
		animationSkillW2.SetDelayCount(3);
		animationAttackR.Reset();
		animationAttackL.Reset();
		animationSkillQR.Reset();
		animationSkillQL.Reset();
		animationSkillW1.Reset();
		animationSkillW2.Reset();
	}

	void Character::MakeFont(int num, string type)
	{
		string mkfont;
		if (type == "HP") {
			mkfont = to_string(num);
			for (int i = 0; i < (int)hp_num.size(); i++) {
				delete hp_num[i];
			}
			hp_num.clear();
			for (int i = 0; i < (int)mkfont.size(); i++) {
				hp_num.push_back(new CMovingBitmap);
				hp_num[i]->LoadBitmap(335 + mkfont[i] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "MP") {
			mkfont = to_string(num);
			for (int i = 0; i < (int)mp_num.size(); i++) {
				delete mp_num[i];
			}
			mp_num.clear();
			for (int i = 0; i < (int)mkfont.size(); i++) {
				mp_num.push_back(new CMovingBitmap);
				mp_num[i]->LoadBitmap(335 + mkfont[i] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "HPLimit") {
			mkfont = to_string(num);
			for (int i = 0; i < (int)hplimit_num.size(); i++) {
				delete hplimit_num[i];
			}
			hplimit_num.clear();
			hplimit_num.push_back(new CMovingBitmap);
			hplimit_num[0]->LoadBitmap(IDB_mphp_line, RGB(0, 255, 0));
			for (int i = 1; i < (int)mkfont.size() + 1; i++) {
				hplimit_num.push_back(new CMovingBitmap);
				hplimit_num[i]->LoadBitmap(335 + mkfont[i - 1] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "MPLimit") {
			mkfont = to_string(num);
			for (int i = 0; i < (int)mplimit_num.size(); i++) {
				delete mplimit_num[i];
			}
			mplimit_num.clear();
			mplimit_num.push_back(new CMovingBitmap);
			mplimit_num[0]->LoadBitmap(IDB_mphp_line, RGB(0, 255, 0));
			for (int i = 1; i < (int)mkfont.size() + 1; i++) {
				mplimit_num.push_back(new CMovingBitmap);
				mplimit_num[i]->LoadBitmap(335 + mkfont[i - 1] - 48, RGB(0, 255, 0));
			}
		}
		else if (type == "Damage") {
			mkfont = to_string(num);
			vector<CMovingBitmap*> dmg_vector;
			int init_x, init_y;
			init_x = x + (animationStandR.Width() / 2) - ((mkfont.length() * 38) / 2);
			init_y = y - 15 - 59;
			for (int i = 0; i < (int)mkfont.size(); i++) {
				dmg_vector.push_back(new CMovingBitmap);
				dmg_vector[i]->LoadBitmap(302 + mkfont[i] - 48, RGB(0, 255, 0));
				dmg_vector[i]->SetTopLeft(init_x + i * 38, init_y);
			}
			damagefont.push_back(dmg_vector);
			damagefont_timer.push_back(clock());
		}
		else if (type == "level") {
			mkfont = to_string(num);
			for (int i = 0; i < (int)level_num.size(); i++) {
				delete level_num[i];
			}
			level_num.clear();
			for (int i = 0; i < (int)mkfont.size(); i++) {
				level_num.push_back(new CMovingBitmap);
				level_num[i]->LoadBitmap(312 + mkfont[i] - 48, RGB(255, 255, 255));
			}
		}
		else if (type == "Q_cd") {
			ostringstream stream;
			stream << fixed << setprecision(1);
			stream << (double)num / 1000;
			mkfont = stream.str();
			for (int i = 0; i < (int)q_cd_time.size(); i++) {
				delete q_cd_time[i];
			}
			q_cd_time.clear();
			for (int i = 0; i < (int)mkfont.size(); i++) {
				q_cd_time.push_back(new CMovingBitmap);
				if (mkfont[i] == '.') {
					q_cd_time[i]->LoadBitmap(IDB_skill_dot, RGB(0, 0, 0));
				}
				else {
					q_cd_time[i]->LoadBitmap(324 + mkfont[i] - 48, RGB(0, 0, 0));
				}
			}
		}
		else if (type == "W_cd") {
			ostringstream stream;
			stream << fixed << setprecision(1);
			stream << (double)num / 1000;
			mkfont = stream.str();
			for (int i = 0; i < (int)w_cd_time.size(); i++) {
				delete w_cd_time[i];
			}
			w_cd_time.clear();
			for (int i = 0; i < (int)mkfont.size(); i++) {
				w_cd_time.push_back(new CMovingBitmap);
				if (mkfont[i] == '.') {
					w_cd_time[i]->LoadBitmap(IDB_skill_dot, RGB(0, 0, 0));
				}
				else {
					w_cd_time[i]->LoadBitmap(324 + mkfont[i] - 48, RGB(0, 0, 0));
				}
			}
		}
	}

	void Character::ShowDamageFont()
	{
		int del = -1;
		for (int i = 0; i < (int)damagefont.size(); i++) {
			for (int j = 0; j < (int)damagefont[i].size(); j++) {
				if (clock() - damagefont_timer[i] <= 400) {
					damagefont[i][j]->SetTopLeft(damagefont[i][j]->Left(), damagefont[i][j]->Top() - (int)(((clock() - damagefont_timer[i]) / 100) * 2));
					damagefont[i][j]->ShowBitmap();
				}
			}
			if (clock() - damagefont_timer[i] >= 1500) {
				del = i;
			}
		}
		if (del != -1) {
			for (int i = 0; i < del + 1; i++) {
				for (int j = 0; j < (int)damagefont[i].size(); j++) {
					delete damagefont[i][j];
				}
			}
			damagefont_timer.erase(damagefont_timer.begin(), damagefont_timer.begin() + del + 1);
			damagefont.erase(damagefont.begin(), damagefont.begin() + del + 1);
		}
	}

	void Character::SetBackpack()
	{
		openBackpack = !openBackpack;
	}

	void Character::SetPick(bool flag)
	{
		pickItem = flag;
	}

	void Character::SetMovingDown(bool flag)
	{
		isMovingDown = flag;
	}

	void Character::SetMovingLeft(bool flag)
	{
		if (isAttack)
		{
			isMovingLeft = false;
		}
		else
		{
			isMovingLeft = flag;
		}
	}

	void Character::SetMovingRight(bool flag)
	{
		if (isAttack)
		{
			isMovingRight = false;
		}
		else
		{
			isMovingRight = flag;
		}
	}

	void Character::SetMovingUp(bool flag)
	{
		isMovingUp = flag;
	}

	void Character::SetAttack(bool flag, string s)
	{
		if (onLadder == 0) {
			isAttack = flag;
			attackstate = s;
			isMovingLeft = false;
			isMovingRight = false;
			isJump = false;
		}
	}

	void Character::SetJump(bool flag)
	{
		if (isAttack)
		{
			isJump = false;
		}
		else
		{
			isJump = true;
		}
	}

	void Character::OnShow()
	{
		vector<int> del;
		playerinfo.SetTopLeft(338, 677);
		playerinfo.ShowBitmap();
		if (openBackpack) {
			backpack_ui.SetTopLeft(858, 75);
			backpack_ui.ShowBitmap();
			for (int i = 0; i < (int)backpack.size(); i++) {
				for (int j = 0; j < i; j++) {
					if (backpack[i]->GetName() == backpack[j]->GetName()) {
						backpack[j]->AddNum();
						del.push_back(i);
						break;
					}
				}
			}
			for (int i = (int)del.size() - 1; i >= 0; i--) {
				delete backpack[del[i]];
				backpack.erase(backpack.begin() + del[i]);
			}
			for (int i = 0; i < (int)backpack.size(); i++) {
				backpack[i]->SetTopLeft(867 + (i % 4) * 36, 103 + (i / 4) * 35);
				backpack[i]->onShow(0, 0, false);
				backpack[i]->ShowNum();
			}
		}
		SkillQ.SetTopLeft(924, 0);
		SkillQ.ShowBitmap();
		SkillW.SetTopLeft(974, 0);
		SkillW.ShowBitmap();
		MakeFont(lvl, "level");
		for (int i = 0; i < (int)level_num.size(); i++) {
			level_num[i]->SetTopLeft(405 + 14 * i, 685);
			level_num[i]->ShowBitmap();
		}
		for (int i = 0; i < (int)ceil((double)hp / hp_limit * 100); i++) {
			hp_pic[i]->SetTopLeft(379 + 3 * i, 717);
			hp_pic[i]->ShowBitmap();
		}
		for (int i = 0; i < (int)ceil((double)mp / mp_limit * 100); i++) {
			mp_pic[i]->SetTopLeft(379 + 3 * i, 741);
			mp_pic[i]->ShowBitmap();
		}
		MakeFont(hp, "HP");
		for (int i = (int)hp_num.size() - 1; i >= 0; i--) {
			hp_num[i]->SetTopLeft(519 - ((int)hp_num.size() - 1 - i) * 10, 720);
			hp_num[i]->ShowBitmap();
		}
		MakeFont(mp, "MP");
		for (int i = (int)mp_num.size() - 1; i >= 0; i--) {
			mp_num[i]->SetTopLeft(519 - ((int)mp_num.size() - 1 - i) * 10, 744);
			mp_num[i]->ShowBitmap();
		}
		MakeFont(hp_limit, "HPLimit");
		for (int i = (int)hplimit_num.size() - 1; i >= 0; i--) {
			hplimit_num[i]->SetTopLeft(529 + i * 10, 720);
			hplimit_num[i]->ShowBitmap();
		}
		MakeFont(mp_limit, "MPLimit");
		for (int i = (int)mplimit_num.size() - 1; i >= 0; i--) {
			mplimit_num[i]->SetTopLeft(529 + i * 10, 744);
			mplimit_num[i]->ShowBitmap();
		}
		ShowDamageFont();
		if (q_cd - (clock() - q_timer) > 0 && q_timer != -1) {
			MakeFont(int(q_cd - (clock() - q_timer)), "Q_cd");
			for (int i = 0; i < (int)q_cd_time.size(); i++) {
				q_cd_time[i]->SetTopLeft(930 + i * 12, 50);
				q_cd_time[i]->ShowBitmap();
			}
		}
		if (w_cd - (clock() - w_timer) > 0 && w_timer != -1) {
			MakeFont(int(w_cd - (clock() - w_timer)), "W_cd");
			for (int i = 0; i < (int)w_cd_time.size(); i++) {
				w_cd_time[i]->SetTopLeft(980 + i * 12, 50);
				w_cd_time[i]->ShowBitmap();
			}
		}
		if (isJump && onLadder == 0)
		{
			if (direction == 0)
			{
				animationJumpR.SetTopLeft(x + mw, y + mh);
				animationJumpR.OnShow();
			}
			else
			{
				animationJumpL.SetTopLeft(x + mw, y + mh);
				animationJumpL.OnShow();
			}
		}
		else if (isAttack)
		{
			if (direction == 0)
			{
				if (attackstate == "Q") {
					animationAttackR.SetTopLeft(x + mw, y + mh);
					animationAttackR.OnShow();
					if (animationAttackR.IsFinalBitmap())
					{
						animationSkillQR.SetTopLeft(x + animationStandR.Width() + (animationSkillQL.Width() / 2), y + (animationSkillQL.Height() / 2));
						animationSkillQR.OnShow();
					}
				}
				else if (attackstate == "W1") {
					animationStandR.SetTopLeft(x + mw, y + mh);
					animationStandR.OnShow();
					animationSkillW1.SetTopLeft(x + mw, y - 125);
					animationSkillW1.OnShow();
				}
				else if (attackstate == "W2") {
					animationStandR.SetTopLeft(x + mw, y + mh);
					animationStandR.OnShow();
					animationSkillW2.SetTopLeft(x + mw, y - 125);
					animationSkillW2.OnShow();
				}
			}
			else
			{
				if (attackstate == "Q") {
					animationAttackL.SetTopLeft(x + mw, y + mh);
					animationAttackL.OnShow();
					if (animationAttackL.IsFinalBitmap())
					{
						animationSkillQL.SetTopLeft(x - (animationSkillQL.Width() / 2), y + (animationSkillQL.Height() / 2));
						animationSkillQL.OnShow();
					}

				}
				else if (attackstate == "W1") {
					animationStandL.SetTopLeft(x + mw, y + mh);
					animationStandL.OnShow();
					animationSkillW1.SetTopLeft(x + mw, y - 125);
					animationSkillW1.OnShow();
				}
				else if (attackstate == "W2") {
					animationStandL.SetTopLeft(x + mw, y + mh);
					animationStandL.OnShow();
					animationSkillW2.SetTopLeft(x + mw, y - 125);
					animationSkillW2.OnShow();
				}
			}
		}
		else if (isMovingRight && onLadder == 0)
		{
			animationWalkR.SetTopLeft(x + mw, y + mh);
			animationWalkR.OnShow();
			direction = 0;
		}
		else if (isMovingLeft && onLadder == 0)
		{
			animationWalkL.SetTopLeft(x + mw, y + mh);
			animationWalkL.OnShow();
			direction = 1;
		}
		else if (isMovingDown && onLadder == 0 && !isJump && Fall == 0)
		{
			if (direction == 0)
			{
				animationProneR.SetTopLeft(x + mw, y + mh);
				animationProneR.OnShow();
			}
			else
			{
				animationProneL.SetTopLeft(x + mw, y + mh);
				animationProneL.OnShow();
			}
		}
		else if (onLadder == 1)
		{
			animationLadder.SetTopLeft(x + mw, y + mh);
			animationLadder.OnShow();
		}
		else if (direction == 0 && onLadder == 0)
		{
			if (ishit&&clock() - hit_timer <= 1000) {
				animationGetHitR.SetTopLeft(x + mw, y + mh);
				animationGetHitR.OnShow();
			}
			else {
				animationStandR.SetTopLeft(x + mw, y + mh);
				animationStandR.OnShow();
			}
		}
		else if (direction == 1 && onLadder == 0)
		{
			if (ishit&&clock() - hit_timer <= 1000) {
				animationGetHitL.SetTopLeft(x + mw, y + mh);
				animationGetHitL.OnShow();
			}
			else {
				animationStandL.SetTopLeft(x + mw, y + mh);
				animationStandL.OnShow();
			}
		}
	}

	void Character::OnMove()
	{
		int totaldmg = 0, getdmg = map->Monsterhit(x, y, x + animationStandR.Width(), y + animationStandR.Height());
		if (getdmg != 0) {
			hp -= getdmg;
			getdmg = 0;
			ishit = true;
			hit_timer = clock();
		}
		if (mp < mp_limit&&clock() - mp_timer >= 1000) {
			mp = mp + 20 + 5 * (lvl - 1);
			mp_timer = clock();
			if (mp > mp_limit) {
				mp = mp_limit;
			}
		}
		if (hp < hp_limit&&clock() - hp_timer >= 1000) {
			hp = hp + 15 + 5 * (lvl - 1);
			hp_timer = clock();
			if (hp > hp_limit) {
				hp = hp_limit;
			}
		}
		if (expr >= LevelUp(lvl)) {
			expr -= LevelUp(lvl);
			lvl++;
			hp_limit += 50;
			mp_limit += 50;
			hp = hp_limit;
			mp = mp_limit;
		}
		if (pickItem) {
			map->PickItem(x - map->getMapX(), y - map->getMapY(), animationStandR.Width(), animationStandR.Height(), &backpack);
		}
		pos.clear();
		pos.push_back(x);
		pos.push_back(y);
		JudgeArea(&pos, "null");
		if (isAttack)
		{
			if (direction == 0)
			{
				if (attackstate == "Q") {
					if (mp >= q_mp && clock() - q_timer >= q_cd) {
						if (animationAttackR.IsFinalBitmap()) {
							animationSkillQR.OnMove();
							expr += map->hitMonster(x, y, animationSkillQR.Left(), animationSkillQR.Top(), animationSkillQR.Left() + animationSkillQR.Width(), animationSkillQR.Top() + (animationSkillQR.Height() / 2), 100 + 25 * (lvl - 1), animationSkillQR.IsFinalBitmap(), &totaldmg);
							if (animationSkillQR.IsFinalBitmap())
							{
								isAttack = false;
								animationAttackR.Reset();
								animationSkillQR.Reset();
								q_timer = clock();
								mp -= q_mp;
								if (totaldmg > 0) {
									MakeFont(totaldmg, "Damage");
								}
							}
						}
						else
						{
							animationAttackR.OnMove();
						}
					}
					else {
						isAttack = false;
					}
				}
				else if (attackstate == "W1") {
					if (mp >= w_mp && clock() - w_timer >= w_cd || skillwstate) {
						animationStandR.OnMove();
						animationSkillW1.OnMove();
						if (animationSkillW1.IsFinalBitmap()) {
							expr += map->hitMonster(x, y, animationSkillW1.Left(), animationSkillW1.Top(), animationSkillW1.Left() + animationSkillW1.Width(), animationSkillW1.Top() + animationSkillW1.Height(), 50 + 25 * (lvl - 1), animationSkillW1.IsFinalBitmap(), &totaldmg);
							if (totaldmg > 0) {
								MakeFont(totaldmg, "Damage");
							}
							animationSkillW1.Reset();
						}
						skillwstate = true;
					}
					else {
						isAttack = false;
					}
				}
				else if (attackstate == "W2") {
					if (skillwstate) {
						animationStandR.OnMove();
						animationSkillW2.OnMove();
						if (animationSkillW2.IsFinalBitmap())
						{
							expr += map->hitMonster(x, y, animationSkillW1.Left(), animationSkillW1.Top(), animationSkillW1.Left() + animationSkillW1.Width(), animationSkillW1.Top() + animationSkillW1.Height(), 150 + 25 * (lvl - 1), animationSkillW2.IsFinalBitmap(), &totaldmg);
							isAttack = false;
							animationSkillW2.Reset();
							skillwstate = false;
							w_timer = clock();
							mp -= w_mp;
							if (totaldmg > 0) {
								MakeFont(totaldmg, "Damage");
							}
						}
					}
					else {
						isAttack = false;
					}
				}
			}
			else
			{
				if (attackstate == "Q") {
					if (mp >= q_mp && clock() - q_timer >= q_cd) {
						if (animationAttackL.IsFinalBitmap()) {
							animationSkillQL.OnMove();
							expr += map->hitMonster(x, y, animationSkillQL.Left(), animationSkillQL.Top(), animationSkillQL.Left() + animationSkillQL.Width(), animationSkillQL.Top() + (animationSkillQL.Height() / 2), 100 + 25 * (lvl - 1), animationSkillQL.IsFinalBitmap(), &totaldmg);
							if (animationSkillQL.IsFinalBitmap())
							{
								isAttack = false;
								animationAttackL.Reset();
								animationSkillQL.Reset();
								q_timer = clock();
								mp -= q_mp;
								if (totaldmg > 0) {
									MakeFont(totaldmg, "Damage");
								}
							}
						}
						else
						{
							animationAttackL.OnMove();
						}
					}
					else {
						isAttack = false;
					}
				}
				else if (attackstate == "W1") {
					if (mp >= w_mp && clock() - w_timer >= w_cd || skillwstate) {
						animationStandL.OnMove();
						animationSkillW1.OnMove();
						if (animationSkillW1.IsFinalBitmap()) {
							expr += map->hitMonster(x, y, animationSkillW1.Left(), animationSkillW1.Top(), animationSkillW1.Left() + animationSkillW1.Width(), animationSkillW1.Top() + animationSkillW1.Height(), 50 + 25 * (lvl - 1), animationSkillW1.IsFinalBitmap(), &totaldmg);
							if (totaldmg > 0) {
								MakeFont(totaldmg, "Damage");
							}
							animationSkillW1.Reset();
						}
						skillwstate = true;
					}
					else {
						isAttack = false;
					}
				}
				else if (attackstate == "W2") {
					if (skillwstate) {
						animationStandL.OnMove();
						animationSkillW2.OnMove();
						if (animationSkillW2.IsFinalBitmap())
						{
							expr += map->hitMonster(x, y, animationSkillW1.Left(), animationSkillW1.Top(), animationSkillW1.Left() + animationSkillW1.Width(), animationSkillW1.Top() + animationSkillW1.Height(), 150 + 25 * (lvl - 1), animationSkillW2.IsFinalBitmap(), &totaldmg);
							isAttack = false;
							animationSkillW2.Reset();
							skillwstate = false;
							w_timer = clock();
							mp -= w_mp;
							if (totaldmg > 0) {
								MakeFont(totaldmg, "Damage");
							}
						}
					}
					else {
						isAttack = false;
					}
				}
			}
		}

		if (isMovingLeft)
		{
			if (JudgeArea(&pos, "left"))
			{
				direction = 1;
				x = pos[0];
				y = pos[1];
			}
		}
		else if (isMovingRight)
		{
			if (JudgeArea(&pos, "right"))
			{
				direction = 0;
				x = pos[0];
				y = pos[1];
			}
		}
		else if (isMovingUp)
		{
			if (JudgeArea(&pos, "up"))
			{
				x = pos[0];
				y = pos[1];
			}
		}
		else if (isMovingDown)
		{
			if (JudgeArea(&pos, "down"))
			{
				x = pos[0];
				y = pos[1];
			}
		}
		else if (direction == 0)
		{
			if (ishit&&clock() - hit_timer <= 1000) {
				animationGetHitR.OnMove();
			}
			else {
				ishit = false;
				animationStandR.OnMove();
			}
		}
		else if (direction == 1)
		{
			if (ishit&&clock() - hit_timer <= 1000) {
				animationGetHitL.OnMove();
			}
			else {
				ishit = false;
				animationStandL.OnMove();
			}
		}

		if (isJump && onLadder == 0)
		{
			if (Fall == 1)
			{
				isJump = false;
			}
			else if (JudgeArea(&pos, "jump"))
			{
				y = pos[1];
			}
		}

		if (Fall == 1)
		{
			if (JudgeArea(&pos, "fall"))
			{
				if (map->isArea(&pos))
				{
					map->setArea(&pos);
					Fall = 0;
					velocity = initial_velocity;
				}

				x = pos[0];
				y = pos[1];
			}
		}
	}
	void Character::Jump(vector<int>* pos, string move)
	{
		if (move == "jump")
		{
			if (velocity > initial_velocity)
			{
				velocity = initial_velocity;
			}

			if (velocity > 0)
			{
				(*pos)[1] -= velocity;
				velocity--;
			}
			else
			{
				Fall = 1;
				velocity = 1;
			}
		}
		else
		{
			if (velocity < 18)
			{
				velocity++;
			}

			(*pos)[1] += velocity;
		}
	}

	bool Character::JudgeArea(vector<int>* pos, string dir)
	{
		if (!map->isArea(pos) && !isJump && onLadder == 0)
		{
			if (Fall == 1)
			{
				isJump = false;
			}
			else
			{
				Fall = 1;
				velocity = 1;
			}
		}

		if (dir == "left" && onLadder == 0)
		{
			if (!map->isEdge(pos, "left")) {
				if ((*pos)[0] > 350)
				{
					(*pos)[0] -= 5;
				}
				else
				{
					(*pos)[0] -= map->scrollLeft();
				}
			}
			animationWalkL.OnMove();
		}

		if (dir == "right" && onLadder == 0)
		{
			if (!map->isEdge(pos, "right")) {
				if ((*pos)[0] < 600)
				{
					(*pos)[0] += 5;
				}
				else
				{
					(*pos)[0] += map->scrollRight();
				}
			}
			animationWalkR.OnMove();
		}

		if (dir == "up")
		{
			if (onLadder == 0)
			{
				if (map->isTeleport(pos)) {
					currentMap = map->setTeleport(pos);
					isMovingUp = false;
				}
				else if (map->isLadder(pos))
				{
					map->setLadder(pos);
					onLadder = 1;
					velocity = initial_velocity;
					animationLadder.OnShow();
					isMovingLeft = false;
					isMovingRight = false;
					isJump = false;
					Fall = 0;
				}
			}
			else
			{
				(*pos)[1] -= 5;
				isJump = false;
				animationLadder.OnMove();

				if (map->isArea(pos))
				{
					map->setArea(pos);
					onLadder = 0;
				}
			}
		}

		if (dir == "down")
		{
			if (onLadder == 0 && !isJump && Fall == 0)
			{
				if (direction == 0)
				{
					animationProneR.OnMove();
				}
				else
				{
					animationProneL.OnMove();
				}
			}
			else if (onLadder == 1)
			{
				(*pos)[1] += 5;
				animationLadder.OnMove();

				if (map->isArea(pos))
				{
					map->setArea(pos);
					onLadder = 0;
				}
			}
		}

		if (dir == "jump" || dir == "fall")
		{
			Jump(pos, dir);

			if (direction == 0)
			{
				animationJumpR.OnMove();
			}
			else
			{
				animationJumpL.OnMove();
			}
		}

		return true;
	}
	/////////////////////////////////////////////////////////////////////////////
	// �o��class���C�����C���}�Y�e������
	/////////////////////////////////////////////////////////////////////////////

	CGameStateInit::CGameStateInit(CGame* g)
		: CGameState(g)
	{
	}

	void CGameStateInit::OnInit()
	{
		ShowInitProgress(0);	// �@�}�l��loading�i�׬�0%
	}

	void CGameStateInit::OnBeginState()
	{
	}

	void CGameStateInit::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
	{
		const char KEY_SPACE = ' ';

		if (nChar == KEY_SPACE)
			GotoGameState(GAME_STATE_RUN);						// ������GAME_STATE_RUN
	}

	void CGameStateInit::OnLButtonDown(UINT nFlags, CPoint point)
	{
		GotoGameState(GAME_STATE_RUN);		// ������GAME_STATE_RUN
	}

	void CGameStateInit::OnShow()
	{
		//
		// �K�Wlogo
		//
		//logo.SetTopLeft(CGameState::MapX, CGameState::MapY);
		//logo.ShowBitmap();
		//
		// Demo�ù��r�����ϥΡA���L�}�o�ɽкɶq�קK�����ϥΦr���A���CMovingBitmap����n
		//
		CDC* pDC = CDDraw::GetBackCDC();			// ���o Back Plain �� CDC
		CFont f, *fp;
		f.CreatePointFont(160, "Times New Roman");	// ���� font f; 160����16 point���r
		fp = pDC->SelectObject(&f);					// ��� font f
		pDC->SetBkColor(RGB(0, 0, 0));
		pDC->SetTextColor(RGB(255, 255, 0));
		pDC->TextOut(120, 220, "Please click mouse or press SPACE to begin.");
		pDC->TextOut(5, 395, "Press Ctrl-F to switch in between window mode and full screen mode.");
		pDC->TextOut(5, 455, "Press Alt-F4 or ESC to Quit.");
		pDC->SelectObject(fp);						// �� font f (�d�U���n�|�F��)
		CDDraw::ReleaseBackCDC();					// �� Back Plain �� CDC
	}

	/////////////////////////////////////////////////////////////////////////////
	// �o��class���C�����������A(Game Over)
	/////////////////////////////////////////////////////////////////////////////

	CGameStateOver::CGameStateOver(CGame* g)
		: CGameState(g)
	{
	}

	void CGameStateOver::OnInit()
	{
		//
		// ���ϫܦh�ɡAOnInit���J�Ҧ����ϭn��ܦh�ɶ��C���קK���C�����H
		//     �������@�СA�C���|�X�{�uLoading ...�v�A���Loading���i�סC
		//
		ShowInitProgress(66);	// ���ӫe�@�Ӫ��A���i�סA���B�i�׵���66%
		//
		// �}�l���J���
		//
		//Sleep(300);				// ��C�A�H�K�ݲM���i�סA��ڹC���ЧR����Sleep
		//
		// �̲׶i�׬�100%
		//
		ShowInitProgress(100);
	}

	void CGameStateOver::OnShow()
	{
		CDC* pDC = CDDraw::GetBackCDC();			// ���o Back Plain �� CDC
		CFont f, *fp;
		f.CreatePointFont(160, "Times New Roman");	// ���� font f; 160����16 point���r
		fp = pDC->SelectObject(&f);					// ��� font f
		pDC->SetBkColor(RGB(0, 0, 0));
		pDC->SetTextColor(RGB(255, 255, 0));
		char str[80];								// Demo �Ʀr��r�ꪺ�ഫ
		pDC->TextOut(240, 210, str);
		pDC->SelectObject(fp);						// �� font f (�d�U���n�|�F��)
		CDDraw::ReleaseBackCDC();					// �� Back Plain �� CDC
	}

	/////////////////////////////////////////////////////////////////////////////
	// �o��class���C�����C�����檫��A�D�n���C���{�����b�o��
	/////////////////////////////////////////////////////////////////////////////

	CGameStateRun::CGameStateRun(CGame* g)
		: CGameState(g) {}

	void CGameStateRun::OnBeginState()
	{
	}

	void CGameStateRun::OnMove()							// ���ʹC������
	{
		map.monsterMove();
		character.OnMove();
	}

	void CGameStateRun::OnInit()  								// �C������Ȥιϧγ]�w
	{
		//
		// ���ϫܦh�ɡAOnInit���J�Ҧ����ϭn��ܦh�ɶ��C���קK���C�����H
		//     �������@�СA�C���|�X�{�uLoading ...�v�A���Loading���i�סC
		//
		ShowInitProgress(33);	// ���ӫe�@�Ӫ��A���i�סA���B�i�׵���33%
		//
		// �}�l���J���
		//
		character.LoadBitmap();
		character.Initialize(&map);
		ShowInitProgress(50);
		SetWindowPos(FindWindow(NULL, "game"), HWND_TOP, 400, 150, 0, 0, SWP_NOSIZE);
		// ���J�s��0���n��ding.wav
		//
		// ��OnInit�ʧ@�|����CGameStaterOver::OnInit()�A�ҥH�i���٨S��100%
		//
	}

	void CGameStateRun::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
	{
		const char KEY_BACKPACK = 0x49;
		const char KEY_PICK = 0x58;
		const char KEY_LEFT = 0x25;
		const char KEY_UP = 0x26;
		const char KEY_RIGHT = 0x27;
		const char KEY_DOWN = 0x28;
		const char KEY_JUMP = 0x5a;
		const char KEY_SKILLQ = 0x51;
		const char KEY_SKILLW = 0x57;
		if (nChar == KEY_BACKPACK)
		{
			character.SetBackpack();
		}
		if (nChar == KEY_PICK)
		{
			character.SetPick(true);
		}
		if (nChar == KEY_SKILLQ)
		{
			character.SetAttack(true, "Q");
		}

		if (nChar == KEY_SKILLW)
		{
			character.SetAttack(true, "W1");
		}

		if (nChar == KEY_LEFT)
		{
			character.SetMovingLeft(true);
			character.SetMovingRight(false);
		}

		if (nChar == KEY_RIGHT)
		{
			character.SetMovingRight(true);
			character.SetMovingLeft(false);
		}

		if (nChar == KEY_UP)
		{
			character.SetMovingUp(true);
			character.SetMovingDown(false);
		}

		if (nChar == KEY_DOWN)
		{
			character.SetMovingDown(true);
			character.SetMovingUp(false);
		}

		if (nChar == KEY_JUMP)
		{
			character.SetJump(true);
		}
	}

	void CGameStateRun::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
	{
		const char KEY_PICK = 0x58;
		const char KEY_LEFT = 0x25;
		const char KEY_UP = 0x26;
		const char KEY_RIGHT = 0x27;
		const char KEY_DOWN = 0x28;
		const char KEY_SKILLQ = 0x51;
		const char KEY_SKILLW = 0x57;
		if (nChar == KEY_PICK)
		{
			character.SetPick(false);
		}
		if (nChar == KEY_SKILLW)
		{
			character.SetAttack(true, "W2");
		}

		if (nChar == KEY_LEFT)
		{
			character.SetMovingLeft(false);
		}

		if (nChar == KEY_RIGHT)
		{
			character.SetMovingRight(false);
		}

		if (nChar == KEY_UP)
		{
			character.SetMovingUp(false);
		}

		if (nChar == KEY_DOWN)
		{
			character.SetMovingDown(false);
		}

	}

	void CGameStateRun::OnShow()
	{
		map.onShow();
		map.itemShow();
		map.monsterShow();
		character.OnShow();
	}
}