//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ͪ� Include �ɮסC
// �� game.rc �ϥ�
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_GAMETYPE                    129
#define IDB_BALL                        130
#define IDB_RACKET                      131
#define IDB_ERASER1                     131
#define IDB_BITMAP1                     132
#define IDB_CORNER                      133
#define IDB_BALL1                       134
#define IDB_BALL2                       135
#define IDB_BALL3                       136
#define IDB_BALL4                       137
#define IDB_0                           138
#define IDB_1                           139
#define IDB_2                           140
#define IDB_3                           141
#define IDB_4                           142
#define IDB_5                           143
#define IDB_6                           144
#define IDB_7                           145
#define IDB_8                           146
#define IDB_9                           147
#define IDB_MINUS                       148
#define IDB_CENTER                      149
#define IDB_ERASER2                     150
#define IDB_ERASER3                     151
#define IDB_CONTINUE                    152
#define IDC_GAMECURSOR                  153
#define IDB_HELP                        155
#define IDB_BITMAP2                     156
#define IDB_LOADING                     156
#define IDB_Blue                        158
#define IDB_BITMAP3                     159
#define IDB_Green                       159
#define IDB_stand1_0_right_weapon       160
#define IDB_stand1_1_right_weapon       161
#define IDB_stand1_2_right_weapon       162
#define IDB_stand1_3_right_weapon       163
#define IDB_map22                       164
#define IDB_PNG1                        165
#define IDB_PNG2                        166
#define IDB_PNG3                        167
#define IDB_PNG4                        168
#define IDB_PNG5                        169
#define IDB_walk1_0_right_weapon        170
#define IDB_walk1_1_right_weapon        171
#define IDB_walk1_2_right_weapon        172
#define IDB_walk1_3_right_weapon        173
#define IDB_jump_0_right_weapon         175
#define IDB_ladder_0                    176
#define IDB_ladder_1                    177
#define IDB_prone_0_left_weapon         178
#define IDB_rope_0                      179
#define IDB_rope_1                      180
#define IDB_swalk1_3_left_weapon        181
#define IDB_stand1_0_left_weapon        181
#define IDB_stand1_1_left_weapon        182
#define IDB_stand1_2_left_weapon        183
#define IDB_walk1_0_left_weapon         184
#define IDB_walk1_1_left_weapon         185
#define IDB_walk1_2_left_weapon         186
#define IDB_walk1_3_left_weapon         187
#define IDB_jumpleft_0                  188
#define IDB_jumpright_0                 190
#define IDB_proneleft_0                 191
#define IDB_proneright_1                192
#define IDB_proneright_0                192
#define IDB_standleft_0                 193
#define IDB_standleft_1                 194
#define IDB_standleft_2                 195
#define IDB_standleft_3                 196
#define IDB_standright_0                197
#define IDB_standright_1                198
#define IDB_standright_2                199
#define IDB_standright_3                200
#define IDB_walkleft_0                  201
#define IDB_walkleft_1                  202
#define IDB_walkleft_2                  203
#define IDB_walkleft_3                  204
#define IDB_walkright_0                 205
#define IDB_walkright_1                 206
#define IDB_walkright_2                 207
#define IDB_walkright_3                 208
#define IDC_README                      1001
#define ID_FILE_PAUSE                   32771
#define ID_TOGGLE_FULLSCREEN            32772
#define ID_BUTTON_FULLSCREEN            32773
#define ID_BUTTON_PAUSE                 32774
#define ID_BUTTON_UNITTEST              32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        209
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
