enum AUDIO_ID  				// �w�q�U�ح��Ī��s��
{
	bgm01,				// 0
	bgm23,			// 1
};

namespace game_framework
{
/////////////////////////////////////////////////////////////////////////////
// �o��class���ѥi�H����L�ηƹ�������l
// �����N�i�H��g���ۤv���{���F
/////////////////////////////////////////////////////////////////////////////
class Monster
{
    public:
        Monster(int, int, int, vector<int>, int,int,int);
        void LoadBitmap();
        void onShow(int, int, int);
        void onMove();
        int getHit(int,int,int, int, int, int, int,bool,int*);
		int Hit(int, int, int, int);
    protected:
        CAnimation animationStandR, animationStandL, animationWalkL, animationWalkR, animationHitL, animationHitR, animationDieL, animationDieR;
        vector<int> Area;
        int direction, state, MapX, MapY, x, y, mh,mw,hp, currentMap,expr,dmg;
        double timer_death,timer_gethit,timer_hit;
};

class Map
{
    public:
		~Map();
        void Initialize(int);
        int getInitX();
        int getInitY();
        int getMapX();
        int getMapY();
        int scrollRight();
        int scrollLeft();
        void onShow();
        void monsterMove();
        void monsterShow();
        int hitMonster(int,int,int, int, int, int, int,bool, int*);
		int Monsterhit(int, int,int,int);
        void setArea(vector<int>*);
        void setLadder(vector<int>*);
		int setTeleport(vector<int>*);
		bool isEdge(vector<int>*,string);
        bool isArea(vector<int>*);
        bool isLadder(vector<int>*);
		bool isTeleport(vector<int>*);
    protected:
        int MapX, MapY, currentMap,edgex1,edgex2;
        vector<vector<int>> Area;
        vector<vector<int>> Ladder;
		vector<vector<int>> Teleport;
        vector<Monster*> monster;
        CMovingBitmap *background=NULL;
};

class Character
{
    public:
		~Character();
        int  GetX1();
        int  GetY1();
        int  GetX2();
        int  GetY2();
        int GetFall();
		int LevelUp(int);
        void Initialize(Map*);
        void LoadBitmap();
		void MakeDamageFont(int);
		void ShowDamageFont();
		void SetMovingDown(bool);
		void SetMovingLeft(bool);
		void SetMovingRight(bool);
		void SetMovingUp(bool);
		void SetAttack(bool, string);
		void SetJump(bool);
        void OnMove();
        void OnShow();
        void Jump(vector<int>*, string);
        bool JudgeArea(vector<int>*, string);
    protected:
        CAnimation animationStandR, animationStandL, animationProneR, animationProneL, animationJumpR, animationJumpL, animationWalkR, animationWalkL, animationAttackR, animationAttackL, animationLadder,animationGetHitR,animationGetHitL;
        CAnimation animationSkillQL, animationSkillQR,animationSkillW1,animationSkillW2;
		CMovingBitmap playerinfo;
		vector<CMovingBitmap*> hp_pic,mp_pic;
		vector<vector<CMovingBitmap*>> damagefont;
		vector<double> damagefont_timer;
		int x, y,hp,mp,expr,hp_limit,mp_limit,lvl, onLadder, Fall, direction;
		int mh, mw, velocity, initial_velocity, currentMap;
		int q_mp, w_mp;
		double q_timer, w_timer,mp_timer,hp_timer,hit_timer;
		string attackstate;
        bool isMovingDown, isMovingLeft, isMovingRight, isMovingUp, isJump, isAttack,ishit,skillwstate;
        Map* map;
        vector<int> pos;
};

class CGameStateInit : public CGameState
{
    public:
        CGameStateInit(CGame* g);
        void OnInit();  								// �C������Ȥιϧγ]�w
        void OnBeginState();							// �]�w�C�������һݪ��ܼ�
        void OnKeyUp(UINT, UINT, UINT); 				// �B�z��LUp���ʧ@
        void OnLButtonDown(UINT nFlags, CPoint point);  // �B�z�ƹ����ʧ@
    protected:
        void OnShow();									// ��ܳo�Ӫ��A���C���e��
    private:
        int MapX, MapY;
};

/////////////////////////////////////////////////////////////////////////////
// �o��class���C�����C�����檫��A�D�n���C���{�����b�o��
// �C��Member function��Implementation���n����
/////////////////////////////////////////////////////////////////////////////

class CGameStateRun : public CGameState
{
    public:
        CGameStateRun(CGame* g);
        void OnBeginState();							// �]�w�C�������һݪ��ܼ�
        void OnInit();  								// �C������Ȥιϧγ]�w
        void OnKeyDown(UINT, UINT, UINT);
        void OnKeyUp(UINT, UINT, UINT);
    protected:
        void OnMove();									// ���ʹC������
        void OnShow();									// ��ܳo�Ӫ��A���C���e��
    private:
        Character	character;
        Map map;
};

/////////////////////////////////////////////////////////////////////////////
// �o��class���C�����������A(Game Over)
// �C��Member function��Implementation���n����
/////////////////////////////////////////////////////////////////////////////

class CGameStateOver : public CGameState
{
    public:
        CGameStateOver(CGame* g);
        void OnInit();
    protected:
        void OnShow();									// ��ܳo�Ӫ��A���C���e��
};

}